package techSol;

public abstract class Employee implements Remunerator{
	public double employeeSalary;
	public abstract double calculateSalary();

}
