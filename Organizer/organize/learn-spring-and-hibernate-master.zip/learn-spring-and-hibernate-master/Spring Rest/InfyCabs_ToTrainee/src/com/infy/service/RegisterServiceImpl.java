package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.RegisterDAO;
import com.infy.exception.DAOTechnicalError;
import com.infy.exception.InvalidCustomerDataException;
import com.infy.model.UserDetail;

@Service("registerService")
@Transactional(readOnly = true)
public class RegisterServiceImpl implements RegisterService {
	@Autowired
	RegisterDAO registerDao;

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String register(UserDetail detail) throws DAOTechnicalError,
			InvalidCustomerDataException {
		Long mobile = 0L;

		try {
			mobile = registerDao.register(detail);
			if (mobile != null) {
				detail.setNotification("Success");
			} else {
				throw new InvalidCustomerDataException(
						"RegisterService.Invalid_Data");
			}

		} catch (Exception e) {
			throw e;
		}
		return detail.getNotification();
	}

}
