package tetser;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import config.SpringConfig;
import model.Address;
import model.Customer;

public class Tester {

	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(SpringConfig.class);
		// get bean by type
		// Address address = ctx.getBean(Address.class);
		
		// get bean by name
		/*Address address = (Address)ctx.getBean("getAddress");
		System.out.println(address.getAddLine1() + " " + address.getPin());
		
		Address address1 = (Address)ctx.getBean("createAddress");
		System.out.println(address1.getAddLine1() + " " + address1.getPin());
		System.out.println(ctx.getApplicationName());*/
		
		Customer customer = ctx.getBean(Customer.class);
		//System.out.println(customer.getName() + " " + customer.getAddress().getAddLine1() + " " + customer.getAddress().getPin());
		System.out.println(customer.getName() + " " + customer.getAddress());
	}
}
