package com.infy.ui;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.infy.configuration.AppConfig;
import com.infy.model.Director;
import com.infy.model.Movie;
import com.infy.service.MovieService;
import com.infy.utility.ContextFactory;

public class UserInterface {

	public static void main(String[] args) {
		//UserInterface.addDirector();
		//UserInterface.getDirectorDetails();
		UserInterface.updateDirector();

	}

	public static void addDirector() {
		MovieService movieService = (MovieService) ContextFactory.getContext()
				.getBean("movieService");
		try {

			Director director = new Director();
			director.setDirectorId("D9011");
			director.setDirectorName("Gautham Menon");
			LocalDate today = LocalDate.of(1985, 5, 3);
			director.setDob(today);
			director.setMoviesList(null);
			Movie movie1 = new Movie();
			movie1.setMovieName("Avatar 2");
			Movie movie2 = new Movie();
			movie2.setMovieName("Avatar 3");
			List<Movie> moviesList = new ArrayList<Movie>();
			moviesList.add(movie1);
			moviesList.add(movie2);
			director.setMoviesList(moviesList);
			movieService.addDirector(director);

			String message = AppConfig.PROPERTIES
					.getProperty("UserInterface.DIRECTOR_ADD_SUCCESS");

			System.out.println(message);
		} catch (Exception e) {
			// e.printStackTrace();
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void updateDirector() {
		MovieService movieService = (MovieService) ContextFactory.getContext()
				.getBean("movieService");
		try {

			Movie movie1 = new Movie();
			movie1.setMovieName("Avatar 4");
			Movie movie2 = new Movie();
			movie2.setMovieName("Avatar 5");
			List<Movie> moviesList = new ArrayList<Movie>();
			moviesList.add(movie1);
			moviesList.add(movie2);

			Integer recordsUpdate = movieService.updateDirector("D9008",
					moviesList);

			String message = AppConfig.PROPERTIES
					.getProperty("UserInterface.DIRECTOR_UPDATE_SUCCESS");

			System.out.println(recordsUpdate + " " + message);

		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
			e.printStackTrace();
		}
	}

	public static void getDirectorDetails() {
		MovieService movieService = (MovieService) ContextFactory.getContext()
				.getBean("movieService");
		try {
			String directorId = "D9002";
			Director director = movieService.getDirectorDetails(directorId);

			System.out.println("Director Details");
			System.out.println("-------------------");
			System.out.println("Director id \t\t:" + director.getDirectorId());
			System.out.println("Director Name \t\t:"
					+ director.getDirectorName() + "\n");
			System.out.println("Movie Details");
			System.out.println("-------------------");
			for (Movie movie : director.getMoviesList()) {
				System.out.println("Movie Id \t\t:" + movie.getMovieId());
				System.out.println("Movie Name \t\t:" + movie.getMovieName());
				System.out.println("IMDB Rating \t\t:" + movie.getIMDBRating()
						+ "\n");
			}

		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
			e.printStackTrace();
		}
	}
}
