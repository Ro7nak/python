package com.airticketreservation.service;

import com.airticketreservation.model.Passenger;

public interface UpdateProfileService {
	public Boolean updateProfile(Passenger passenger) throws Exception;

	public Boolean updateAddress(Passenger passenger) throws Exception;

}

