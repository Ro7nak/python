package com.infy.validator;


import com.infy.model.Loan;

public class Validator {

	//DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public static void validate(Loan loan) throws Exception{
			// Your code goes here
		if(!validateLoanType(loan.getLoanType()))
			throw new Exception("Validator.INVALID_LOANTYPE");
		}
	
	// don't tamper with the signature
	public static Boolean validateLoanType(String loanType) throws Exception {
		
		// Your code goes here
		Boolean isValid = false;
		// Ignore case
		String pattern = "(?i)(HomeLoan|CarLoan)";
		if(loanType.matches(pattern))
			isValid = true;
		return isValid;
		
	}

}
