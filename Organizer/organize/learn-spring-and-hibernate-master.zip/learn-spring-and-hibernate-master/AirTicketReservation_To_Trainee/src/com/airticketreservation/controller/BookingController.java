package com.airticketreservation.controller;

import java.time.LocalDate;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.airticketreservation.model.FlightSchedule;
import com.airticketreservation.service.BookingService;
import com.airticketreservation.utility.ContextFactory;

@Controller
@PropertySource("classpath:/com/airticketreservation/resources/configuration.properties")
public class BookingController {

	@Autowired
	private Environment environment;
	
	@RequestMapping(value = { "/bookFlights" })
	public ModelAndView bookFlights(HttpSession httpSession) {
		ModelAndView modelAndView = new ModelAndView("searchFlights");
		modelAndView.addObject("name", httpSession.getAttribute("passengerName"));
		return modelAndView;
	}

	
	@RequestMapping(value = "/searchFlights", method=RequestMethod.POST)
	public ModelAndView searchForFlights(@RequestParam("source") String source,
			@RequestParam("destination") String destination,
			@RequestParam("travelDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate travelDate, 
			HttpSession httpSession)
	{
		ModelAndView model = new ModelAndView("searchFlights");
		model.addObject("name", httpSession.getAttribute("passengerName"));

		try
		{	
			BookingService bookingService = (BookingService) ContextFactory.getContext().getBean("bookingService");
			List<FlightSchedule> flightScheduleList = bookingService.searchFlights(source, destination, travelDate);
			model.addObject("flightScheduleList", flightScheduleList);
			
			httpSession.setAttribute("Source", source);
			httpSession.setAttribute("Destination", destination);
			httpSession.setAttribute("Travel Date", travelDate);
			httpSession.setAttribute("FlightScheduleList", flightScheduleList);
		
		} 
		catch (Exception e) 
		{
			if(e.getMessage()!=null)
			{
				model.addObject("message", environment.getProperty(e.getMessage()));
			}
		}			
		
		return model;
	}
	
	
	@RequestMapping(value = "/bookingFlights/{scheduleId}")
	public ModelAndView bookingFlights(@PathVariable("scheduleId") String scheduleId, HttpSession httpSession)
	{
		
		ModelAndView model = new ModelAndView("bookingFlights");
		model.addObject("name", httpSession.getAttribute("passengerName"));
		httpSession.setAttribute("scheduleId", scheduleId);
		try
		{
		BookingService bookingService = (BookingService) ContextFactory.getContext().getBean("bookingService");
		FlightSchedule flightSchedule = bookingService.getFlightSchedules(scheduleId);
		
		model.addObject("flightSchedule", flightSchedule);
		httpSession.setAttribute("FlightSchedule", flightSchedule);
		} 
		catch (Exception e) 
		{
			if(e.getMessage()!=null)
			{
				model.addObject("message", environment.getProperty(e.getMessage()));
			}
		}	
		return model;
	}
	
	@RequestMapping(value = "bookingFlights/confirmBooking", method=RequestMethod.POST)
	public ModelAndView confirmBooking(@RequestParam("ticketsNeeded") String ticketsNeeded,HttpSession httpSession)
	{
		ModelAndView model = new ModelAndView("bookingFlights");
		model.addObject("name", httpSession.getAttribute("passengerName"));
		model.addObject("flightSchedule", httpSession.getAttribute("FlightSchedule"));
		model.addObject("message", null);
		model.addObject("successMessage", null);
		
		try
		{
		FlightSchedule scheduleSelected = (FlightSchedule) httpSession.getAttribute("FlightSchedule");
		Integer ticket = Integer.parseInt(ticketsNeeded);
		Integer profileId = (Integer) httpSession.getAttribute("userId");
		BookingService bookingService = (BookingService) ContextFactory.getContext().getBean("bookingService");
		Integer bookingId = bookingService.bookFlights(scheduleSelected, ticket, profileId);
		if (bookingId != null){
			model.addObject("successMessage", environment.getProperty("BookingController.BOOKING_SUCCESS")+bookingId);
		}
		
		
		} 
		catch (Exception e) 
		{
			if(e.getMessage()!=null)
			{
				model.addObject("message", environment.getProperty(e.getMessage()));
			}
		}
		
		return model;
	}
}
