package com.infy.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.UserDetailEntity;
import com.infy.exception.DAOTechnicalError;
import com.infy.model.UserDetail;
import com.infy.utility.ContextFactory;

@Repository("registerDao")
public class RegisterDAOImpl implements RegisterDAO {
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public Long register(UserDetail detail) throws DAOTechnicalError {

		Session session = null;
		Long mobile = 0L;
		session = sessionFactory.getCurrentSession();
		UserDetailEntity userDetail = (UserDetailEntity) ContextFactory
				.getContext().getBean("userDetailEntity");
		userDetail.setMobilenumber(detail.getMobileNumber());
		userDetail.setEmail(detail.getEmail());
		userDetail.setName(detail.getName());
		userDetail.setPassword(detail.getPassword());
		userDetail.setNotifications(detail.getNotification());
		userDetail.setRole(detail.getRole());
		mobile = (Long) session.save(userDetail);

		return mobile;

	}
}