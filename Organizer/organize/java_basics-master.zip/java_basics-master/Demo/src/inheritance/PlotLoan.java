package inheritance;

public class PlotLoan extends HomeLoan{

	public static void main(String[] args) {
		
		PlotLoan pl = new PlotLoan();
		pl.accountNumber = "055123";
	}

}
