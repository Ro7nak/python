package com.airticketreservation.utility;

import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;


@Component
@Aspect
public class LoggingAspect {

	
	@AfterThrowing(pointcut = "execution(* com.airticketreservation.dao.*.*(..))", throwing = "exception")
	public void logExceptionFromDAO(Exception exception) throws Exception {
		log(exception);
		throw new Exception("DAO.TECHNICAL_ERROR");

	}

	@AfterThrowing(pointcut = "execution(* com.airticketreservation.service.*.*(..))", throwing = "exception")
	public void logExceptionFromService(Exception exception) throws Exception {
		if (exception.getMessage().contains("Service")) {
			log(exception);
		}
		throw exception;

	}

	@AfterThrowing(pointcut = "execution(* com.airticketreservation.validator.*.*(..))", throwing = "exception")
	public void logExceptionFromValidator(Exception exception) throws Exception {

		log(exception);
		throw exception;

	}

	
	private void log(Exception exception) {
		
		LogConfig.getLogger(this.getClass()).error(exception.getMessage(), exception);

	}

}
