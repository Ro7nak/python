package com.infy.validator;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import com.infy.model.Policy;

public class Validator {
	

	public static void validate(Policy policy) throws Exception{
		
		if(!validatePolicyName(policy.getPolicyName()))
			throw new Exception("Validator.INVALID_POLICY_NAME");
		
		if(!validatePolicyType(policy.getPolicyType()))
			throw new Exception("Validator.INVALID_POLICY_TYPE");
		
		if(!validatePremium(policy.getPremium()))
			throw new Exception("Validator.INVALID_PREMIUM");
		
		if(!validateTenure(policy.getTenureInMonths()))
			throw new Exception("Validator.INVALID_TENURE");
		
		if(!validateDateOfBirth(policy.getDateOfBirth()))
			throw new Exception("Validator.INVALID_DOB");
		
		if(!validatePolicyNumber(policy.getPolicyNumber(), policy.getPolicyType()))
			throw new Exception("Validator.INVALID_POLICY_NUMBER");
		
		if(!validatePolicyHolderName(policy.getPolicyHolderName()))
			throw new Exception("Validator.INVALID_HOLDER_NAME");
		
		
		
	}


	
	public static Boolean validatePolicyName(String policyName){
		Boolean isValid = false;
		if(policyName.matches("[A-Za-z]+") && ! policyName.matches(""))
			isValid = true;
		return isValid;
	}

	
	public static Boolean validatePolicyType(String policyType){
		Boolean isValid = false;
		String pattern = "(Term Life Insurance|Whole Life Policy|Endowment Plans)";
		if(policyType.matches(pattern))
			isValid = true;
		return isValid;
	}

	
	public static Boolean validatePremium(Double premium){
		Boolean flag = false;
		if(premium > 100)
			flag = true;
		return flag;
	}

	
	public static Boolean validateTenure(Integer tenureInMonths){
		Boolean flag = false;
		if(tenureInMonths > 24)
			flag = true;
		return flag;
	}


	
	public static Boolean validateDateOfBirth(LocalDate dateOfBirth){
		Boolean flag = false;
		if(dateOfBirth.isBefore(LocalDate.now()))
			flag = true;
		return flag;
	}

	
	public static Boolean validatePolicyNumber(String policyNumber,String policyType){
		Boolean isValid = false;
		String pattern = "(TL|WL|EP)-[\\d]{6}";
		Map<String, String> acronymMap = new HashMap<String, String>();
		acronymMap.put("Term Life Insurance", "TL");
		acronymMap.put("Whole Life Policy", "WL");
		acronymMap.put("Endowment Plans", "EP");
		if(policyNumber.matches(pattern) && acronymMap.containsKey(policyType)) {
			if(policyNumber.startsWith(acronymMap.get(policyType)))
				isValid = true;
		}
		
		return isValid;
	}

	
	public static Boolean validatePolicyHolderName(String policyHolderName){
		Boolean isValid = false;
//		if(!policyHolderName.equals(" ") && !policyHolderName.matches(".*[^A-Za-z].*") && policyHolderName.matches(".*\\b[A-Za-z]{3,}\\b.*") && !policyHolderName.matches(".*\\s{2,}.*"))
		String pattern = "([A-Za-z]+ )*([A-Za-z]{3,})( [A-Za-z]+)*";
		if(policyHolderName.matches(pattern))
			isValid = true;
		return isValid;
	}


}
