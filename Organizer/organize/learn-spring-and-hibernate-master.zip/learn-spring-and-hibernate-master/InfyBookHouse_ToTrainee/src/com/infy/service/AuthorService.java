package com.infy.service;

import java.util.List;

import com.infy.model.Author;



public interface AuthorService {
	
	public Integer addAuthor(Author author) throws Exception;	
	public List<Author> getAuthorDetails(String qualification) throws Exception;
}
