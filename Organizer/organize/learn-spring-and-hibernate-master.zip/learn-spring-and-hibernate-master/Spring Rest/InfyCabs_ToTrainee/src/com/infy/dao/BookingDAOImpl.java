package com.infy.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.CabBookingEntity;
import com.infy.entity.FareEstimationEntity;
import com.infy.exception.DAOTechnicalError;
import com.infy.model.CabBooking;
import com.infy.utility.ContextFactory;

@Repository("bookingDao")

public class BookingDAOImpl implements BookingDAO{
	@Autowired
	SessionFactory sessionFactory;
	@Override
	
	public Float getEstimateFare( String from,String to) throws DAOTechnicalError{
		Session session=null;
		Float distance=0f;
		
			session=sessionFactory.getCurrentSession();
			CriteriaBuilder builder=session.getCriteriaBuilder();
			CriteriaQuery<FareEstimationEntity> criteria = builder.createQuery(FareEstimationEntity.class);
			Root<FareEstimationEntity> query=criteria.from(FareEstimationEntity.class);
			List<FareEstimationEntity> fare=session.createQuery(criteria).list();
			for(FareEstimationEntity i:fare){
				String place[]=i.getSourceDestination().split("-");
				if(place[0].equalsIgnoreCase(from)){
					if(place[1].equalsIgnoreCase(to)){
						distance=i.getDistance();
						System.out.println(distance);
						return distance;
					
				}}
				else if(place[1].equalsIgnoreCase(from)){
					if(place[0].equalsIgnoreCase(to)){
						distance=i.getDistance();
					}
				}
			}

			return distance;

	}
	
	@Override
	public Integer booking(CabBooking booking) throws DAOTechnicalError{
		Session session=null;
		Integer bookingId=0;
			session=sessionFactory.getCurrentSession();
			
			CabBookingEntity book=(CabBookingEntity)ContextFactory.getContext().getBean("cabBookingEntity");
			book.setFrom(booking.getFrom());
			book.setTo(booking.getTo());
			book.setEstimatedfare(booking.getEstimatedfare());
			book.setUsermobilenumber(booking.getUsermobilenumber());
			book.setDateoftravel(Calendar.getInstance());
			book.setStatus(booking.getStatus());
			bookingId=(Integer)session.save(book);
			
		return bookingId;
	}
	
	@Override
	public List<CabBooking> getdetails(Long mobileNo) throws DAOTechnicalError{
		Session session=null;
		List<CabBooking> bookingList=null;
			session=sessionFactory.getCurrentSession();
			CriteriaBuilder builder=session.getCriteriaBuilder();
			CriteriaQuery<CabBookingEntity> criteria = builder.createQuery(CabBookingEntity.class);
			Root<CabBookingEntity> query=criteria.from(CabBookingEntity.class);
			criteria.where(builder.equal(query.get("usermobilenumber"),mobileNo));
			List<CabBookingEntity> details=session.createQuery(criteria).list();
			bookingList=new ArrayList<CabBooking>();
			for(CabBookingEntity i:details){
				CabBooking booking=ContextFactory.getContext().getBean(CabBooking.class);
				booking.setBookingId(i.getBookingid());
				booking.setDateoftravel(i.getDateoftravel());
				booking.setEstimatedfare(i.getEstimatedfare());
				booking.setFrom(i.getFrom());
				booking.setTo(i.getTo());
				booking.setStatus(i.getStatus());
				booking.setUsermobilenumber(i.getUsermobilenumber());
				bookingList.add(booking);
			}
			
		return bookingList;
		
	}
	
	@Override
	public Integer updateBooking(Integer bookingId,Long mobileNo) throws DAOTechnicalError{
		Session session=null;
		CabBookingEntity booking=null;
			session=sessionFactory.getCurrentSession();
			CriteriaBuilder builder=session.getCriteriaBuilder();
			CriteriaQuery<CabBookingEntity> criteria=builder.createQuery(CabBookingEntity.class);
			Root<CabBookingEntity> root=criteria.from(CabBookingEntity.class);
			criteria.where(builder.and((builder.equal(root.get("bookingId"), bookingId)),(builder.equal(root.get("usermobilenumber"), mobileNo))));
			
			booking=(CabBookingEntity)session.createQuery(criteria).uniqueResult();
			
			if(booking!=null && booking.getStatus()=='B'){
				booking.setStatus('C');
				}else{
					return null;
				}
			
			
		return bookingId;
	}

}
