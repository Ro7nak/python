package com.airticketreservation.dao;

import com.airticketreservation.model.Passenger;

public interface PassengerRegisterDAO {

	public Integer addNewPassenger(Passenger passenger) throws Exception;

}
