package com.infy.service;

	import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dao.CustomerLoginDAO;
import com.infy.model.CustomerLogin;
	
	@Service(value = "customerLoginSerivce")
	public class CustomerLoginServiceImpl implements CustomerLoginService {
		@Autowired
		private CustomerLoginDAO customerLoginDao;
	
		public Boolean authenticateCustomerLogin(CustomerLogin customerLogin) {
			Boolean isValid = false;
			CustomerLogin customerLoginFromDao = customerLoginDao
					.getCustomerLoginByLoginName(customerLogin.getLoginName());
			if (customerLogin.getPassword().equals(
					customerLoginFromDao.getPassword()))
				isValid = true;
			return isValid;
		}
	}

	