package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.TransactionDAO;
import com.infy.model.Transaction;
import com.infy.validator.Validator;

@Service(value = "transactionService")
@Transactional(readOnly = true)
public class TransactionServiceImpl implements TransactionService {
	@Autowired
	private TransactionDAO transactionDAO;

	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Integer makeTransaction(Transaction transaction) throws Exception {
		Integer result = null;
		Validator.validateAmount(transaction.getAmount());
		Validator.validateCustomerId(transaction.getCustomerId());
		result = transactionDAO.makeTransaction(transaction);
		return result;
	}
	@Transactional(readOnly = true)
	public Transaction getTransactionDetails(Integer transactionId)
			throws Exception {
		Transaction transaction = null;
		transaction = transactionDAO.getTransactionDetails(transactionId);
		if(transaction == null) 
			throw new Exception("Service.No_Transaction_Found");
		return transaction;
	}

}
