package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dao.DesktopAllocationDAO;
import com.infy.model.Trainee;
import com.infy.utility.LogConfig;
import com.infy.validator.Validator;

@Service(value = "desktopAllocationService")
public class DesktopAllocationServiceImpl implements DesktopAllocationService {
	@Autowired
	private DesktopAllocationDAO desktopDao;
	public Trainee getAllocationDetails(Integer traineeId) throws Exception {
		Trainee trainee = null;
		try {
			trainee = desktopDao.getAllocationDetails(traineeId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			if(e.getMessage().contains("Service"))
				LogConfig.getLogger(this.getClass()).error(e.getMessage(), e);
			throw e;
		}
		return trainee;
	}

	@Override
	public Integer addNewTrainee(Trainee trainee) throws Exception {
		Integer result = 0;
		Validator.validate(trainee);
		result = desktopDao.addNewTrainee(trainee);
		return result;
	}

	
}
