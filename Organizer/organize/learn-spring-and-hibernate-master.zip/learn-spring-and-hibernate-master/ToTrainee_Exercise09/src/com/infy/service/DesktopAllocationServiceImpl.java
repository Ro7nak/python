package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.DesktopAllocationDAO;
import com.infy.model.Desktop;
import com.infy.model.Trainee;

@Service(value = "desktopAllocationService")
@Transactional(readOnly = true)
public class DesktopAllocationServiceImpl implements DesktopAllocationService {
	
	@Autowired
	private DesktopAllocationDAO desktopAllocationDAO;
	@Transactional(readOnly = true)
	public Trainee getAllocationDetails(Integer traineeId) throws Exception {
		Trainee trainee = null;
		trainee = desktopAllocationDAO.getAllocationDetails(traineeId);
		return trainee;
	}

	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Integer addNewTrainee(Trainee trainee) throws Exception {
		Integer result = null;
		result = desktopAllocationDAO.addNewTrainee(trainee);
		return result;
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void allocateExistingDesktop(Integer traineeId, String machineName)
			throws Exception {
		Integer result = desktopAllocationDAO.allocateExistingDesktop(traineeId, machineName);
		if(result == 0)
			throw new Exception("Service.DESKTOP_NOT_FOUND");
		if(result == -1)
			throw new Exception("Service.TRAINEE_NOT_FOUND");
	}

	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String allocateNewDesktop(Integer traineeId, Desktop desktop)
			throws Exception {
		String result = null;
		result = desktopAllocationDAO.allocateNewDesktop(traineeId, desktop);
		if(result == null)
			throw new Exception("Service.TRAINEE_NOT_FOUND");
		return result;
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String deallocateDesktop(Integer traineeId) throws Exception {
		String result = null;
		result = desktopAllocationDAO.deallocateDesktop(traineeId);
		if(result == null)
			throw new Exception("Service.TRAINEE_NOT_FOUND");
		return result;
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String deleteTraineeOnly(Integer traineeId) throws Exception {
		String result = null;
		result = desktopAllocationDAO.deleteTraineeOnly(traineeId);
		if(result == null)
			throw new Exception("Service.TRAINEE_NOT_FOUND");
		return result;

	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void deleteTraineeAndDesktop(Integer traineeId) throws Exception {
		Integer result = null;
		result = desktopAllocationDAO.deleteTraineeAndDesktop(traineeId);
		if(result == 0)
			throw new Exception("Service.TRAINEE_NOT_FOUND");
		if(result == -1)
			throw new Exception("Service.NO_DESKTOP_MAPPED");
	}

}
