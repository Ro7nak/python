package com.infy.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.MovieDAO;
import com.infy.model.Movie;

@Service(value = "movieService")
@Transactional(readOnly = true)
public class MovieServiceImpl implements MovieService {
	@Autowired
	private MovieDAO movieDAO;

	public List<Movie> getMovieByRatingInAscending(Double fromRating)
			throws Exception {
		List<Movie> movieList = null;
		movieList = movieDAO.getMovieByRatingInAscending(fromRating);
		return movieList;
	}

	public Map<String, Float> getMaxRatedMovieOfDirector(String directorName)
			throws Exception {
		Map<String, Float> directorMaxRatingMap = new HashMap<>();
		directorMaxRatingMap = movieDAO.getMaxRatedMovieOfDirector(directorName);
		return directorMaxRatingMap;
	}

	public Float getAverageRatingOFDirector(String directorName)
			throws Exception {
		Float averageRating = null;
		averageRating = movieDAO.getAverageRatingOFDirector(directorName);
		return averageRating;
	}

	public Integer getNumberMovieReleasedInYearRange(Integer fromYear,
			Integer toYear) throws Exception {
		Integer result = null;
		result = movieDAO.getNumberMovieReleasedInYearRange(fromYear, toYear);
		return result;
	}

}
