package com.airticketreservation.dao;

import java.time.LocalDate;
import java.util.List;

import com.airticketreservation.model.BookingDetails;
import com.airticketreservation.model.FlightSchedule;

public interface BookingDAO {

	public List<FlightSchedule> searchFlights(String source, String destination, LocalDate travelDate);

	public Integer bookFlights(BookingDetails bookingDetails, Integer userId);

	public FlightSchedule getFlightSchedules(String scheduleId);

}
