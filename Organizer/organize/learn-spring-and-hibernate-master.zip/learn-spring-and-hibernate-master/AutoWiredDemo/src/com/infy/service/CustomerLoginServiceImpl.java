package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.infy.dao.CustomerLoginDAO;
import com.infy.model.CustomerLogin;

public class CustomerLoginServiceImpl implements CustomerLoginService {
	@Autowired
	private CustomerLoginDAO customerLoginDAO;

	@Override
	public Boolean authenticateCustomer(CustomerLogin customerLogin)
			throws Exception {
		Boolean isValid = false;
		CustomerLogin customerLoginFromDAO = customerLoginDAO.getCustomerLoginByLoginName(customerLogin.getLoginName());
		if(customerLogin.getPassword().equals(customerLoginFromDAO.getPassword())) 
			isValid = true;
		
		return isValid;
	}
	
	
}
