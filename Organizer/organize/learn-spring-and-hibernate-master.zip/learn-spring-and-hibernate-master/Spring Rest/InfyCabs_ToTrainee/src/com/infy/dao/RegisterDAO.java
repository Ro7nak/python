package com.infy.dao;

import com.infy.exception.DAOTechnicalError;
import com.infy.model.UserDetail;

public interface RegisterDAO {
	public Long register(UserDetail detail) throws DAOTechnicalError;

}
