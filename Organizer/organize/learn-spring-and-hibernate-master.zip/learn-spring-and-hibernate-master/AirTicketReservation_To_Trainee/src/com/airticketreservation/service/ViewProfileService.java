package com.airticketreservation.service;

import com.airticketreservation.model.Passenger;

public interface ViewProfileService {
	public Passenger viewProfile(Integer userId)
			throws 	Exception;
	}

