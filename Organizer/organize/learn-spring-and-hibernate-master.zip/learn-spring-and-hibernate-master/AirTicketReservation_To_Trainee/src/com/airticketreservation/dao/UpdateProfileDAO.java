package com.airticketreservation.dao;

import com.airticketreservation.model.Passenger;

public interface UpdateProfileDAO {
	public Integer updateProfile(Passenger passenger );

	public Integer updateAddress(Passenger passenger);
}
