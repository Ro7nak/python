package com.airticketreservation.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.airticketreservation.model.Passenger;
import com.airticketreservation.service.PassengerLoginService;
import com.airticketreservation.service.UpdateProfileService;
import com.airticketreservation.utility.ContextFactory;

@Controller
@PropertySource("classpath:/com/airticketreservation/resources/configuration.properties")
public class UpdateProfileController {
	@Autowired
	private Environment environment;

	@RequestMapping(value = { "/updateProfile" })
	public ModelAndView update(HttpSession httpSession) {
		ModelAndView model = new ModelAndView("updateProfile");

		try {

			Passenger passenger = new Passenger();
			passenger.setUserId((Integer) httpSession.getAttribute("userId"));
			passenger
					.setPassword((String) httpSession.getAttribute("password"));

			PassengerLoginService loginService = (PassengerLoginService) ContextFactory
					.getContext().getBean("passengerLoginService");
			

			Passenger passenger1 = loginService
					.authenticatePassengerLogin(passenger);
			model.addObject("passengerName", passenger1.getPassengerName());
			model.addObject("password", passenger1.getPassword());
			model.addObject("userId", passenger1.getUserId());
			model.addObject("age", passenger1.getAge());
			model.addObject("gender", passenger1.getGender());
			model.addObject("emailid", passenger1.getEmailid());
			model.addObject("contactNumber", passenger1.getContactNumber());
		} catch (Exception e) {

		}

		return model;

	}

	@RequestMapping(value = { "/Update" })
	public ModelAndView updateProfile(@ModelAttribute Passenger customerLogin,
			HttpSession httpSession) {
		ModelAndView mv = new ModelAndView("updateProfile");
		try {
			customerLogin.setUserId((Integer) httpSession
					.getAttribute("userId"));

			UpdateProfileService update = (UpdateProfileService) ContextFactory
					.getContext().getBean("updateProfileService");
			if (update.updateProfile(customerLogin)) {
				mv.addObject("successMessage", environment
						.getProperty("UpdateController.SUCCESSFULL_UPDATE"));
			}

		} catch (Exception e) {
			mv.addObject("errorMessage",
					environment.getProperty(e.getMessage()));

		}

		return mv;

	}

	@RequestMapping(value = "/addAddress")
	public ModelAndView addAddress() {
		ModelAndView model = new ModelAndView("error");
		return model;
	}

	/*@RequestMapping("/add")
	public ModelAndView add(@ModelAttribute Passenger passenger,
			HttpSession httpSession) {

		ModelAndView model = new ModelAndView("address");

		try {
			passenger.setUserId((Integer) httpSession.getAttribute("userId"));

			UpdateProfileService update = (UpdateProfileService) ContextFactory
					.getContext().getBean("updateProfileService");
			if (update.updateAddress(passenger)) {
				
				model.addObject("successMessage", environment
						.getProperty("UpdateController.SUCCESSFULL_UPDATE"));
			}

		} catch (Exception e) {
			
			model.addObject("errorMessage", environment.getProperty(e.getMessage()));
		}
		return model;
	}*/

}
