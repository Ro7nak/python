package com.infy.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dao.EmployeeDAO;
import com.infy.model.Employee;
import com.infy.validator.Validator;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service(value = "employeeService")
@Transactional(readOnly = true)
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeDAO employeeDAO;

	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Integer addEmployee(Employee employee) throws Exception {
		Integer empId = null;
		empId = employeeDAO.addEmployee(employee);
		return empId;
	}

	//@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Employee getEmployeeDetails(Integer employeeId) throws Exception {
		Employee employee = null;
		Validator.validateEmployeeId(employeeId.toString());
		employee = employeeDAO.getEmployeeDetails(employeeId);
		if(employee == null)
			throw new Exception("Sevice.Employee_Not_Exist");
		return employee;
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Integer updateEmployee(Integer employeeId, String emailId)
			throws Exception {
		Integer result = null;
		result = employeeDAO.updateEmployee(employeeId, emailId);
		if(result == null)
			throw new Exception("Sevice.Employee_Not_Exist");
		return result;
	}

	public String deleteEmployee(Integer employeeId) throws Exception {
		String result = null;
		result = employeeDAO.deleteEmployee(employeeId);
		if(result == null)
			throw new Exception("Sevice.Employee_Not_Exist");
		return result;
	}
}
