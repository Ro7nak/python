package com.infy.validator;

import com.infy.model.TeamMember;

public class Validator {

	public static void validate(TeamMember teamMember) throws Exception {
		if(!validateEmployeeId(teamMember.getEmployeeId()))
			throw new Exception("Validator.INVALID_EMPLOYEEID");

	}

	public static Boolean validateEmployeeId(Integer employeeId) throws Exception {
		return employeeId.toString().matches("\\d{6}");
	}

}
