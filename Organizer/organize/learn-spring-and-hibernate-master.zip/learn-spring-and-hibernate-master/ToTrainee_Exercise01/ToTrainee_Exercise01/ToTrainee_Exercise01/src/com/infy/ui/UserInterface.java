package com.infy.ui;

import java.time.LocalDate;

import com.infy.configuration.AppConfig;
import com.infy.model.Employee;
import com.infy.model.EmployeeUnit;
import com.infy.service.EmployeeService;
import com.infy.utility.ContextFactory;


public class UserInterface {

	
	public static void main(String[] args) throws Exception {
		
		UserInterface.addEmployee();
		//UserInterface.getEmployeeDetails();
		//UserInterface.updateEmployee();
		//UserInterface.deleteEmployee();
	}

	public static void addEmployee() {
		try {
			EmployeeService employeeService = (EmployeeService) ContextFactory.getContext().getBean("employeeService");

			Employee employee = new Employee();
			employee.setEmployeeId(2007);
			employee.setName("Wilson");
			employee.setEmailId("wilson@mail.com");
			
			employee.setDateOfBirth(LocalDate.now());
			employee.setEmployeeUnit(EmployeeUnit.DNA);

			Integer employeeId = employeeService.addEmployee(employee);

			System.out.println("Employee is successfully added with id : " + employeeId);

		} catch (Exception e) {
			System.out.println(e);
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
			
		}
	}

	public static void getEmployeeDetails() {
		try {
			EmployeeService employeeService = (EmployeeService) ContextFactory.getContext().getBean("employeeService");

			Employee employee = employeeService.getEmployeeDetails(2005);

			System.out.println("Employee Details");
			System.out.println("----------------");
			System.out.println("Employee Id \t\t:" + employee.getEmployeeId());
			System.out.println("Employee Name \t\t:" + employee.getName());
			System.out.println("Employee EmailId \t:" + employee.getEmailId());
			System.out.println("Employee DOB \t\t:" + employee.getDateOfBirth());
			System.out.println("Employee Unit \t\t:" + employee.getEmployeeUnit());
			

		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
			
		}
	}

	public static void updateEmployee() {
		try {
			EmployeeService employeeService = (EmployeeService) ContextFactory.getContext().getBean("employeeService");

			Integer employeeId = 2005;
			String emailId = "firdouse@mail.com";

			Integer empId = employeeService.updateEmployee(employeeId, emailId);

			System.out.println("Employee id " + empId + " is successfully updated with emailid");

		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
			
		}
	}

	public static void deleteEmployee() {
		try {
			EmployeeService employeeService = (EmployeeService) ContextFactory.getContext().getBean("employeeService");

			String employeeName = employeeService.deleteEmployee(2004);

			System.out.println("Employee " + employeeName + " is successfully deleted");
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
			
		}
	}
}
