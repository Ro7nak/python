package com.infy.service;

import com.infy.model.Employee;

public interface EmployeeService {
	public Integer addEmployee(Employee employee) throws Exception;

	public Employee getEmployeeDetails(Integer employeeId) throws Exception;

	public Integer updateEmployee(Integer employeeId, String emailId) throws Exception;

	public String deleteEmployee(Integer employeeId) throws Exception;

}
