package com.airticketreservation.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.airticketreservation.dao.PassengerRegisterDAO;
import com.airticketreservation.model.Passenger;
import com.airticketreservation.validator.PassengerValidator;

@Service(value = "passengerRegisterService")
@Transactional(readOnly = true)
public class PassengerRegisterServiceImpl implements PassengerRegisterService {
	
	@Autowired
	private PassengerRegisterDAO passengerRegisterDAO;
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	// don't tamper the signature
	public Integer addPassenger(Passenger passenger) throws Exception {

		// Your code goes here
		Integer result = null;
		PassengerValidator.validatePassengerDetails(passenger);
		result = passengerRegisterDAO.addNewPassenger(passenger);
		return result;
	}

}
