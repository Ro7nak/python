package com.infy.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "Transaction")
@GenericGenerator(name = "idGen", strategy = "sequence",
parameters = {@Parameter(name = "sequence_name", value = "DB_TransactionId_PK")})
public class TransactionEntity {
	@Id
	@GeneratedValue(generator = "idGen")
	private Integer transactionId;
	private String customerId;
	@Column(name = "transactionTime")
	private LocalDate transactionDateTime;
	private Double amount;
	
	public Integer getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public LocalDate getTransactionDateTime() {
		return transactionDateTime;
	}
	public void setTransactionDateTime(LocalDate transactionDateTime) {
		this.transactionDateTime = transactionDateTime;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	
	
}
