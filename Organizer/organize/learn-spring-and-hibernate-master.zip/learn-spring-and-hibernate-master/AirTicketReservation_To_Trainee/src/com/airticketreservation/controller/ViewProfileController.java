package com.airticketreservation.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.airticketreservation.model.Passenger;
import com.airticketreservation.service.ViewProfileService;
import com.airticketreservation.utility.ContextFactory;

@Controller
@PropertySource("classpath:/com/airticketreservation/resources/configuration.properties")
public class ViewProfileController {
	@Autowired
	private Environment environment;

	@RequestMapping(value = { "/viewProfile" })
	public ModelAndView bookFlights(HttpSession httpSession) {
		ModelAndView model = new ModelAndView("viewProfile");

		try {

			Integer userId = (Integer) httpSession.getAttribute("userId");			
			ViewProfileService profileService = (ViewProfileService) ContextFactory
					.getContext().getBean("viewProfileService");

			Passenger passenger1 = profileService
					.viewProfile(userId);
			model.addObject("passengerName", passenger1.getPassengerName());
			model.addObject("userId", passenger1.getUserId());
			model.addObject("password", passenger1.getPassword());
			model.addObject("age", passenger1.getAge());
			model.addObject("gender", passenger1.getGender());
			model.addObject("emailid", passenger1.getEmailid());
			model.addObject("contactNumber", passenger1.getContactNumber());
		} catch (Exception e) {

		}

		return model;

	}

}
