package com.infy.ui;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.stereotype.Component;

import com.infy.configuration.AppConfig;
import com.infy.model.Movie;
import com.infy.service.MovieService;
import com.infy.utility.ContextFactory;

public class UserInterface {

	public static void main(String[] args) {
		//getMovieByRatingInAscending();
		//getMaxRatedMovieOfDirector();
		//getAverageRatingOFDirector();
		getNumberMovieReleasedInYearRange();
	}

	private static void getMovieByRatingInAscending() {
		MovieService movieService = (MovieService) ContextFactory.getContext().getBean("movieService");

		try {

			Double fromRating = 7.6d;

			List<Movie> movieList = movieService.getMovieByRatingInAscending(fromRating);

			System.out.println("\n---------------------------------------------------");
			System.out.println(AppConfig.PROPERTIES.getProperty("UserInterface.MOVIE_LIST") + fromRating);
			System.out.println("---------------------------------------------------\n");
			int count = 1;

			System.out.printf("%2s\t%2.3s\t%4s\t%-25s\t%-25s\n", "S.No", "IMDB Rating", "Year", "Movie Name", "Director Name");
			System.out.println("-------------------------------------------------------------------------");
			for (Movie movie : movieList) {
				System.out.printf("%2d\t%1.1f\t%4d\t%-25s\t%-25s\n", count++, movie.getImdbRating(), movie.getYear(), movie.getMovieName(),
						movie.getDirectorName());
			}
		} catch (Exception e) {
			System.err.println("Error: " + AppConfig.PROPERTIES.getProperty(e.getMessage()));
			// e.printStackTrace();
		}
	}

	private static void getMaxRatedMovieOfDirector() {
		MovieService movieService = (MovieService) ContextFactory.getContext().getBean("movieService");

		try {
			String directorName = "Joss Whedon";

			Map<String, Float> movieMap = movieService.getMaxRatedMovieOfDirector(directorName);

			System.out.println("\n-----------------------------------------------");
			System.out.println(AppConfig.PROPERTIES.getProperty("UserInterface.MOVIE_DIRECTOR") + directorName);
			System.out.println("-----------------------------------------------\n");

			System.out.println("Rating\tMovie Name");
			System.out.println("------\t----------");
			for (Entry<String, Float> entry : movieMap.entrySet()) {
				System.out.println(entry.getValue() + "\t" + entry.getKey());
			}
		} catch (Exception e) {
			System.err.println("Error: " + AppConfig.PROPERTIES.getProperty(e.getMessage()));
			 e.printStackTrace();
		}
	}

	public static void getAverageRatingOFDirector() {
		MovieService movieService = (MovieService) ContextFactory.getContext().getBean("movieService");

		try {

			String directorName = "Tim Miller";
			Float avgRating = movieService.getAverageRatingOFDirector(directorName);

			System.out.println("\n-----------------------------------------");
			System.out.println(directorName + " " + AppConfig.PROPERTIES.getProperty("UserInterface.MOVIE_AVG_RATING") + avgRating);
			System.out.println("-----------------------------------------\n");

		} catch (Exception e) {
			System.err.println("Error: " + AppConfig.PROPERTIES.getProperty(e.getMessage()));
			// e.printStackTrace();
		}
	}

	public static void getNumberMovieReleasedInYearRange() {
		MovieService movieService = (MovieService) ContextFactory.getContext().getBean("movieService");

		try {

			Integer fromYear = 2017;
			Integer toYear = 2018;

			Integer noOfMovieReleased = movieService.getNumberMovieReleasedInYearRange(fromYear, toYear);

			System.out.println("\n--------------------------------------------------------------");
			System.out.println(noOfMovieReleased + " " + AppConfig.PROPERTIES.getProperty("UserInterface.MOVIE_YEAR_BETWEEN") + fromYear + " and " + toYear);
			System.out.println("--------------------------------------------------------------\n");

		} catch (Exception e) {
			System.err.println("Error: " + AppConfig.PROPERTIES.getProperty(e.getMessage()));
			// e.printStackTrace();
		}
	}
}
