package com.infy.test;

import java.time.LocalDate;

import junit.framework.Assert;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.infy.configuration.SpringConfig;
import com.infy.model.Policy;
import com.infy.service.InsuranceService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes={SpringConfig.class})
public class InsuranceServiceTest {
	@Autowired
	InsuranceService insuranceService;
	
	@Rule
	public ExpectedException ee = ExpectedException.none();
	
	@Test
	public void buyPolicyInvalidPolicyName() throws Exception{
		Policy policy = new Policy();
		policy.setPolicyNumber("WL-553912");
		policy.setPolicyName("Retirement Plan"); 
		policy.setPolicyType("Whole Life Policy"); //
		policy.setPolicyHolderName("James"); //
		policy.setDateOfBirth(LocalDate.of(1992, 1, 10));
		policy.setPremium(3500.0);
		policy.setTenureInMonths(180);
		
		ee.expectMessage("Validator.INVALID_POLICY_NAME");
		insuranceService.buyPolicy(policy);
	}
	
	@Test
	public void buyPolicyInvalidPolicyType() throws Exception{
		Policy policy = new Policy();
		policy.setPolicyNumber("WL-553912");
		policy.setPolicyName("Retirement"); 
		policy.setPolicyType("Whole Life Policy");
		policy.setPolicyHolderName("James"); //
		policy.setDateOfBirth(LocalDate.of(1992, 1, 10));
		policy.setPremium(-123.0);
		policy.setTenureInMonths(180);
		
		ee.expectMessage("Validator.INVALID_PREMIUM");
		insuranceService.buyPolicy(policy);
	}
	
	@Test
	public void buyPolicyInvalidPremium() throws Exception{
		Policy policy = new Policy();
		policy.setPolicyNumber("WL-553912");
		policy.setPolicyName("Retirement"); 
		policy.setPolicyType("Org-Infy-044"); //
		policy.setPolicyHolderName("James"); //
		policy.setDateOfBirth(LocalDate.of(1992, 1, 10));
		policy.setPremium(3500.0);
		policy.setTenureInMonths(180);
		
		ee.expectMessage("Validator.INVALID_POLICY_TYPE");
		insuranceService.buyPolicy(policy);
	}
	
	@Test
	public void buyPolicyTenure() throws Exception{
		Policy policy = new Policy();
		policy.setPolicyNumber("WL-553912");
		policy.setPolicyName("Retirement"); 
		policy.setPolicyType("Whole Life Policy");
		policy.setPolicyHolderName("James"); //
		policy.setDateOfBirth(LocalDate.of(1992, 1, 10));
		policy.setPremium(3500.0);
		policy.setTenureInMonths(12);
		
		ee.expectMessage("Validator.INVALID_TENURE");
		insuranceService.buyPolicy(policy);
	}
}
