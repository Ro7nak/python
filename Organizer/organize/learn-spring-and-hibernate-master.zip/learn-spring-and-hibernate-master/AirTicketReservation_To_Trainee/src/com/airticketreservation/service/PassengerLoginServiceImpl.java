package com.airticketreservation.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.airticketreservation.dao.PassengerLoginDAO;
import com.airticketreservation.model.Passenger;

@Service(value = "passengerLoginService")
@Transactional(readOnly=true)
public class PassengerLoginServiceImpl implements PassengerLoginService {
	
	@Autowired
	private PassengerLoginDAO passengerDao;

	@Override
	public Passenger authenticatePassengerLogin(Passenger passenger)
			throws Exception{
		
		Passenger passenger1 = passengerDao.getPassengerLoginByLoginName(passenger);
		
		if (passenger1 == null) {
			
			throw new Exception(
					"LoginService.INVALID_CREDENTIALS");
		}
		
		return passenger1;
	}	
	
}
