package com.infy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.MovieDAO;
import com.infy.model.Director;
import com.infy.model.Movie;

@Service(value = "movieService")
@Transactional(readOnly = true)
public class MovieServiceImpl implements MovieService {
	@Autowired
	private MovieDAO movieDAO;
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String addDirector(Director director) throws Exception {
		String result = null;
		result = movieDAO.addDirector(director);
		return result;
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Integer updateDirector(String directorId, List<Movie> movie)
			throws Exception {
		Integer result = null;
		result = movieDAO.updateDirector(directorId, movie);
		return result;
	}
	@Transactional(readOnly = true)
	public Director getDirectorDetails(String directorId) throws Exception {
		Director director = null;
		director = movieDAO.getDirectorDetails(directorId);
		return director;
	}
}
