package com.infy.service;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.infy.dao.ProjectDAO;
import com.infy.model.Project;
import com.infy.model.TeamMember;
import com.infy.utility.LogConfig;
import com.infy.validator.Validator;


public class ProjectServiceImpl implements ProjectService {

	@Autowired
	private ProjectDAO dao;
	public Integer addProject(Project project) throws Exception {
		Integer result = 0;
		List<TeamMember> listOfTeamMembers = project.getMemberList();
		for(TeamMember tm : listOfTeamMembers) {
			//Validator.validateEmployeeId(tm.getEmployeeId());
			Validator.validate(tm);
			result = dao.addProject(project);
				
		}
		return result;
	}

	
	@Override
	public List<Project> getProjectDetails(String technology) throws Exception {
		List<Project> filteredProjectList = new ArrayList<>();
		try {
			List<Project> projectList = dao.getProjectDetails();
			for(Project p: projectList)
				if(p.getTechnologyUsed().equals(technology))
					filteredProjectList.add(p);
			if(filteredProjectList.isEmpty())
				throw new Exception("Service.PROJECTS_NOT_FOUND");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			if(e.getMessage().startsWith("Service."))
				LogConfig.getLogger(this.getClass()).error(e.getMessage(), e);
			throw e;
		}
		return filteredProjectList;
	}


	
}
