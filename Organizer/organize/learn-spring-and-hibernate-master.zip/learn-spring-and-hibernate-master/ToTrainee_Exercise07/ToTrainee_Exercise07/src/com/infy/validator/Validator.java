package com.infy.validator;

public class Validator {
	public static void validateAmount(Double amount) {

	}

	public static void validateCustomerId(String customerId) {

	}
}
