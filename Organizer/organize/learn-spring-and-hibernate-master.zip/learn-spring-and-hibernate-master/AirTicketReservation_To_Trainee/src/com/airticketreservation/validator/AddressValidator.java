package com.airticketreservation.validator;

import com.airticketreservation.model.Address;
import com.airticketreservation.model.Passenger;

public class AddressValidator {

	// don't tamper the signature
	public static void validateAddressDetails(Passenger passenger)
			throws Exception {
		// Your code goes here

	}

	// don't tamper the signature
	public static Boolean validateAddress(Address address) {
		// Your code goes here
		return null;

	}

}
