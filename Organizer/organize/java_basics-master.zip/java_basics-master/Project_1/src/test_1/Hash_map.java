package test_1;

import java.util.HashMap;
import java.util.Map;

public class Hash_map {

	public static void main(String[] args) {
		Map<String, Integer> m = new HashMap<>();
		m.put("abc", 1);
		System.out.println(m);
		
				
				
	}
}
