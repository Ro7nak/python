package com.infy.ui;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.infy.configuration.AppConfig;
import com.infy.model.Customer;
import com.infy.service.CustomerService;
import com.infy.utility.ContextFactory;

public class UserInterface {
	static CustomerService customerService = (CustomerService) ContextFactory
			.getContext().getBean("customerService");

	public static void main(String[] args) throws Exception {

		addCustomer();

	}

	public static void addCustomer() {

		Customer customer = new Customer();
		customer.setDateOfBirth(LocalDate.of(1993, 07, 22));
		customer.setName("Tim");
		customer.setEmailId("tim@gmail.com");
		customer.setSecurityQuestionId(210001);
		customer.setSecurityAnswer("TIM");
		customer.setCreatedBy(105);
		customer.setCreatedTimeStamp(LocalDateTime.now());

		try {
			Integer custId = customerService.addCustomer(customer, 5001);
			System.out.println("\n"
					+ AppConfig.PROPERTIES
							.getProperty("UserInterface.CUSTOMER_ADDED")
					+ custId);

		} catch (Exception e) {
			e.printStackTrace();
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			if (message == null) {
				message = AppConfig.PROPERTIES.getProperty("General.EXCEPTION");
			}
			System.out.println("\nERROR:" + message);
		}

	}

}
