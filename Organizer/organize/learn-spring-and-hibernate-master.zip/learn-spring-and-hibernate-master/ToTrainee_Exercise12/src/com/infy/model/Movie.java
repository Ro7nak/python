package com.infy.model;


public class Movie {
	private Integer movieId;
	private String movieName;
	private Float IMDBRating;

	public Integer getMovieId() {
		return movieId;
	}

	public void setMovieId(Integer movieId) {
		this.movieId = movieId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public Float getIMDBRating() {
		return IMDBRating;
	}

	public void setIMDBRating(Float iMDBRating) {
		IMDBRating = iMDBRating;
	}

}
