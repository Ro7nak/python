package com.infy.dao;

import com.infy.model.Trainee;


public interface DesktopAllocationDAO {

	public Trainee getAllocationDetails(Integer traineeId) throws Exception ;
	public Integer addNewTrainee(Trainee trainee) throws Exception;

}
