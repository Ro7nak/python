package com.infy.dao;

import java.util.HashMap;
import java.util.Map;

import com.infy.model.CustomerLogin;

public class CustomerLoginDAOImpl implements CustomerLoginDAO{

	@Override
	public CustomerLogin getCustomerLoginByLoginName(String loginName) {
		Map<String, String> customerCredentials = new HashMap<>();
		customerCredentials.put("tom", "tom123");
		customerCredentials.put("gaurav", "gaurav123");
		
		CustomerLogin customerLogin = new CustomerLogin();
		customerLogin.setLoginName(loginName);
		customerLogin.setPassword(customerCredentials.get(loginName));
		return customerLogin;
	}
	
}
