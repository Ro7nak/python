package com.airticketreservation.service;

import com.airticketreservation.model.Passenger;




public interface PassengerLoginService {

	public Passenger authenticatePassengerLogin(Passenger passenger)
			throws Exception;


		
}
