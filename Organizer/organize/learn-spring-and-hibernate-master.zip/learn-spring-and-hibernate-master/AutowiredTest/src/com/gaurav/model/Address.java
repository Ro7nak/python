package com.gaurav.model;

public class Address {
	private String address;
	private Integer id;
	public Address() {
		System.out.println("Adress constructor.");
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	
}
