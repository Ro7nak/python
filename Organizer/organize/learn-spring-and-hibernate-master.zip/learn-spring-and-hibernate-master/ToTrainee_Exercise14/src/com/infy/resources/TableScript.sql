DROP TABLE ManyToMany_Trainee CASCADE CONSTRAINTS;
DROP TABLE ManyToMany_Exam CASCADE CONSTRAINTS;
DROP TABLE TraineeExam CASCADE CONSTRAINTS;

CREATE TABLE ManyToMany_Exam(
examId VARCHAR2(10) CONSTRAINT MM_ExamPK PRIMARY KEY,
details VARCHAR2(100) CONSTRAINT MM_Details_Nnull NOT NULL);

CREATE TABLE ManyToMany_Trainee(
id NUMBER(7) CONSTRAINT MM_TraineePK PRIMARY KEY,
name VARCHAR2(25) CONSTRAINT MM_Name_Nnull NOT NULL);

CREATE TABLE TraineeExam(
traineeId NUMBER(7) CONSTRAINT MM_Trainee_FK REFERENCES ManyToMany_Trainee(id),
examId VARCHAR2(15) CONSTRAINT MM_Exam_FK REFERENCES ManyToMany_Exam(examId),
CONSTRAINT TraineeExam_PK PRIMARY KEY (traineeId, examId));

INSERT INTO ManyToMany_Exam VALUES('FA1 - HO','Hands On developing Business Tier of an Application');
INSERT INTO ManyToMany_Exam VALUES('FA1 - OBJ','Objective on  developing Business Tier of an Application');


INSERT INTO ManyToMany_Trainee VALUES(800001,'Scott');
INSERT INTO ManyToMany_Trainee VALUES(800002,'Jack');
INSERT INTO ManyToMany_Trainee VALUES(800003,'Jill');

INSERT INTO TraineeExam VALUES (800001,'FA1 - HO');
INSERT INTO TraineeExam VALUES (800002,'FA1 - HO');
INSERT INTO TraineeExam VALUES (800001,'FA1 - OBJ');

COMMIT;


SELECT * FROM ManyToMany_Exam;
SELECT * FROM ManyToMany_Trainee;
SELECT * FROM TraineeExam;