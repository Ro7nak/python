package tester;

import model.Employee;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import service.RegisterService;
import config.SpringConfig;


public class Tester {

	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(SpringConfig.class);
		
		RegisterService service = ctx.getBean(RegisterService.class);
		Employee e = new Employee();
		e.setEmpId(1001);
		e.setName("Gaurav");
		String result = service.registerEmployee(e);
		System.out.println(result);
	}
}
