package com.infy.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;


@Entity
@Table(name = "Author")
@GenericGenerator(name = "sequenceGen", strategy = "sequence")
public class AuthorEntity {
	
	// Your code goes here
	@Id
	@GeneratedValue(generator = "sequenceGen")
	private Integer authorId;
	@Column(name = "name")
	private String authorName;
	private String emailId;
	private String qualification;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "",
	joinColumns = @JoinColumn(name = "authorId"),
	inverseJoinColumns = @JoinColumn(name = "bookId")
	)
	private List<BookEntity> bookList;
	public Integer getAuthorId() {
		return authorId;
	}
	public void setAuthorId(Integer authorId) {
		this.authorId = authorId;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public List<BookEntity> getBookList() {
		return bookList;
	}
	public void setBookList(List<BookEntity> bookList) {
		this.bookList = bookList;
	}
	

}
