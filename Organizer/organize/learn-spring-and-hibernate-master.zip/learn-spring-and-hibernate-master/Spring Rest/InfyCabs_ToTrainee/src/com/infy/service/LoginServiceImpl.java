package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.LoginDAO;
import com.infy.exception.DAOTechnicalError;
import com.infy.exception.InvalidCustomerCredentialsException;
import com.infy.exception.InvalidPasswordException;
import com.infy.model.UserLogin;

@Service("loginService")
@Transactional(readOnly = true)
public class LoginServiceImpl implements LoginService {
	@Autowired
	LoginDAO loginDao;

	@Override
	public String login(UserLogin user) throws DAOTechnicalError,
			InvalidCustomerCredentialsException {

		String userName = "";

		userName = loginDao.authenticate(user);
		if ((userName == null)) {
			throw new InvalidCustomerCredentialsException(
					"LoginService.Invalid_Credentials");

		}
		return userName;

	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String changePassword(String oldPassword, String confirmPassword,
			String newPassword, Long mobileNo) throws DAOTechnicalError,
			InvalidPasswordException {
		String userName = null;
		try {

			if (newPassword.equals(confirmPassword)) {

				if (oldPassword.equals(newPassword)) {
					throw new InvalidPasswordException(
							"LoginService.Invalid_Password");
				} else {
					userName = loginDao.changePassword(oldPassword,
							newPassword, mobileNo);
				}
			} else {
				throw new InvalidPasswordException(
						"LoginService.Invalid_Password");
			}
		} catch (Exception e) {

			throw e;
		}
		return userName;
	}

}
