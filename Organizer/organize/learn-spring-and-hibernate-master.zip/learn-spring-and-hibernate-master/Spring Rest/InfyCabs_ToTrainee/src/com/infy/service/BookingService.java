package com.infy.service;

import java.util.List;

import com.infy.exception.DAOTechnicalError;
import com.infy.exception.InvalidDataForBookingException;
import com.infy.exception.InvalidServiceAreaException;
import com.infy.model.CabBooking;

public interface BookingService {

	public Float getEstimateFare(String from,String to)throws  DAOTechnicalError,InvalidServiceAreaException;
	public Integer booking(CabBooking booking)throws DAOTechnicalError,InvalidDataForBookingException;
	public List<CabBooking> getdetails(Long mobileNo) throws DAOTechnicalError,Exception;
	public Integer updateBooking(Integer bookingId,Long mobileNo) throws DAOTechnicalError,Exception;
}
