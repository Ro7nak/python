package com.airticketreservation.dao;

import com.airticketreservation.model.Passenger;

public class ViewProfileDAOImpl implements ViewProfileDAO {

	// don't tamper the signature
	public Passenger viewProfile(Integer userId) {

		// Your code goes here
		return null;
	}

}
