package com.infy.dao;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.CustomerEntity;
import com.infy.model.Customer;

@Repository(value = "customerDao")
public class CustomerDAOImpl implements CustomerDAO {

	@Autowired
	SessionFactory sessionFactory;

	
	    public Integer addCustomer(Customer customer){    
	        Session session = sessionFactory.getCurrentSession();
	        CustomerEntity customerEntity = new CustomerEntity();
	        customerEntity.setName(customer.getName());
	        customerEntity.setDateOfBirth(customer.getDateOfBirth());
	        customerEntity.setEmailId(customer.getEmailId());
	        customerEntity.setCreatedBy(customer.getCreatedBy());
	        customerEntity.setSecurityQuestionId(customer.getSecurityQuestionId());
	        customerEntity.setSecurityAnswer(customer.getSecurityAnswer());
	        Integer customerId = (Integer) session.save(customerEntity);    
	        return customerId;
	    }
	}

	
