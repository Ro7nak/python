package com.infy.configuration;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.logging.log4j.Logger;

import com.infy.utility.LogConfig;

public class AppConfig {
	public static final Properties PROPERTIES;
	public static InputStream inputStream = null;
	static {
		try {
			inputStream = new FileInputStream(
					"src/com/infy/resources/configuration.properties");
		} catch (Exception e) {

			Logger logger = LogConfig.getLogger(AppConfig.class);
			logger.error(e.getMessage(), e);
		}
		PROPERTIES = new Properties();
		try {
			PROPERTIES.load(inputStream);
		} catch (IOException e) {

			Logger logger = LogConfig.getLogger(AppConfig.class);
			logger.error(e.getMessage(), e);
		}
	}
}
