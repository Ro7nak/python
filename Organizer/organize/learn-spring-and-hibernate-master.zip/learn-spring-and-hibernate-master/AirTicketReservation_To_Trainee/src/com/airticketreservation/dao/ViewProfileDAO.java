package com.airticketreservation.dao;

import com.airticketreservation.model.Passenger;

public interface ViewProfileDAO {
	
	public Passenger viewProfile(Integer userId);
	
	
}
