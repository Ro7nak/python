package config;

import model.Address;
import model.Customer;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfig {
	/*@Bean
	public Address createAddress() {
		Address address = new Address();
		address.setAddLine1("3rd cross");
		address.setPin(562157);
		return address;
	}
	
	@Bean
	public Address getAddress() {
		Address address = new Address();
		address.setAddLine1("10th cross");
		address.setPin(333333);
		return address;
	}*/
	
	@Bean
	public Customer createCustomer() { // if we make function name as address , dependency injection can be satisfied
		Customer customer = new Customer();
		customer.setName("Sarah");
		
		return customer;
	}
	
	/*@Bean
	public Salary createSalary() {
		return 
	}*/
}
