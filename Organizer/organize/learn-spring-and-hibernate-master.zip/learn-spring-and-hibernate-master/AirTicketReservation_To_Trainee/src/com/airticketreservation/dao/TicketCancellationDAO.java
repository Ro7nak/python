package com.airticketreservation.dao;

import java.util.List;

import com.airticketreservation.model.BookingDetails;



public interface TicketCancellationDAO {
	
	public List<BookingDetails> getMyBookingDetails(Integer profileId);
	public Integer cancelTicket(Integer BookingId);
	
}
