package com.infy.service;

import java.util.List;
import java.util.Map;

import com.infy.model.Movie;

public interface MovieService {

	public List<Movie> getMovieByRatingInAscending(Double fromRating) throws Exception;

	// movie Name and Rating
	public Map<String, Float> getMaxRatedMovieOfDirector(String directorName) throws Exception;

	public Float getAverageRatingOFDirector(String directorName) throws Exception;

	// Number of Movies
	public Integer getNumberMovieReleasedInYearRange(Integer fromYear, Integer toYear) throws Exception;

}
