package com.infy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dao.MovieDAO;
import com.infy.model.Movie;
import com.infy.validator.Validator;

@Service
public class MovieServiceImpl implements MovieService {
	@Autowired
	private MovieDAO dao;
	public String addMovie(Movie movie) throws Exception{
		String result = null;
		Validator.validate(movie);
		result = dao.addMovie(movie);
		return result;
	}

	public List<Movie> getMovieNameDirectorName() throws Exception{
		List<Movie> movieList = null;
		movieList = dao.getMovieNameDirectorName();
		return movieList;
		
	}
}
