package model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Customer {
	private String name;
	
	/*@Autowired
	private Address address;*/
	
	// to search a particular Bean
	/*@Autowired
	@Qualifier(value="createAddress")*/
	
	// to make address optional
	@Autowired(required=false)
	@Qualifier(value="createAddress")
	private Address address;
	
	public Customer() {
		System.out.println("Customer constructor");
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	
}
