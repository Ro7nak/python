package com.airticketreservation.dao;

import com.airticketreservation.model.Passenger;

public class UpdateProfileDAOImpl implements UpdateProfileDAO {

	// don't tamper the signature
	public Integer updateProfile(Passenger passenger) {

		// Your code goes here
		return null;

	}

	// don't tamper the signature
	public Integer updateAddress(Passenger passenger) {
		
		// Your code goes here
		return null;

	}

}
