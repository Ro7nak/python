package com.airticketreservation.service;

import java.time.LocalDate;
import java.util.List;

import com.airticketreservation.model.FlightSchedule;

public class BookingServiceImpl implements BookingService {

	// don't tamper the signature
	public List<FlightSchedule> searchFlights(String source,
			String destination, LocalDate travelDate) throws Exception {

		// Your code goes here
		return null;
	}

	// don't tamper the signature
	public Integer bookFlights(FlightSchedule flightSchedule,
			Integer ticketsNeeded, Integer userId) throws Exception {

		// Your code goes here
		return null;
	}

	// don't tamper the signature
	public FlightSchedule getFlightSchedules(String scheduleId)
			throws Exception {

		// Your code goes here
		return null;
	}
}
