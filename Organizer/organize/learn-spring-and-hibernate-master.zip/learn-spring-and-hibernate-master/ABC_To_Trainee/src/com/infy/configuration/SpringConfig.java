package com.infy.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.infy.dao.ProjectDAOImpl;
import com.infy.service.ProjectServiceImpl;

@Configuration
public class SpringConfig {

	@Bean
	public ProjectServiceImpl projectServiceImpl() {
		return new ProjectServiceImpl();
	}

	@Bean
	public ProjectDAOImpl projectDAOImpl() {
		return new ProjectDAOImpl();
	}

}
