package com.infy.dao;

import java.time.LocalDate;
import java.util.ArrayList;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.infy.model.Director;
import com.infy.model.Movie;

@Repository(value = "movieDao")
public class MovieDAOImpl implements MovieDAO {

	public String addMovie(Movie movie) throws Exception {

		return movie.getMovieId();

	}

	public List<Movie> getMovieNameDirectorName() throws Exception {

		List<Movie> movieList = new ArrayList<Movie>();

		Movie movie = new Movie();
		movie.setMovieId("M1002");
		movie.setMovieName("Baby''s Day Out");
		movie.setLanguage("English");
		movie.setReleasedIn(LocalDate.now());
		movie.setRevenueInDollars(16800000);
		Director director = new Director();
		director.setDirectorId("D102");
		director.setDirectorName("Patrick Read Johnson");
		director.setBornIn(1962);
		movie.setDirector(director);

		Movie movie1 = new Movie();
		movie1.setMovieId("M1004");
		movie1.setMovieName("Taare Zameen Par");
		movie1.setLanguage("Hindi");
		movie1.setReleasedIn(LocalDate.now());
		movie1.setRevenueInDollars(13000000);
		Director director1 = new Director();
		director1.setDirectorId("D103");
		director1.setDirectorName("Aamir Khan");
		director1.setBornIn(1965);
		movie1.setDirector(director1);
		movieList.add(movie);
		movieList.add(movie1);

		return movieList;

	}
}