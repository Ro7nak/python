package array_prac;

public class _2D_Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
	}

}
