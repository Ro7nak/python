package com.airticketreservation.service;

import java.time.LocalDate;
import java.util.List;

import com.airticketreservation.model.FlightSchedule;

public interface BookingService {

	public Integer bookFlights(FlightSchedule flightschedule, Integer seatNumber, Integer userId) throws Exception;

	public List<FlightSchedule> searchFlights(String source, String destination, LocalDate travelDate) throws Exception;

	public FlightSchedule getFlightSchedules(String flightId) throws Exception;

}
