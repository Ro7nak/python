package com.infy.model;

/**
 * Bean class to hold and transfer ClassRoom data across the tiers
 * 
 * @author ETA
 */

public class ClassRoom {
	private String classRoomId;
	private Integer seatingCapacity;

	public String getClassRoomId() {
		return classRoomId;
	}

	public void setClassRoomId(String classRoomId) {
		this.classRoomId = classRoomId;
	}

	public Integer getSeatingCapacity() {
		return seatingCapacity;
	}

	public void setSeatingCapacity(Integer seatingCapacity) {
		this.seatingCapacity = seatingCapacity;
	}

}
