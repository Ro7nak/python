package com.infy.model;

/**
 * Bean class to hold and transfer Exam data across the tiers   
 * @author ETA
 */

public class Exam {
	private String examId;
	private String details;
	public String getExamId() {
		return examId;
	}
	public void setExamId(String examId) {
		this.examId = examId;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	

}
