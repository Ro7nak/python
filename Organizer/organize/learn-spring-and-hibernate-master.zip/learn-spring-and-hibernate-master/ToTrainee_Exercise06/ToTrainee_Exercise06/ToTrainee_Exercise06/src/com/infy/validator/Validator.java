package com.infy.validator;

public class Validator {
	public static void validateAmount(Double amount) throws Exception {
		if(amount < 0)
			throw new Exception("Validator.Invalid_Amount");
	}

	public static void validateCustomerId(String customerId) throws Exception {
		if(!customerId.startsWith("C") || customerId.length() != 5)
			throw new Exception("Validator.Invalid_Customer");
	}
}
