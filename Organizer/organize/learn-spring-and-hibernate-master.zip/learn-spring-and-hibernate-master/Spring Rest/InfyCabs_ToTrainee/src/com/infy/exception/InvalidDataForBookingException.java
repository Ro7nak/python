
package com.infy.exception;


public class InvalidDataForBookingException extends Exception {

	private static final long serialVersionUID = 1L;

	public InvalidDataForBookingException(String message) {
		super(message);
	}
}
