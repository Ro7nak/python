package com.infy.ui;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.infy.configuration.AppConfig;
import com.infy.configuration.SpringConfig;
import com.infy.model.Project;
import com.infy.model.TeamMember;
import com.infy.service.ProjectService;
import com.infy.service.ProjectServiceImpl;


public class UserInterface {
	
	
	public static void main(String[] args) {
		addProject();
		getProjectDetails();
	}

	public static void addProject() {		
		ApplicationContext ctx = new AnnotationConfigApplicationContext(SpringConfig.class);
		ProjectService projectService = ctx.getBean(ProjectServiceImpl.class);
		try {
			Project project = new Project();
			project.setProjectName("FSADM8");
			project.setCost(200000);
			project.setTeamSize(5);
			project.setTechnologyUsed("JAVA");
			
			List<TeamMember> teamMemberList = new ArrayList<TeamMember>();
			TeamMember t1 = new TeamMember();
			t1.setEmployeeId(722009);
			t1.setEmployeeName("Ram Chandra");
			t1.setDesignation("SSC");
			t1.setSkills("JAVA,Oracle");
			teamMemberList.add(t1);
			
			TeamMember t2 = new TeamMember();
			t2.setEmployeeId(722019);
			t2.setEmployeeName("RADHA Ravi");
			t2.setDesignation("SSC");
			t2.setSkills("JAVA,Dotnet");
			teamMemberList.add(t2);
			
			project.setMemberList(teamMemberList);
			
			Integer result = projectService.addProject(project);
			System.out.println("New project successfully added with projectId: " + result);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage(), e.getMessage()));
		}
	}

	public static void getProjectDetails() {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(SpringConfig.class);
		ProjectService projectService = ctx.getBean(ProjectServiceImpl.class);
		String technology = "JAVA";
		try {
			projectService.getProjectDetails(technology).forEach(
					p -> {
						System.out.println("Project Id: " + p.getProjectId()
								+ " , " + "Technology used: "
								+ p.getTechnologyUsed() + "\n"
								+ "\tTeam member Details\n"
								+ "Member Id\tMember Name\tSkills");
						p.getMemberList().forEach(
								tm -> System.out.println(tm.getEmployeeId()
										+ "\t\t" + tm.getEmployeeName() + "\t"
										+ tm.getSkills()));
					});
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
