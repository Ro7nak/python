package com.infy.model;

import java.util.Calendar;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
@Component
@Scope("prototype")
public class CabBooking {
	private Integer	bookingId;
	private String from;
	private String to;
	private Float estimatedfare;
	private Float actualfare;
	private Calendar dateoftravel;
	private Long usermobilenumber;
	private Character status;
	
	public Long getUsermobilenumber() {
		return usermobilenumber;
	}
	public void setUsermobilenumber(Long usermobilenumber) {
		this.usermobilenumber = usermobilenumber;
	}
	public Character getStatus() {
		return status;
	}
	public void setStatus(Character status) {
		this.status = status;
	}
	public Integer getBookingId() {
		return bookingId;
	}
	public void setBookingId(Integer bookingid) {
		this.bookingId = bookingid;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public Float getEstimatedfare() {
		return estimatedfare;
	}
	public void setEstimatedfare(Float estimatedfare) {
		this.estimatedfare = estimatedfare;
	}
	public Float getActualfare() {
		return actualfare;
	}
	public void setActualfare(Float actualfare) {
		this.actualfare = actualfare;
	}
	public Calendar getDateoftravel() {
		return dateoftravel;
	}
	public void setDateoftravel(Calendar dateoftravel) {
		this.dateoftravel = dateoftravel;
	}
	public Long getMobilenumber() {
		return usermobilenumber;
	}
	public void setMobilenumber(Long mobilenumber) {
		this.usermobilenumber = mobilenumber;
	}
	

}
