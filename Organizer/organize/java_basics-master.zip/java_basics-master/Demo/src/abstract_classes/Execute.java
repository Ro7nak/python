package abstract_classes;

public class Execute {

	public static void main(String[] args) {
		MumbaiBranch mb = new MumbaiBranch();
		mb.openAccount("pan card", "ration card", 2000);
	}

}
