package com.infy.service;

import com.infy.model.Transaction;

public interface TransactionService {
	public Integer makeTransaction(Transaction transaction) throws Exception;

	public Transaction getTransactionDetails(Integer transactionId) throws Exception;
}
