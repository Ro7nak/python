package com.infy.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.CustomerEntity;
import com.infy.entity.LoanEntity;
import com.infy.model.Customer;
import com.infy.model.Loan;

@Repository(value = "loanDAO")
public class LoanDAOImpl implements LoanDAO {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	//DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public List<Customer> getReportByLoanType(String loanType) throws Exception {
		
		// Your code goes here
		List<Customer> customerList = null;

		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		CriteriaQuery< CustomerEntity> criteriaQuery = criteriaBuilder.createQuery(CustomerEntity.class);
		Root<CustomerEntity> root = criteriaQuery.from(CustomerEntity.class);
		criteriaQuery.select(root);
		// ignore case
		criteriaQuery.where(criteriaBuilder.equal(
				criteriaBuilder.upper(root.get("loan").get("loanType")),
				loanType.toUpperCase()));
		List<CustomerEntity> customerEntityList = session.createQuery(criteriaQuery).getResultList();
		if(!customerEntityList.isEmpty()) {
			customerList = new ArrayList<Customer>();
			for(CustomerEntity customerEntity : customerEntityList) {
				if(customerEntity.getLoan() != null) {
					LoanEntity loanEntity = customerEntity.getLoan();
					Loan loan = new Loan();
					
					//if(loanEntity.getLoanType().toUpperCase().equals(loanType.toUpperCase())) {
						loanEntity = customerEntity.getLoan();
						Customer customer = new Customer();
						customer.setCustomerId(customerEntity.getCustomerId());
						customer.setCustomerName(customerEntity.getCustomerName());

						Double amount = loanEntity.getLoanAmount();
						Integer term = loanEntity.getTerm();
						Double rate =  loanEntity.getInterestRate();
						Double interest = (amount * rate * term)/ 100;
						Double emi  = (amount + interest) / (term * 12);
						customer.setEmi(Math.ceil(emi));

						loan.setLoanId(loanEntity.getLoanId());
						loan.setLoanType(loanEntity.getLoanType());
						loan.setLoanAmount(loanEntity.getLoanAmount());
						loan.setTerm(loanEntity.getTerm());
						loan.setInterestRate(loanEntity.getInterestRate());
						customer.setLoan(loan);
						customerList.add(customer);
						
					//}
				}
			}
		}

		if(customerList.isEmpty())
			customerList = null;
		return customerList;
	}

	//DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public Integer checkLoanAllotment(Integer customerId) throws Exception {
		
		// Your code goes here
		Integer result = null;
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		CriteriaQuery<CustomerEntity> criteriaQuery = criteriaBuilder.createQuery(CustomerEntity.class);
		Root<CustomerEntity> root = criteriaQuery.from(CustomerEntity.class);
		criteriaQuery.select(root)
		.where(criteriaBuilder.equal(root.get("customerId"), customerId));
		CustomerEntity customerEntity = session.createQuery(criteriaQuery).uniqueResult();
		if(customerEntity != null) {
			if(customerEntity.getLoan() == null)
				result = 0;
			else
				result = customerEntity.getLoan().getLoanId();
		}
		return result;
	}

	//DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public Integer applyLoan(Loan loan, Integer customerId) throws Exception {
		
		// Your code goes here
		Integer result = 0;
		Session session = sessionFactory.getCurrentSession();
		CustomerEntity customerEntity = session.get(CustomerEntity.class, customerId);
		if(customerEntity != null) {
			Double interestRate = 0.0;
			Integer term = 0;
			String loanType = loan.getLoanType();
			if(loanType.equals("HomeLoan")) {
				interestRate = 13.0;
				term = 15;
			}
			else {
				interestRate = 9.0;
				term = 5;
			}
			
			LoanEntity loanEntity = new LoanEntity();
			loanEntity.setLoanType(loanType);
			loanEntity.setTerm(term);
			loanEntity.setInterestRate(interestRate);
			loanEntity.setLoanAmount(loan.getLoanAmount());
			
			result = (Integer)session.save(loanEntity);
			
			customerEntity.setLoan(loanEntity);
			//session.save(customerEntity);
			//result = customerEntity.getLoan().getLoanId();
			
		}
		
		return result;
	}

	//DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public List<Integer> closeLoan(String startsWith) throws Exception {
		
		// Your code goes here
		
		List<Integer> loanIdList = null;
		List<CustomerEntity> customerEntityList = null;
		
			Session session = sessionFactory.getCurrentSession();
			CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
			CriteriaQuery<CustomerEntity> criteriaQuery = criteriaBuilder.createQuery(CustomerEntity.class);
			Root<CustomerEntity>  root = criteriaQuery.from(CustomerEntity.class);
			criteriaQuery.select(root)
			.where(criteriaBuilder.like(root.get("customerName"), startsWith + "%"));
			customerEntityList = session.createQuery(criteriaQuery).getResultList();
			
			if(customerEntityList != null) {
				loanIdList = new ArrayList<Integer>();
				for(CustomerEntity customerEntity : customerEntityList) {
					if(customerEntity.getLoan() != null) {
						System.out.println(customerEntity.getLoan().getLoanId());
						loanIdList.add(customerEntity.getLoan().getLoanId());
						session.delete(customerEntity.getLoan()	);
						customerEntity.setLoan(null);
						session.save(customerEntity);
						
						}
					}
			}
		
		
		
		return loanIdList;
	}
}
