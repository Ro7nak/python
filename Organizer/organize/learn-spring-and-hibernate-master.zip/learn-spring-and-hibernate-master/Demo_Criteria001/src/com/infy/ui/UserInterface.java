package com.infy.ui;

import java.util.List;
import com.infy.configuration.AppConfig;
import com.infy.model.Customer;
import com.infy.service.CustomerService;
import com.infy.utility.ContextFactory;

public class UserInterface {
	static CustomerService customerService = (CustomerService) ContextFactory
			.getContext().getBean("customerService");

	public static void main(String[] args) throws Exception {
		 //getCustomerDetails();
		//getCustomerNames();
		getCustomerNameandEmailid();
	}

	public static void getCustomerDetails() {
		try {
			List<Customer> cust = customerService.getCustomerDetails();
			System.out.println("Customer ID " + "  Customer Name "
					+ "       Customer DOB " + "     Customer EmailId ");
			System.out
					.println("---------------------------------------------------------------------------");
			for (Customer c : cust) {

				System.out.println(c.getCustomerId() + "        " + c.getName()
						+ "        " + c.getDateOfBirth() + "        "
						+ c.getEmailId());
			}

		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			if (message == null) {
				message = AppConfig.PROPERTIES.getProperty("General.EXCEPTION");
			}
			System.out.println("\nERROR:" + message);
		}

	}

	public static void getCustomerNames() {
		try {
			List<String> customerName = customerService.getCustomerName();
			System.out.println("Customer Name ");
			System.out.println("--------------");

			for (String name : customerName) {
				System.out.println(name);

			}

		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			if (message == null) {
				message = AppConfig.PROPERTIES.getProperty("General.EXCEPTION");
			}
			System.out.println("\nERROR:" + message);
		}

	}

	public static void getCustomerNameandEmailid() {
		try {
			List<Object[]> customerDetails = customerService
					.getCustomerNameandEmail();
			System.out.println("Customer Name " + "        Customer EmailId ");
			System.out.println("------------------------------------");

			for (Object[] object : customerDetails) {
				System.out.println(object[0] + "           " + object[1]);

			}

		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			if (message == null) {
				message = AppConfig.PROPERTIES.getProperty("General.EXCEPTION");
			}
			System.out.println("\nERROR:" + message);
		}

	}

}
