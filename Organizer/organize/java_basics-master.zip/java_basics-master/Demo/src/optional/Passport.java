package optional;

class Passport {
    private int passportNumber;

    public int getPassportNumber() {
        return passportNumber;
    }
    public void setPassportNumber(int passportNumber) {
        this.passportNumber = passportNumber;
    }
    // Other fields and methods
}
