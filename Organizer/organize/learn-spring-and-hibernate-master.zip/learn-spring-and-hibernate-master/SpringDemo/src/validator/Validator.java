package validator;

import model.Employee;

public class Validator {

	public static void validator(Employee employee){
		System.out.println("Validating Employee Details");
	}
}
