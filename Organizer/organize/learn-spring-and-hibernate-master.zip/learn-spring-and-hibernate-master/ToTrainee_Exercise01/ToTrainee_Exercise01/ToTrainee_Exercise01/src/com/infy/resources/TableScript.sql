
DROP TABLE Employee CASCADE CONSTRAINTS;


CREATE TABLE Employee (
	employeeId NUMBER(10)PRIMARY KEY,
	employeeName VARCHAR2(100) NOT NULL,
	emailId VARCHAR2(255) UNIQUE NOT NULL,
	dob DATE NOT NULL,
	employeeUnit VARCHAR2(10) NOT NULL
);

INSERT INTO Employee VALUES (2001, 'Jack', 'jack@mail.com', '03-Sep-1988', 'EASSAP');
INSERT INTO Employee VALUES (2002, 'Jose', 'jose@mail.com', '15-Jan-1987', 'ECSADMC');
INSERT INTO Employee VALUES (2003, 'Jill', 'jill@mail.com', '15-Nov-1990','ORCALL');
INSERT INTO Employee VALUES (2004, 'Albert', 'albert@mail.com', '30-Dec-1988','DNA');
INSERT INTO Employee VALUES (2005, 'Fir', 'fir@mail.com', '04-Jan-1985','ENGCR');
INSERT INTO Employee VALUES (2006, 'Husee', 'husee@mail.com', '22-Mar-1989','ENGCR');

SELECT * FROM Employee;

COMMIT;

