package model;

public class Address {
	private String addLine1;
	private Integer pin;
	
	public Address() {
		System.out.println("Address constructor");
	}
	public String getAddLine1() {
		return addLine1;
	}
	public void setAddLine1(String addLine1) {
		this.addLine1 = addLine1;
	}
	public Integer getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	
}
