package com.infy.ui;

import java.time.LocalDate;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.infy.configuration.AppConfig;
import com.infy.configuration.SpringConfig;
import com.infy.model.Policy;
import com.infy.service.InsuranceService;
import com.infy.service.InsuranceServiceImpl;

public class UserInterface {
	
	public static void main(String[] args) {
		try {
			buyPolicy();
			generateReport();
		} catch (Exception e) {
			System.out.println(e);
			//System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
		
		
		try {
			generateReport();
		} catch (Exception e) {
			System.out.println(e);
			//System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void buyPolicy() throws Exception{
		ApplicationContext ctx = new AnnotationConfigApplicationContext(SpringConfig.class);
		InsuranceService insuranceService = ctx.getBean(InsuranceServiceImpl.class);
		//InsuranceService insuranceService = (InsuranceService)ctx.getBean("insuranceServiceImpl");
		Policy policy = new Policy();
		policy.setPolicyNumber("WL-553912");
		policy.setPolicyName("Retirement"); 
		policy.setPolicyType("Whole Life Policy"); //
		policy.setPolicyHolderName("J@@ames"); //
		policy.setDateOfBirth(LocalDate.of(1992, 1, 10));
		policy.setPremium(3500.0);
		policy.setTenureInMonths(180);
		
		String result = insuranceService.buyPolicy(policy);
		System.out.println("The policy successfully added with policy number: " +result);
	}

	public static void generateReport() throws Exception{
		ApplicationContext ctx = new AnnotationConfigApplicationContext(SpringConfig.class);
		InsuranceService insuranceService = ctx.getBean(InsuranceServiceImpl.class);
		String insuranceType = "Term Life Insurance";
		
		System.out.println("Policy Holder Name\tPolicy Number\tAge\tTenure(in months)");
		insuranceService.getReport(insuranceType)
		.forEach(i -> 
		System.out.println(i.getPolicyHolderName() + "\t\t\t" + 
		i.getPolicyNumber() + "\t" + 
		i.getPolicyHolderAge().toString() + "\t\t" + 
		i.getTenureInMonths()));
	}
}

