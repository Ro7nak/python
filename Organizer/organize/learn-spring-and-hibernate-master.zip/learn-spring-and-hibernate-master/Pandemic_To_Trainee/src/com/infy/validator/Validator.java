package com.infy.validator;

import com.infy.model.Trainee;


public class Validator {

	public static void validate(Trainee trainee) throws Exception {		
		if(!validateTrainee(trainee))
			throw new Exception("Validator.INVALID_DETAIL");
	}

	public static Boolean validateTrainee(Trainee trainee) throws Exception {
		Boolean isValid = false;
		if(trainee.getId().toString().length() > 0 && trainee.getName().length() > 0)
			isValid = true;
		return isValid;
	}
}
