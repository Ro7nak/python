package com.infy.configuration;

//import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;


//import com.infy.dao.InsuranceDAOImpl;
//simport com.infy.service.InsuranceServiceImpl;


@Configuration
@ComponentScan(basePackages="com.infy.dao com.infy.service")
public class SpringConfig {
	
	/*@Bean
	public InsuranceServiceImpl insuranceService() {
		return new InsuranceServiceImpl();
	}
	
	@Bean
	public InsuranceDAOImpl insuranceDAO() {
		return new InsuranceDAOImpl();
	}*/
}
