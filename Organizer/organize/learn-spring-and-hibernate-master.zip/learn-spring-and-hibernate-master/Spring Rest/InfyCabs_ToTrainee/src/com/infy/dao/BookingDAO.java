package com.infy.dao;

import java.util.List;

import com.infy.exception.DAOTechnicalError;
import com.infy.model.CabBooking;

public interface BookingDAO {

	public Float getEstimateFare(String from,String to) throws DAOTechnicalError;
	public Integer booking(CabBooking booking) throws DAOTechnicalError;
	public List<CabBooking> getdetails(Long mobileNo) throws DAOTechnicalError;
	public Integer updateBooking(Integer bookingId,Long mobileNo) throws DAOTechnicalError;
}
