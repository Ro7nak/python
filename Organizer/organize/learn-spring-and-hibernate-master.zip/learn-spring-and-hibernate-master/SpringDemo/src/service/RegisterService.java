package service;

import org.springframework.beans.factory.annotation.Autowired;

import validator.Validator;
import dao.RegisterDAO;
import model.Employee;

public class RegisterService {
	@Autowired
	private RegisterDAO dao;
	
	public String registerEmployee(Employee employee){
		Validator.validator(employee);
		System.out.println("Running business logics");
		return dao.registerEmployee(employee);
	}
}
