package com.infy.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "OnetoOne_Trainee")
@GenericGenerator(name = "idGen", strategy = "increment")
public class TraineeEntity {
	@Id
	@GeneratedValue(generator = "idGen")
	@Column(name = "id")
	private Integer traineeId;
	@Column(name = "name")
	private String traineeName;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "machineId", unique = true)
	private DesktopEntity desktopEntity;
	public Integer getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(Integer traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public DesktopEntity getDesktopEntity() {
		return desktopEntity;
	}
	public void setDesktopEntity(DesktopEntity desktopEntity) {
		this.desktopEntity = desktopEntity;
	}
	
	
	
}
