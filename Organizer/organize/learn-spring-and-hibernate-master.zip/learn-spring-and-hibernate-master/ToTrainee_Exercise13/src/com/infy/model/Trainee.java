package com.infy.model;

/**
 * Bean class to hold and transfer Trainee data across the tiers
 * 
 * @author ETA
 */

public class Trainee {

	private Integer traineeId;
	private String traineeName;
	private ClassRoom traineeClassroom;
	public ClassRoom getTraineeClassroom() {
		return traineeClassroom;
	}
	public void setTraineeClassroom(ClassRoom traineeClassroom) {
		this.traineeClassroom = traineeClassroom;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public Integer getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(Integer traineeId) {
		this.traineeId = traineeId;
	}

	
}
