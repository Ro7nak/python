package com.airticketreservation.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.airticketreservation.model.BookingDetails;
import com.airticketreservation.model.Passenger;
import com.airticketreservation.service.CancelTicketService;
import com.airticketreservation.utility.ContextFactory;

@Controller
@PropertySource("classpath:/com/airticketreservation/resources/configuration.properties")
public class PassengerCancelController {
	
	@Autowired
	private Environment environment;

	@RequestMapping(value = { "/myBookings" })
	public ModelAndView ViewMyBookings(@ModelAttribute Passenger customerLogin,
			HttpSession httpSession) throws Exception{

		ModelAndView model = new ModelAndView("TicketCancellation");
		try {

			model.addObject("loginName", httpSession.getAttribute("passengerName"));
			CancelTicketService cancelTicketService = (CancelTicketService) ContextFactory
					.getContext().getBean("cancelTicketService");

			Integer profileId = (Integer) httpSession.getAttribute("userId");

			List<BookingDetails> bookingDetails = cancelTicketService
					.viewMyBookings(profileId);

			model.addObject("bookingDetails", bookingDetails);
			httpSession.setAttribute("bookingDetails", bookingDetails);

		} catch (Exception e) {
			model.addObject("errorMessage",
					environment.getProperty(e.getMessage()));
		} 
		return model;
	}

	@RequestMapping(value = { "/CancelTicket/{bookingId}" })
	public ModelAndView CancelTicket(
			@PathVariable("bookingId") Integer bookingId,
			HttpSession httpSession) {
		ModelAndView model = new ModelAndView("TicketCancellation");
		List<BookingDetails> booking= (List<BookingDetails>) httpSession.getAttribute("bookingDetails");
		

		CancelTicketService cancelTicketService = (CancelTicketService) ContextFactory
				.getContext().getBean("cancelTicketService");
		Integer id = cancelTicketService.cancelTicket(bookingId);

		List<BookingDetails> filteredList = new ArrayList<>();
		for (BookingDetails bookingDetails : booking) {
			
			if(!bookingDetails.getBookingId().equals(bookingId)){
				filteredList.add(bookingDetails);
			}
			
			
			
		}
		
		
		httpSession.setAttribute("bookingDetails", filteredList);
		
		model.addObject("loginName", httpSession.getAttribute("passengerName"));
		
		model.addObject("bookingDetails",filteredList);
		model.addObject(
				"cancellationSuccessMessage",
				environment
						.getProperty("PassengerController.CANCELLATION_SUCCESS_MESSAGE")
						+ id);

		return model;

	}

}
