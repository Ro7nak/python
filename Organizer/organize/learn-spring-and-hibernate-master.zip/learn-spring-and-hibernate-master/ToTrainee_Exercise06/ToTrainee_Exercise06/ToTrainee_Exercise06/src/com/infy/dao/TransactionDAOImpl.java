package com.infy.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.TransactionEntity;
import com.infy.model.Transaction;


@Repository(value="transactionDAO")
public class TransactionDAOImpl implements TransactionDAO {
	@Autowired
	SessionFactory sessionFactory;
	
	public Integer makeTransaction(Transaction transaction) throws Exception {
		Integer result = null;
		Session session = sessionFactory.getCurrentSession();
		
		TransactionEntity transactionEntity = new TransactionEntity();
		transactionEntity.setTransactionDateTime(transaction.getTransactionDateTime());
		transactionEntity.setCustomerId(transaction.getCustomerId());
		transactionEntity.setAmount(transaction.getAmount());
		
		result = (Integer) session.save(transactionEntity);
		return result;
	}

	
	public Transaction getTransactionDetails(Integer transactionId) throws Exception {
		Transaction transaction = new Transaction();
		Session session = sessionFactory.getCurrentSession();
		TransactionEntity transactionEntity = session.get(TransactionEntity.class, transactionId);
		transaction.setTransactionId(transactionEntity.getTransactionId());
		transaction.setTransactionDateTime(transactionEntity.getTransactionDateTime());
		transaction.setCustomerId(transactionEntity.getCustomerId());
		transaction.setAmount(transactionEntity.getAmount());
		return transaction;
	}

}