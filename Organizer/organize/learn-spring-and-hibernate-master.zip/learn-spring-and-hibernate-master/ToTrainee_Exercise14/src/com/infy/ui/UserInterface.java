package com.infy.ui;

import java.util.ArrayList;
import java.util.List;

import com.infy.configuration.AppConfig;
import com.infy.model.Exam;
import com.infy.model.Trainee;
import com.infy.service.EnrolExamService;
import com.infy.utility.ContextFactory;

public class UserInterface {

	public static void main(String args[]) {

		//UserInterface.getTraineeDetails();
		//UserInterface.enrollTraineeForExams();
		//UserInterface.delistTraineeFromExams();
		UserInterface.deleteTraineeDetails();
	}

	public static void getTraineeDetails() {
		try {
			Integer traineeId = 800001;
			EnrolExamService service = (EnrolExamService) ContextFactory
					.getContext().getBean("enrolExamService");

			Trainee trainee = service.getTraineeDetails(traineeId);
			System.out.println("Trainee Details");
			System.out.println("=============================");
			System.out.println("TraineeId \t\t: " + trainee.getTraineeId());
			System.out
					.println("Trainee Name \t\t: " + trainee.getName() + "\n");
			if (trainee.getExamList() != null) {
				for (Exam e : trainee.getExamList()) {
					System.out.println("Exam Id \t\t: " + e.getExamId());
					System.out.println("Details \t\t: " + e.getDetails());
					System.out.println("*******************************");
				}
			}
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void enrollTraineeForExams() {
		try {

			List<String> examIdL = new ArrayList<String>();
			examIdL.add("FA1 - HO");
			examIdL.add("FA1 - OBJ");
			//examIdL.add("FA2 - OBJ");
			Integer traineeId = 800003;
			String message = null;

			EnrolExamService service = (EnrolExamService) ContextFactory
					.getContext().getBean("enrolExamService");

			String name = service.enrollTraineeForExams(traineeId, examIdL);

			message = AppConfig.PROPERTIES
					.getProperty("UserInterface.EXAM_DETAILS_UPDATED_SUCCESS")
					+ " " + name;

			System.out.println(message);

		} catch (Exception e) {
			e.printStackTrace();
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void delistTraineeFromExams() {
		try {

			List<String> examIdL = new ArrayList<String>();
			examIdL.add("FA2 - OBJ");
			examIdL.add("FA1 - OBJ");

			Integer traineeId = 800002;
			String message = null;

			EnrolExamService service = (EnrolExamService) ContextFactory
					.getContext().getBean("enrolExamService");

			String name = service.delistTraineeFromExams(traineeId, examIdL);

			message = name
					+ " "
					+ AppConfig.PROPERTIES
							.getProperty("UserInterface.EXAM_DEREGISTER_SUCCESS");

			System.out.println(message);
		} catch (Exception e) {
			// e.printStackTrace();
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void deleteTraineeDetails() {
		try {

			Integer traineeId = 800003;
			String message = null;

			EnrolExamService service = (EnrolExamService) ContextFactory
					.getContext().getBean("enrolExamService");

			String name = service.deleteTraineeDetails(traineeId);

			message = AppConfig.PROPERTIES
					.getProperty("UserInterface.TRAINEE_DELETED_SUCCESS");

			System.out.println(name + " " + message);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

}
