package com.infy.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

//Strictly follow class diagram
@Entity
@Table(name = "Customer")
public class CustomerEntity {
	
	// Your code goes here
	@Id
	private Integer customerId;
	
	@Column(name = "name")
	private String customerName;
	
	private Long mobileNo;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "loanId", unique = true)
	private LoanEntity loan;

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public LoanEntity getLoan() {
		return loan;
	}

	public void setLoan(LoanEntity loan) {
		this.loan = loan;
	}
	
	
	
}
