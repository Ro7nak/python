package com.infy.dao;

import java.util.List;

import com.infy.model.Author;

public interface AuthorDAO {

	
	public Boolean checkEmailAvailability(String emailId) throws Exception;
	public Boolean checkBookAvailability(String bookId) throws Exception;
	public Integer addAuthor(Author author) throws Exception;
	public List<Author>  getAuthorDetails(String qualification) throws Exception;
	
}
