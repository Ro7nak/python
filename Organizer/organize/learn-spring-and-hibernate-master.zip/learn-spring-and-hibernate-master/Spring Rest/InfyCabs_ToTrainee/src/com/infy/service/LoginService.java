package com.infy.service;


import com.infy.model.UserLogin;

public interface LoginService {
	
	public String login(UserLogin user) throws Exception;
	public String changePassword(String oldPassword,String confirmPassword,String newPassword,Long mobileNo)throws Exception;
	

}