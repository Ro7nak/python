package com.infy.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;



@Component
@Scope("prototype")
@Entity
@Table(name="userlogin")
public class UserLoginEntity {
	@Id
	@Column(name="mobilenumber")
	private Long loginMobileNo;
	private String password;
	
	public Long getLoginMobileNo() {
		return loginMobileNo;
	}
	public void setLoginMobileNo(Long loginMobileNo) {
		this.loginMobileNo = loginMobileNo;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
