package test_1;

public class Strings {
	
	
	
public static void main(String[] args) {

	String a="";
	String b="";
	
	a="i am tring ";
	b="first time ";
	
	System.out.println(a+b);
	System.out.println(a.concat(b));
	System.out.println(a.substring(1, 4));
	
}


}
