package com.infy.service;

import java.util.List;










import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.LoanDAO;
import com.infy.model.Customer;
import com.infy.model.Loan;
import com.infy.validator.Validator;

@Service(value = "loanService")
@Transactional(readOnly = true)
public class LoanServiceImpl implements LoanService {
	@Autowired
	private LoanDAO loanDAO;

	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Integer applyLoan(Loan loan, Integer customerId) throws Exception {

		// Your code goes here
		Integer result = null;
		Validator.validate(loan);
		Integer loanId = loanDAO.checkLoanAllotment(customerId);
		if(loanId == null)
			throw new Exception("Service.CUSTOMER_UNAVAILABLE");
		if(loanId != 0)
			throw new Exception("Service.LOAN_ALREADY_TAKEN");
		result = loanDAO.applyLoan(loan, customerId);
		return result;

	}

	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public List<Customer> getReportByLoanType(String loanType) throws Exception {

		// Your code goes here
		List<Customer> customerList = null;
		customerList = loanDAO.getReportByLoanType(loanType);
		if(customerList == null)
			throw new Exception("Service.NO_LOAN_FOUND");
		return customerList;
	}

	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public List<Integer> closeLoan(String startsWith) throws Exception {

		// Your code goes here

		List<Integer> loanIdList = null;
		loanIdList = loanDAO.closeLoan(startsWith);
		if(loanIdList == null)
			throw new Exception("Service.NO_LOAN_FOUND");
		return loanIdList;

	}

}
