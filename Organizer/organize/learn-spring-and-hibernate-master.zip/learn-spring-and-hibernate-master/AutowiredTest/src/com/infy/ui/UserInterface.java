package com.infy.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.gaurav.model.Customer;
import com.gauravssnl.configuration.SpringConfig;

public class UserInterface {

	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(SpringConfig.class);
		Customer c = (Customer) ctx.getBean(Customer.class);
		System.out.println(c.getAddress().getAddress()); // output = null
		System.out.println(c.getAddress().getId()); // output = null
	}

}
