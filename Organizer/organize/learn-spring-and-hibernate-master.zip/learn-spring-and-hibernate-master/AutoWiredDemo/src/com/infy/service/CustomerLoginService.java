package com.infy.service;

import com.infy.model.CustomerLogin;

public interface CustomerLoginService {
	public Boolean authenticateCustomer(CustomerLogin customerLogin ) throws Exception;
}
