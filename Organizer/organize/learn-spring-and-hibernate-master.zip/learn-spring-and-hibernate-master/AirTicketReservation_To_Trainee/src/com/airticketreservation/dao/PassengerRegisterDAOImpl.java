package com.airticketreservation.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.airticketreservation.entity.PassengerEntity;
import com.airticketreservation.model.Passenger;

@Repository
public class PassengerRegisterDAOImpl implements PassengerRegisterDAO {
	@Autowired
	SessionFactory sessionFactory;
	// don't tamper the signature
	public Integer addNewPassenger(Passenger passenger)
			throws Exception {

		// Your code goes here
		Integer result = null;
		Session session = sessionFactory.getCurrentSession();
		PassengerEntity passengerEntity = new PassengerEntity();
		passengerEntity.setPassengerName(passenger.getPassengerName());
		passengerEntity.setContactNumber(passenger.getContactNumber());
		passengerEntity.setEmailid(passenger.getEmailid());
		passengerEntity.setGender(passenger.getGender());
		passengerEntity.setPassword(passenger.getPassword());
		passengerEntity.setAge(passenger.getAge());
		result = (Integer) session.save(passengerEntity);
		return result;
	}

}
