package com.airticketreservation.service;

import com.airticketreservation.model.Passenger;

public class ViewProfileServiceImpl implements ViewProfileService {

	// don't tamper the signature
	public Passenger viewProfile(Integer userId) throws Exception {

		// Your code goes here
		return null;

	}

}
