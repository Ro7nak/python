package com.infy.service;

import com.infy.model.Trainee;

public interface ClassRoomAllocationService {

	public Trainee getAllocationDetails(Integer traineeId) throws Exception;

	public Integer addNewTrainee(Trainee trainee) throws Exception;

	public Integer updateClassRoomDetails(Integer traineeId, String classRoomId) throws Exception;

	public String deleteTraineeDetails(Integer traineeId) throws Exception;

}
