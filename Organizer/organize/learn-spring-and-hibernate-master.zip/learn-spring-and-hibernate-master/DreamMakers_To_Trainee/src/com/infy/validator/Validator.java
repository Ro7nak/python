package com.infy.validator;

import com.infy.model.Movie;

public class Validator {

	public static void validate(Movie movie) throws Exception {
		if(!validateMovie(movie))
			throw new Exception("Validator.INVALID_NAMES");
	}

	public static Boolean validateMovie(Movie movie) throws Exception {
		Boolean isValid = false;
		if(!(movie.getMovieName().matches("^[\\s]+$")) && !movie.getDirector().getDirectorName().matches("^[\\s]+$"))
			isValid = true;
		return isValid;
	}
}
