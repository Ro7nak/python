package com.infy.service;

import com.infy.model.Desktop;
import com.infy.model.Trainee;

public interface DesktopAllocationService {

	public Trainee getAllocationDetails(Integer traineeId) throws Exception;

	public Integer addNewTrainee(Trainee trainee) throws Exception;

	public void allocateExistingDesktop(Integer traineeId, String machineName) throws Exception;

	public String allocateNewDesktop(Integer traineeId, Desktop desktop) throws Exception;

	public String deallocateDesktop(Integer traineeId) throws Exception;

	public String deleteTraineeOnly(Integer traineeId) throws Exception;

	public void deleteTraineeAndDesktop(Integer traineeId) throws Exception;

}
