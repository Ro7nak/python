package com.infy.test;

import static org.mockito.Mockito.when;
import static org.mockito.Matchers.*;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.infy.dao.LoanDAO;
import com.infy.model.Customer;
import com.infy.model.Loan;
import com.infy.service.LoanService;
import com.infy.service.LoanServiceImpl;
import com.infy.validator.Validator;

@RunWith(MockitoJUnitRunner.class)
public class LoanServiceTest {
	//DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	@Mock
	private LoanDAO loanDAO;
	
	@InjectMocks
	private LoanService loanService = new LoanServiceImpl();
	
	@Rule
	public ExpectedException ee = ExpectedException.none();
	
	@Test
	public void applyLoanInValidLoanTypeTest() throws Exception {
		Loan loan = new Loan();
		loan.setLoanAmount(3000000.0);
		loan.setLoanType("PersonalLoan");
		Integer customerId = 2004;
		ee.expectMessage("Validator.INVALID_LOANTYPE");
		loanService.applyLoan(loan, customerId);
	}
	//DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	@Test
	public void applyLoanCustomerUnAvailableTest() throws Exception {
		Loan loan = new Loan();
		loan.setLoanAmount(2000000.0);
		loan.setLoanType("HomeLoan");
		Integer customerId = 2004;
		when(loanDAO.checkLoanAllotment(customerId)).thenReturn(null);
		ee.expectMessage("Service.CUSTOMER_UNAVAILABLE");
		loanService.applyLoan(loan, customerId);
	}
	//DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	@Test
	public void applyLoanLoanAlreadyTakenTest() throws Exception {
		Loan loan = new Loan();
		loan.setLoanAmount(2000000.0);
		loan.setLoanType("HomeLoan");
		Integer customerId = 2004;
		when(loanDAO.checkLoanAllotment(customerId)).thenReturn(22);
		ee.expectMessage("Service.LOAN_ALREADY_TAKEN");
		loanService.applyLoan(loan, customerId);
	}

}
