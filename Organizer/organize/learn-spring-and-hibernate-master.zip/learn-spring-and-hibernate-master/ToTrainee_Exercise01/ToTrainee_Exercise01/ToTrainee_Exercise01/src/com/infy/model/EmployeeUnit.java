package com.infy.model;

public enum EmployeeUnit {
	 EASSAP,ECSADMC, ORCALL, DNA, ENGCR
	 }