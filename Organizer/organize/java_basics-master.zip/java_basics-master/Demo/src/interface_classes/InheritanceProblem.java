package interface_classes;

public class InheritanceProblem implements Greeting, GreetingExtn{

	public static void main(String[] args) {
		new InheritanceProblem().hello();

	}

}
