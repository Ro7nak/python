package com.infy.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;



@Configuration
@EnableAspectJAutoProxy(proxyTargetClass=true)
@ComponentScan(basePackages="com.infy.dao com.infy.service com.infy.utility")
public class SpringConfig {
	
	/*@Bean
	public InsuranceServiceImpl insuranceService() {
		return new InsuranceServiceImpl();
	}
	
	@Bean
	public InsuranceDAOImpl insuranceDAO() {
		return new InsuranceDAOImpl();
	}*/
}
