package com.airticketreservation.service;

import java.util.List;

import com.airticketreservation.model.BookingDetails;

public interface CancelTicketService {
	
	public List<BookingDetails> viewMyBookings(Integer profileId) throws Exception;
	public Integer cancelTicket(Integer bookingId);
		
	
}
