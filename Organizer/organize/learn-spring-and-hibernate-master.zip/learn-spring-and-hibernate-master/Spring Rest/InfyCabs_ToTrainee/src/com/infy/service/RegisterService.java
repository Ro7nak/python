package com.infy.service;

import com.infy.exception.DAOTechnicalError;
import com.infy.exception.InvalidCustomerDataException;
import com.infy.model.UserDetail;

public interface RegisterService {
	public String register(UserDetail detail) throws DAOTechnicalError,InvalidCustomerDataException;
}
