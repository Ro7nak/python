package com.airticketreservation.validator;

import com.airticketreservation.model.Passenger;

public class PassengerValidator {
	// don't tamper the signature
	public static void validatePassengerDetails(Passenger passenger)
			throws Exception {
		if(!validateName(passenger.getPassengerName()))
			throw new Exception("PassengerValidator.INVALID_PASSENGER_NAME");
		if(!validateEmail(passenger.getEmailid()))
			throw new Exception("PassengerValidator.INVALID_EMAIL");
		if(!validatePassword(passenger.getPassword()))
			throw new Exception("PassengerValidator.INVALID_PASSWORD");
		if(!validateContactNumber(passenger.getContactNumber()))
			throw new Exception("PassengerValidator.INVALID_CONTACTNUMBER");
	}

	// don't tamper the signature
	public static Boolean validateContactNumber(String contactNumber) {
		Boolean isValid = false;
		String pattern1 = "\\d{10}";
		String pattern2 = contactNumber.charAt(0) + "{10}";
		if(contactNumber.matches(pattern1) && !contactNumber.matches(pattern2))
			isValid = true;
		return isValid;
	}

	// don't tamper the signature
	public static Boolean validateEmail(String emailId) {
		Boolean isValid = false;
		String pattern = "^[A-Za-z][\\w]*@[A-Za-z]+.[A-Za-z]+$";
		if(emailId.matches(pattern))
			isValid = false;
		return isValid;
	}

	// don't tamper the signature
	public static Boolean validateName(String name) {
		Boolean isValid = false;
		String pattern = "[A-Z]([A-Za-z]+ )*([A-Za-z]+)*";
		if(name.matches(pattern))
			isValid = false;
		return isValid;
	}

	// don't tamper the signature
	public static Boolean validatePassword(String password) {
		Boolean isValid = false;
		String pattern1 = ".*[A-Z].*";
		String pattern2 = ".*[a-z].*";
		String pattern3 = ".*[0-9].*";
		String pattern4 = ".*[!#$%\\^&*()@].*";
		if(password.matches(pattern1) && password.matches(pattern2) && 
				password.matches(pattern3) && password.matches(pattern4))
			isValid = true;
		System.out.println(isValid);
		return isValid;
	}
}
