package com.infy.exception;


public class InvalidServiceAreaException extends Exception {

	private static final long serialVersionUID = 1L;

	public InvalidServiceAreaException(String message) {
		super(message);
	}
}
