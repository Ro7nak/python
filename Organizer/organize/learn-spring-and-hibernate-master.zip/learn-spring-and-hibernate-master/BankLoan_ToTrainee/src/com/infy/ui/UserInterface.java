package com.infy.ui;

import java.util.List;

import com.infy.configuration.AppConfig;
import com.infy.model.Customer;
import com.infy.model.Loan;
import com.infy.service.LoanService;
import com.infy.utility.ContextFactory;



public class UserInterface {
	static LoanService service = (LoanService) ContextFactory
			.getContext().getBean("loanService");

	public static void main(String[] args) {
			//applyLoan();
			getReportByLoanType();
			//closeLoan();
		
	}
	
	public static void applyLoan() 
	{
		try 
		{
			Integer customerId=2004;
			
			Loan loan=new Loan();
			loan.setLoanAmount(2000000.0);
			loan.setLoanType("HomeLoan");
						
			Integer loanId = service.applyLoan(loan, customerId);
			
			System.out.println(AppConfig.PROPERTIES.getProperty("UserInterface.ALLOCATE_SUCCESS")+loanId);
			
		} catch (Exception e) {
			
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			if (message == null) {
				message = AppConfig.PROPERTIES.getProperty("General.EXCEPTION");
			}
			System.out.println("ERROR:" + message);
		}	
	}
	

	public static void getReportByLoanType() 
	{
		String loanType="carloan";
		try 
		{
			List<Customer> customerDetails=service.getReportByLoanType(loanType);
			
			System.out.println("List of customers");
			System.out.println("==================");
			System.out.println("CustomerId   CustomerName    LoanId    LoanAmount      EMI");
			System.out.println("===========================================================");
			for (Customer customer : customerDetails) 
			{
				System.out.printf("%-15d%-15s%-10d%-15.1f%-15.1f",customer.getCustomerId(),customer.getCustomerName(),customer.getLoan().getLoanId(),customer.getLoan().getLoanAmount(),customer.getEmi());
				System.out.println();
			}
					
		} catch (Exception e) {
			
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			if (message == null) {
				message = AppConfig.PROPERTIES.getProperty("General.EXCEPTION");
			}
			System.out.println("ERROR:" + message);
		}
	}


	public static void closeLoan() 
	{
		String customerName="M";
		List<Integer> loanIds=null;
		try 
		{
			loanIds=service.closeLoan(customerName);
			System.out.println("Closed LoanId's are");
			for(Integer loanId:loanIds)
			{
				System.out.println(loanId);
			}			
		} 
		catch (Exception e) 
		{
			
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			if (message == null) 
			{
				message = AppConfig.PROPERTIES.getProperty("General.EXCEPTION");
			}
			System.out.println("ERROR:" + message);
		}
		
	}
	
}
