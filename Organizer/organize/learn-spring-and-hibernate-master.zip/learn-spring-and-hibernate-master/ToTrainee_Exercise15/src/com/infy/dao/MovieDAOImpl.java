package com.infy.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.MovieEntity;
import com.infy.model.Movie;

@Repository(value = "movieDAO")
public class MovieDAOImpl implements MovieDAO {
	@Autowired
	SessionFactory sessionFactory;

	public List<Movie> getMovieByImdbRating(Double fromRating, Double toRating) throws Exception {
		List<Movie> movieList = new ArrayList<Movie>();
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		CriteriaQuery<MovieEntity> criteriaQuery = criteriaBuilder.createQuery(MovieEntity.class);
		Root<MovieEntity> root = criteriaQuery.from(MovieEntity.class);
		
		// select all columns 
		criteriaQuery.select(root);
		criteriaQuery.where(criteriaBuilder.between(root.get("imdbRating"),
				fromRating, toRating));

		Query query = session.createQuery(criteriaQuery);
		List<MovieEntity> movieEntityList = query.getResultList();
		for (MovieEntity movieEntity : movieEntityList) {
			Movie movie = new Movie();
			movie.setMovieId(movieEntity.getMovieId());
			movie.setMovieName(movieEntity.getMovieName());
			movie.setDirectorName(movieEntity.getDirectorName());
			movie.setImdbRating(movieEntity.getImdbRating());
			movie.setYear(movieEntity.getYear());
			movieList.add(movie);
		}

		return movieList;
	}

	
	public Movie getMovieDetails(String movieName) throws Exception {
		Movie movie = null;
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		CriteriaQuery<MovieEntity> criteriaQuery = criteriaBuilder.createQuery(MovieEntity.class);
		Root<MovieEntity> root = criteriaQuery.from(MovieEntity.class);
		criteriaQuery.select(root);
		criteriaQuery.where(criteriaBuilder.equal(root.get("movieName"),
				movieName));
		Query query = session.createQuery(criteriaQuery);
		MovieEntity movieEntity = (MovieEntity) query.getSingleResult();
		if (movieEntity != null) {
			movie = new Movie();
			movie.setMovieId(movieEntity.getMovieId());
			movie.setMovieName(movieEntity.getMovieName());
			movie.setDirectorName(movieEntity.getDirectorName());
			movie.setImdbRating(movieEntity.getImdbRating());
			movie.setYear(movieEntity.getYear());
		}
		
		return movie;
	}


	@Override
	public List<Object[]> getMoviesNameAndYear(String directorName,
			Double toRating) throws Exception {
		// TODO Auto-generated method stub
		List<Object[]> moviesnameAndYearList = new ArrayList<Object[]>();

		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		CriteriaQuery<Object[]> criteriaQuery = criteriaBuilder.createQuery(Object[].class);
		Root<MovieEntity> root = criteriaQuery.from(MovieEntity.class);
		
		criteriaQuery.multiselect(root.get("year"), root.get("movieName"))
		.where(criteriaBuilder.and(
				criteriaBuilder.equal(root.get("directorName"), directorName),
				criteriaBuilder.ge(root.get("imdbRating"), toRating)));
		Query query = session.createQuery(criteriaQuery);
		moviesnameAndYearList = query.getResultList();

		return moviesnameAndYearList;
	}


	@Override
	public List<String> getMoviesByDirectorName(String directorName)
			throws Exception {
		// TODO Auto-generated method stub
		List<String> movieNamesList = null;
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<MovieEntity> root = criteriaQuery.from(MovieEntity.class);
		criteriaQuery.select(root.get("movieName"))
		.where(criteriaBuilder.equal(root.get("directorName"), directorName));
		Query query = session.createQuery(criteriaQuery);
		movieNamesList = query.getResultList();
		return movieNamesList;
	}

}
