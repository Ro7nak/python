package com.infy.service;

import java.util.List;
import java.util.Map;

import com.infy.model.Movie;

public interface MovieService {

public Movie getMovieDetails(String movieName) throws Exception;
	
	public List<Movie> getMovieByImdbRating(Double fromRating, Double toRating) throws Exception;

	public List<Object[]> getMoviesNameAndYear(String directorName, Double toRating) throws Exception;

	public List<String> getMoviesByDirectorName(String directorName) throws Exception;

}
