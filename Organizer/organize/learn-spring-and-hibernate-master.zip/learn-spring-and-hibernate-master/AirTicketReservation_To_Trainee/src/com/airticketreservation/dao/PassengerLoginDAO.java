package com.airticketreservation.dao;

import com.airticketreservation.model.Passenger;

public interface PassengerLoginDAO {
	
	public Passenger getPassengerLoginByLoginName(Passenger passenger);
	
	
}
