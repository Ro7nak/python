package com.airticketreservation.entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "Booking_Details")
@GenericGenerator(name = "bookingIdGen", 
strategy = "sequence",
parameters = {@Parameter(name = "sequence_name", value = "passenger_sequence")})
public class BookingDetailsEntity {
	@Id
	@GeneratedValue(generator = "bookingIdGen")
	private Integer bookingId;
	private LocalDate bookingDate;
	private Integer amount;
	private Integer noOfseats;
	private String status;
	public Integer getBookingId() {
		return bookingId;
	}
	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}
	public LocalDate getBookingDate() {
		return bookingDate;
	}
	public void setBookingDate(LocalDate bookingDate) {
		this.bookingDate = bookingDate;
	}
	public Integer getAmount() {
		return amount;
	}
	public void setAmount(Integer amount) {
		this.amount = amount;
	}
	public Integer getNoOfseats() {
		return noOfseats;
	}
	public void setNoOfseats(Integer noOfseats) {
		this.noOfseats = noOfseats;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
