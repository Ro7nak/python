package com.infy.test;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.infy.configuration.SpringConfig;
import com.infy.model.CustomerLogin;
import com.infy.service.CustomerLoginService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {SpringConfig.class})
public class CustomerLoginServiceTest {

	@Autowired
	CustomerLoginService customerLoginService;

	@Test
	public void authenticateCustomerLoginValidCredentials() throws Exception {

		CustomerLogin c = new CustomerLogin();

		c.setLoginName("tom");

		c.setPassword("tom123");

		Boolean b = customerLoginService.authenticateCustomerLogin(c);

		Assert.assertTrue(b);

	}

}