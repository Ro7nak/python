package com.infy.ui;

import org.hibernate.Session;

import com.infy.configuration.AppConfig;
import com.infy.model.Desktop;
import com.infy.model.Trainee;
import com.infy.service.DesktopAllocationService;
import com.infy.utility.ContextFactory;

public class UserInterface {

	public static void main(String args[]) {
		Session session = null;
		 //UserInterface.getAllocationDetails();
		 //UserInterface.addNewTraineeOnly();
		 //UserInterface.addNewTraineeAndNewDesktop();
		 //UserInterface.allocateExistingDesktop();
		//UserInterface.allocateNewDesktop();
		//UserInterface.deallocateDesktop() ;
		 //UserInterface.deleteTraineeOnly();
		 UserInterface.deleteTraineeAndDesktop();
	}

	public static void getAllocationDetails() {
		try {
			Integer traineeId = 800001;

			DesktopAllocationService service = (DesktopAllocationService) ContextFactory
					.getContext().getBean("desktopAllocationService");
			Trainee trainee = service.getAllocationDetails(traineeId);

			System.out.println("Trainee Details");
			System.out.println("-------------------");
			System.out.println("TraineeId \t\t:" + trainee.getTraineeId());
			System.out.println("Trainee Name \t\t:" + trainee.getTraineeName());

			if (trainee.getDesktop() != null) {
				System.out.println("Machine Name \t\t:"
						+ trainee.getDesktop().getMachineName());
				System.out.println("Make \t\t\t:"
						+ trainee.getDesktop().getMake());
			} else {
				System.out.println(AppConfig.PROPERTIES
						.getProperty("UserInterface.Dekstop_Not_Available"));
			}
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
			
		}
	}

	public static void addNewTraineeOnly() {

		try {
			Trainee trainee = new Trainee();
			trainee.setTraineeName("Jill");

			DesktopAllocationService service = (DesktopAllocationService) ContextFactory
					.getContext().getBean("desktopAllocationService");

			Integer traineeId = service.addNewTrainee(trainee);

			System.out.println(AppConfig.PROPERTIES
					.getProperty("UserInterface.NEW_TRAINEE_SUCCESS")
					+ " : "
					+ traineeId);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
			 //e.printStackTrace();
		}
	}

	public static void addNewTraineeAndNewDesktop() {
		try {
			Trainee trainee = new Trainee();
			trainee.setTraineeName("John");

			Desktop desktop = new Desktop();
			desktop.setMachineName("MYSGEC444444D");
			desktop.setMake("IBM");

			trainee.setDesktop(desktop);

			DesktopAllocationService service = (DesktopAllocationService) ContextFactory
					.getContext().getBean("desktopAllocationService");

			Integer traineeId = service.addNewTrainee(trainee);

			String message = AppConfig.PROPERTIES
					.getProperty("UserInterface.NEW_TRAINEE_DESKTOP_SUCCESS");
			System.out.println(message + " : " + traineeId);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
			// e.printStackTrace();
		}
	}

	public static void allocateExistingDesktop() {
		try {

			String machineName = "MYSGEC222222D";
			Integer traineeId = 800002;

			DesktopAllocationService service = (DesktopAllocationService) ContextFactory
					.getContext().getBean("desktopAllocationService");

			service.allocateExistingDesktop(traineeId, machineName);

			System.out
					.println(machineName
							+ " "
							+ AppConfig.PROPERTIES
									.getProperty("UserInterface.EXISTING_DESKTOP_ALLOCATED_SUCCESS")
							+ " " + traineeId);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
			// e.printStackTrace();
		}
	}

	public static void allocateNewDesktop() {
		// TODO Auto-generated method stub
		try {

			Integer traineeId = 800002;

			Desktop desktop = new Desktop();
			desktop.setMachineName("MYSGEC333335D");
			desktop.setMake("IBM");
			String message = null;

			DesktopAllocationService service = (DesktopAllocationService) ContextFactory
					.getContext().getBean("desktopAllocationService");

			service.allocateNewDesktop(traineeId, desktop);

			message = AppConfig.PROPERTIES
					.getProperty("UserInterface.NEW_DESKTOP_ALLOCATED_SUCCESS");

			System.out.println(message + " " + traineeId);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
			// e.printStackTrace();
		}
	}

	public static void deallocateDesktop() {
		try {
			Integer traineeId = 800002;

			DesktopAllocationService service = (DesktopAllocationService) ContextFactory
					.getContext().getBean("desktopAllocationService");

			String name = service.deallocateDesktop(traineeId);

			String message = null;

			message = AppConfig.PROPERTIES
					.getProperty("UserInterface.DESKTOP_DEALLOCATED_SUCCESS")
					+ " " + name;

			System.out.println(message);

		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void deleteTraineeOnly() {
		try {
			Integer traineeId = 800001;
			DesktopAllocationService service = (DesktopAllocationService) ContextFactory
					.getContext().getBean("desktopAllocationService");
			String message = null;
			String name = service.deleteTraineeOnly(traineeId);

			message = name
					+ " "
					+ AppConfig.PROPERTIES
							.getProperty("UserInterface.TRAINEE_DELETED_SUCCESS");

			System.out.println(message);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void deleteTraineeAndDesktop() {
		try {
			Integer traineeId = 800001;
			String message = null;

			DesktopAllocationService service = (DesktopAllocationService) ContextFactory
					.getContext().getBean("desktopAllocationService");

			service.deleteTraineeAndDesktop(traineeId);

			message = AppConfig.PROPERTIES
					.getProperty("UserInterface.TRAINEE_DESKTOP_DELETED_SUCCESS");

			System.out.println(message);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

}
