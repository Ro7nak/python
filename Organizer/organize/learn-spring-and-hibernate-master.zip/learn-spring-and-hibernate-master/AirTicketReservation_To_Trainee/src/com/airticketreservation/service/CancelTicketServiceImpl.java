package com.airticketreservation.service;

import java.util.List;

import com.airticketreservation.model.BookingDetails;

public class CancelTicketServiceImpl implements CancelTicketService {

	// don't tamper the signature
	public List<BookingDetails> viewMyBookings(Integer profileId)
			throws Exception {

		// Your code goes here
		return null;
	}

	// don't tamper the signature
	public Integer cancelTicket(Integer bookingId) {

		// Your code goes here
		return null;

	}

}
