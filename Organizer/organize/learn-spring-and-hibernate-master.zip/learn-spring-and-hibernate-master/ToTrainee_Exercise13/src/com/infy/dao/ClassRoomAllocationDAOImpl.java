package com.infy.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.ClassRoomEntity;
import com.infy.entity.TraineeEntity;
import com.infy.model.ClassRoom;
import com.infy.model.Trainee;

@Repository(value = "classRoomAllocationDAO")
public class ClassRoomAllocationDAOImpl implements ClassRoomAllocationDAO {
	@Autowired
	SessionFactory sessionFactory;

	public Trainee getAllocationDetails(Integer traineeId) throws Exception {
		Trainee trainee= null;
		Session session = sessionFactory.getCurrentSession();
		TraineeEntity traineeEntity = session.get(TraineeEntity.class, traineeId);
		if(traineeEntity != null) {
			trainee = new Trainee();
			trainee.setTraineeId(traineeEntity.getTraineeId());
			trainee.setTraineeName(traineeEntity.getTraineeName());
			ClassRoom classRoom = null;
			if(traineeEntity.getTraineeClassRoom() != null) {
				classRoom = new ClassRoom();
				classRoom.setClassRoomId(traineeEntity.getTraineeClassRoom().getClassRoomId());
				classRoom.setSeatingCapacity(traineeEntity.getTraineeClassRoom().getSeatingCapacity());
				trainee.setTraineeClassroom(classRoom);
			}
		}
		return trainee;
	}

	public Integer addNewTrainee(Trainee trainee) throws Exception {
		Integer id = null;
		Session session = sessionFactory.getCurrentSession();
		TraineeEntity traineeEntity = new TraineeEntity();
		traineeEntity.setTraineeName(trainee.getTraineeName());
		
		ClassRoomEntity classRoomEntity = null;
		
		if(trainee.getTraineeClassroom() != null) {
			
			classRoomEntity = session.get(ClassRoomEntity.class, trainee.getTraineeClassroom().getClassRoomId());
			
			if(classRoomEntity == null){
				classRoomEntity = new ClassRoomEntity();
				classRoomEntity.setClassRoomId(trainee.getTraineeClassroom().getClassRoomId());
				classRoomEntity.setSeatingCapacity(trainee.getTraineeClassroom().getSeatingCapacity());
				session.persist(classRoomEntity);
			}
		}
		
		traineeEntity.setTraineeClassRoom(classRoomEntity);
		id = (Integer) session.save(traineeEntity);
		
		return id;
	}

	public Integer updateClassRoomDetails(Integer traineeId, String classRoomId)
			throws Exception {
		Integer result = null;
		Session session = sessionFactory.getCurrentSession();
		TraineeEntity traineeEntity = session.get(TraineeEntity.class, traineeId);
		ClassRoomEntity classRoomEntity = session.get(ClassRoomEntity.class, classRoomId);
		if(traineeEntity != null) {
			if(classRoomEntity != null) {
				result = 1;
				traineeEntity.setTraineeClassRoom(classRoomEntity);
			}
			
			else 
				result = -1;
		}
		else
			result = 0;
		return result;
	}

	public String deleteTraineeDetails(Integer traineeId) throws Exception {
		String result = null;
		Session session = sessionFactory.getCurrentSession();
		TraineeEntity traineeEntity = session.get(TraineeEntity.class, traineeId);
		if(traineeEntity != null) {
			traineeEntity.setTraineeClassRoom(null);
			result = traineeEntity.getTraineeName();
			session.delete(traineeEntity);
		}
		return result;
	}
}
