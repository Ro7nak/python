package com.infy.ui;

import java.time.LocalDate;

import com.infy.configuration.AppConfig;
import com.infy.model.Transaction;
import com.infy.service.TransactionService;
import com.infy.utility.ContextFactory;

public class UserInterface {

	static TransactionService transactionService = (TransactionService) ContextFactory
			.getContext().getBean("transactionService");

	public static void main(String[] args) throws Exception {

		UserInterface.makeTransaction();
		//UserInterface.getTransactionDetails();

	}

	public static void getTransactionDetails() {
		try {

			Transaction transaction = transactionService
					.getTransactionDetails(1004);

			System.out.println("Transaction Details");
			System.out.println("-------------------");
			System.out.println("Transaction id \t\t:"
					+ transaction.getTransactionId());
			System.out.println("Customer Id \t\t:"
					+ transaction.getCustomerId());
			System.out.println("Transaction Amount \t:"
					+ transaction.getAmount());

		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
			System.out.println(e);
			
		}

	}

	public static void makeTransaction() {
		try {
			TransactionService transactionService = (TransactionService) ContextFactory
					.getContext().getBean("transactionService");

			Transaction transaction = new Transaction();
			transaction.setCustomerId("C5001");
			transaction.setTransactionDateTime(LocalDate.now());
			transaction.setAmount(150.40d);

			Integer transactionId = transactionService
					.makeTransaction(transaction);

			System.out.println("Transaction is successfull with id : "
					+ transactionId);

		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
			
		}
	}
}
