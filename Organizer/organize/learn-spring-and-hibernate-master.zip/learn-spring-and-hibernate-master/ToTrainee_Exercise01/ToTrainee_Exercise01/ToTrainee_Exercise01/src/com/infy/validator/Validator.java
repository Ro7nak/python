package com.infy.validator;

public class Validator {
	public static void validateEmailId(String emailId) throws Exception {
		Boolean isValid = false;
		String pattern = "[\\w]+@[A-Za-z]+.[A-Za-z]";
		if(emailId.matches(pattern))
			isValid = true;
		if(!isValid)
			throw new Exception("Validator.Invalid_EmailId");
	}

	public static void validateEmployeeId(String employeeId) throws Exception {
		Boolean isValid = false;
		if(employeeId.matches("\\d{4}"))
			isValid = true;
		if(!isValid)
			throw new Exception("Validator.Invalid_EmployeeId");
	}
}
