package com.gaurav.model;

import org.springframework.beans.factory.annotation.Autowired;

public class Customer {
	@Autowired
	private Address address;
	public Customer() {
		System.out.println("Customer constructor");
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
}
