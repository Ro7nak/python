package threads;

public class DataContainer {

	private int intData;

	public int get() {
		return intData;
	}

	public void put(int value) {
		this.intData = value;
	}
	
	
}
