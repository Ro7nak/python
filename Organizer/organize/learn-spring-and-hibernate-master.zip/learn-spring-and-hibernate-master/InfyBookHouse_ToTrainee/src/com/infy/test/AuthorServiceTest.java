package com.infy.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;

import static org.mockito.Mockito.when;
import static org.mockito.Matchers.*;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.infy.dao.AuthorDAO;
import com.infy.model.Author;
import com.infy.model.Book;
import com.infy.service.AuthorService;
import com.infy.service.AuthorServiceImpl;
import com.infy.validator.Validator;

@RunWith(MockitoJUnitRunner.class)
public class AuthorServiceTest {
	@Mock
	private AuthorDAO authorDAO;
	@InjectMocks
	private AuthorService authorService = new AuthorServiceImpl();
	
	@Rule
	public ExpectedException ee = ExpectedException.none();
	
	@Test
	public void addAuthorInvalidBookIDTest() throws Exception {
		Author author = new Author();
		author.setEmailId("Soha@infy.in");
		List<Book> bookList = new ArrayList<Book>();
		Book b1 = new Book();
		b1.setBookId("1011");
		bookList.add(b1);
		author.setBookList(bookList);
		ee.expect(Exception.class);
		ee.expectMessage("Validator.INVALID_BOOKID");
		authorService.addAuthor(author);
	}
	
	@Test
	public void addAuthorEmailIdAlreadyExistsTest() throws Exception {
		Author author = new Author();
		author.setEmailId("Soha@infy.in");
		List<Book> bookList = new ArrayList<Book>();
		Book b1 = new Book();
		b1.setBookId("B1011");
		bookList.add(b1);
		author.setBookList(bookList);
		when(authorDAO.checkEmailAvailability("Soha@infy.in")).thenReturn(true);
		ee.expect(Exception.class);
		ee.expectMessage("Service.EXISTING_EMAIL_ID");
		authorService.addAuthor(author);
	}

	@Test
	public void addAuthorBookAlreadyExistsTest() throws Exception {
		Author author = new Author();
		author.setEmailId("Soha@infy.in");
		List<Book> bookList = new ArrayList<Book>();
		Book b1 = new Book();
		b1.setBookId("B1011");
		bookList.add(b1);
		author.setBookList(bookList);
		when(authorDAO.checkBookAvailability("B1011")).thenReturn(true);
		ee.expect(Exception.class);
		ee.expectMessage("Service.BOOK_ALREADY_EXISTS");
		authorService.addAuthor(author);
	}
}
