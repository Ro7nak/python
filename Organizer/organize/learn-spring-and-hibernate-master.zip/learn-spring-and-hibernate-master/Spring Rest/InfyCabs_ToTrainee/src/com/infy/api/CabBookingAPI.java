package com.infy.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.infy.exception.InvalidDataForBookingException;

import com.infy.exception.InvalidServiceAreaException;
import com.infy.model.CabBooking;
import com.infy.service.BookingService;
import com.infy.service.BookingServiceImpl;
import com.infy.service.LoginService;
import com.infy.utility.ContextFactory;




@RestController
@CrossOrigin
@RequestMapping("cabBookingAPI")
public class CabBookingAPI {
	
	
	@Autowired 
	Environment environment;
	
	@RequestMapping("/Rides/{mobileNo}")
	public ResponseEntity<List<CabBooking>> getYourRidePage(@PathVariable Long mobileNo){
		BookingService bookingService = (BookingService) ContextFactory.getContext().getBean(BookingServiceImpl.class);
		List<CabBooking> cabBookingList = null;
		try {
			cabBookingList = bookingService.getdetails(mobileNo); 
			return new ResponseEntity<List<CabBooking>>(cabBookingList, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<List<CabBooking>>(cabBookingList, HttpStatus.NOT_FOUND);
		}
	}
	
	@RequestMapping(value = "/changePassword/{confirmPassword}", method = RequestMethod.PUT)
	public ResponseEntity<String> changePassword(@RequestParam String oldPassword,@RequestParam String newPassword, @PathVariable String confirmPassword, @RequestParam Long mobileNo){
		String userName = null;
		LoginService loginService = (LoginService)ContextFactory.getContext().getBean("loginService");
		try{
			userName = loginService.changePassword(oldPassword, confirmPassword, newPassword, mobileNo);
			if(userName != null){
				return new ResponseEntity<String>(environment.getProperty("PASSWORD_CHANGED"), HttpStatus.OK);
			}
			else{
				return new ResponseEntity<String>(environment.getProperty("NOT_MATCHING"), HttpStatus.OK);
			}
		}catch (Exception e) {
			return new ResponseEntity<String>(environment.getProperty("ERROR"), HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/makeBooking", method = RequestMethod.POST)
	public ResponseEntity<String> makeBooking(@RequestBody CabBooking cabBooking ,@RequestParam String value){
		Float fare = 0f;
		BookingService bookingService = (BookingService) ContextFactory.getContext().getBean("bookingService");
		ResponseEntity<String> responseEntity = null;
		try {
			fare = bookingService.getEstimateFare(cabBooking.getFrom(), cabBooking.getTo());
			cabBooking.setStatus('B');
			cabBooking.setEstimatedfare(fare);
			if(value.equals("0")){
				if(fare > 0F && cabBooking.getBookingId() == 0){
					responseEntity = new ResponseEntity<String>(environment.getProperty("ESTIMATED_FARE" ) + " " + fare, HttpStatus.OK);
				}
			}
			else if(fare != 0F & value.equals("1")){
				Integer bookingId = 0;
				bookingId = bookingService.booking(cabBooking);
				if(bookingId != 0)
					responseEntity = new ResponseEntity<String>(environment.getProperty("SUCCESSFUL_BOOKING") + " " + bookingId, HttpStatus.OK);
			}
		}catch(InvalidServiceAreaException e){
			responseEntity = new ResponseEntity<String>(environment.getProperty(e.getMessage()), HttpStatus.BAD_REQUEST);
		}catch(InvalidDataForBookingException e){
			responseEntity = new ResponseEntity<String>(environment.getProperty(e.getMessage()), HttpStatus.BAD_REQUEST);
		}catch(Exception e) {
			responseEntity = new ResponseEntity<String>(environment.getProperty("ERROR"), HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}
	
	
	@RequestMapping(value = "/cancelRides/{bookingId}", method = RequestMethod.DELETE)
	public ResponseEntity<String> getCancelRide(@PathVariable Integer bookingId,@RequestParam Long mobileNo){
		BookingService bookingService = (BookingService) ContextFactory.getContext().getBean("bookingService");
		Integer id = null;
		ResponseEntity<String> responseEntity = null;
		try {
			id = bookingService.updateBooking(bookingId, mobileNo);
			if(id != null)
				responseEntity = new ResponseEntity<String>(environment.getProperty("UPDATE_SUCCESS") + " " + id, HttpStatus.OK);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<String>(environment.getProperty(e.getMessage()), HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}
}
