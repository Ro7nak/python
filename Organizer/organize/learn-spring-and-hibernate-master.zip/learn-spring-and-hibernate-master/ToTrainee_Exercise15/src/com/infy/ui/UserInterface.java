package com.infy.ui;

import java.util.List;
import java.util.Map;

import com.infy.configuration.AppConfig;
import com.infy.model.Movie;
import com.infy.service.MovieService;
import com.infy.utility.ContextFactory;

public class UserInterface {

	public static void main(String[] args) {
		getMovieByImdbRating();
		// getMoviesNameAndYear();
		// getMoviesByDirectorName();
		// getMovieDetails();
	}
	public static void getMovieDetails() {
		MovieService movieService = (MovieService) ContextFactory.getContext().getBean("movieService");

		try {

			String movieName = "Deadpool";
			Movie movie = movieService.getMovieDetails(movieName);

			System.out.println(movieName + " " + AppConfig.PROPERTIES.getProperty("UserInterface.MOVIE_DETAILS"));

			System.out.println("-----------------------------");
			System.out.println("Director Name \t" + movie.getDirectorName());
			System.out.println("IMDb Rating \t" + movie.getImdbRating());
			System.out.println("Release Year\t" + movie.getYear());

		} catch (Exception e) {
			System.err.println("Error: " + AppConfig.PROPERTIES.getProperty(e.getMessage()));
			e.printStackTrace();
		}
	}
	private static void getMovieByImdbRating() {
		MovieService movieService = (MovieService) ContextFactory.getContext().getBean("movieService");
		try {

			Double fromRating = 7.0d;
			// Double toRating = 7.8d;// valid
			Double toRating = 8.0d;// Invalid

			List<Movie> movieList = movieService.getMovieByImdbRating(fromRating, toRating);

			System.out.println(AppConfig.PROPERTIES.getProperty("UserInterface.MOVIE_LIST"));
			int count = 1;
			System.out.println("S.No\tIMDB Rating\tYear\tMovie Name\t");
			System.out.println("--------------------------------------------");
			// System.out.println("----\t-----------\t----\t----------");
			for (Movie movie : movieList) {
				System.out.print(" " + count++ + "\t   " + movie.getImdbRating() + "\t\t" + movie.getYear() + "\t" + movie.getMovieName() + "\t");
				System.out.println();
			}
		} catch (Exception e) {
			System.err.println("Error: " + AppConfig.PROPERTIES.getProperty(e.getMessage()));
			e.printStackTrace();
		}
	}

	private static void getMoviesNameAndYear() {
		MovieService movieService = (MovieService) ContextFactory.getContext().getBean("movieService");

		try {
			String directorName = "Joss Whedon";
			Double toRating = 7.3d;
			List<Object[]> movie = movieService.getMoviesNameAndYear(directorName, toRating);

			System.out.println("Year\tMoive Name");
			System.out.println("----\t----------");
			for (Object[] obj : movie) {
				System.out.println(obj[0] + "\t" + obj[1]);
			}
		} catch (Exception e) {
			System.err.println("Error: " + AppConfig.PROPERTIES.getProperty(e.getMessage()));
			e.printStackTrace();
		}
	}

	private static void getMoviesByDirectorName() {
		MovieService movieService = (MovieService) ContextFactory.getContext().getBean("movieService");

		try {

			String directorName = "Tim Miller";
			List<String> movieList = movieService.getMoviesByDirectorName(directorName);

			System.out.println(AppConfig.PROPERTIES.getProperty("UserInterface.MOVIES_DIRECTOR_NAME") + "" + directorName);
			System.out.println("-------------------------------------------");
			for (String movieName : movieList) {
				System.out.println(movieName);
			}

		} catch (Exception e) {
			System.err.println("Error: " + AppConfig.PROPERTIES.getProperty(e.getMessage()));
			e.printStackTrace();
		}
	}

	
}
