package com.gauravssnl.supplier;

import java.util.function.Supplier;

public class SupplierDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		show();
	}
	
	public static void show() {
		Supplier<Integer> supplier = new Supplier<Integer>() {

			@Override
			public Integer get() {
				// TODO Auto-generated method stub
				return 5;
			}
			
		};
		System.out.println(supplier.get());
	}
}
