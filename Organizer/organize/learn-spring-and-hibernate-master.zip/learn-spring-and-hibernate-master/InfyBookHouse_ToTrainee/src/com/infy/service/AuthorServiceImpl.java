package com.infy.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.AuthorDAO;
import com.infy.model.Author;
import com.infy.model.Book;
import com.infy.validator.Validator;

@Service(value = "authorService")
@Transactional(readOnly = true)
public class AuthorServiceImpl implements AuthorService {
	@Autowired
	private AuthorDAO authorDAO;

	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Integer addAuthor(Author author) throws Exception {

		// Your code goes here
		Integer result = null;
		if(!author.getBookList().isEmpty()) {
			for(Book book : author.getBookList())
				Validator.validate(book);
		}
		
		Boolean existingEmail = false;
		existingEmail = authorDAO.checkEmailAvailability(author.getEmailId());
		if(existingEmail)
			throw new Exception("Service.EXISTING_EMAIL_ID");
		
		Boolean existingBook = false;
		if(!author.getBookList().isEmpty()) {
			for(Book book : author.getBookList())
				if(authorDAO.checkBookAvailability(book.getBookId())) {
					existingBook = true;
					break;
				}
					
		}
		
		if(existingBook)
			throw new Exception("Service.BOOK_ALREADY_EXISTS");
		
		result = authorDAO.addAuthor(author);
		return result;
	}

	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public List<Author> getAuthorDetails(String qualification) throws Exception {

		// Your code goes here

		List<Author> authorList =  null;
		authorList = authorDAO.getAuthorDetails(qualification);
		if(authorList == null)
			throw new Exception("Service.AUTHORS_NOT_FOUND");
		return authorList;
	}
}
