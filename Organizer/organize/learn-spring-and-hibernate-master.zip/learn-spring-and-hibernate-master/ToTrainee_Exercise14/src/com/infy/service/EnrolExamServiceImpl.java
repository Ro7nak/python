package com.infy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.EnrolExamDAO;
import com.infy.model.Trainee;

@Service(value = "enrolExamService")
@Transactional(readOnly = true)
public class EnrolExamServiceImpl implements EnrolExamService {
	
	@Autowired
	private EnrolExamDAO enrolExamDAO;
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String enrollTraineeForExams(Integer traineeId, List<String> examIdL)
			throws Exception {
		// TODO Auto-generated method stub
		String result = null;
		result = enrolExamDAO.enrollTraineeForExams(traineeId, examIdL);
		if(result == null)
			throw new Exception("Service.INVALID_TRAINEE_ID");
		if(result == "")
			throw new Exception("Service. EXAMID_NOT_FOUND");
		return result;
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String delistTraineeFromExams(Integer traineeId, List<String> examIdL)
			throws Exception {
		// TODO Auto-generated method stub
		String result = null;
		result = enrolExamDAO.delistTraineeFromExams(traineeId, examIdL);
		if(result == null)
			throw new Exception("Service.INVALID_TRAINEE_ID");
		return result;
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String deleteTraineeDetails(Integer traineeId) throws Exception {
		// TODO Auto-generated method stub
		String result = null;
		result = enrolExamDAO.deleteTraineeDetails(traineeId);
		return result;
	}

	@Override
	public Trainee getTraineeDetails(Integer traineeId) throws Exception {
		// TODO Auto-generated method stub
		Trainee trainee = null;
		trainee = enrolExamDAO.getTraineeDetails(traineeId);
		if(trainee == null)
			throw new Exception("Service.INVALID_TRAINEE_ID");
		return trainee;
	}

	


}
