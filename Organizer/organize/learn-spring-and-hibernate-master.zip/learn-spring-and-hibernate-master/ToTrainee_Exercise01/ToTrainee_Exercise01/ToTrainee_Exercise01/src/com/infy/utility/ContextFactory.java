package com.infy.utility;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;



/**
 * This Context Factory class is used to create object of applicationContext
 * which creates spring container.
 * 
 * @author ETA_JAVA
 *
 */
public class ContextFactory {

	
	
	public static ApplicationContext getContext() {
		ApplicationContext CONTEXT = new AnnotationConfigApplicationContext(com.infy.configuration.SpringConfig.class);
		return CONTEXT;
	}
}
