package com.infy.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.infy.configuration.AppConfig;
import com.infy.configuration.SpringConfig;
import com.infy.model.Desktop;
import com.infy.model.Trainee;
import com.infy.service.DesktopAllocationService;
import com.infy.service.DesktopAllocationServiceImpl;


public class UserInterface {

	public static void main(String[] args) {
		addNewTrainee();
		getAllocationDetails();
	}

	public static void addNewTrainee() {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(SpringConfig.class);
		DesktopAllocationService desktopAllocationService = ctx.getBean(DesktopAllocationServiceImpl.class);
		
		Trainee trainee = new Trainee();
		trainee.setId(1008);
		trainee.setName("Aaditya");
		Desktop desktop = new Desktop();
		desktop.setMachineName("MYSGEC1111112D");
		desktop.setMake("Dell");
		trainee.setDesktop(desktop);
		try {
			Integer result = desktopAllocationService.addNewTrainee(trainee);
			System.out.println(AppConfig.PROPERTIES.getProperty("UserInterface.TRAINEE_ADDED_SUCCESS") + result);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

	public static void getAllocationDetails() {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(SpringConfig.class);
		DesktopAllocationService desktopAllocationService = ctx.getBean(DesktopAllocationServiceImpl.class);
		Integer id = 100;
		
		try {
			Trainee trainee = desktopAllocationService.getAllocationDetails(id);
			System.out.println("Trainee Id: " + trainee.getId() + 
					" Trainee Name: " + trainee.getName() + 
					"\n\tDesktop Details\n____________________________\n\nMachine Name\tMake\n*************\t*****\n"+
					trainee.getDesktop().getMachineName() + "\t" + trainee.getDesktop().getMake());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println(AppConfig.PROPERTIES.getProperty("UserInterface.TRAINEE_DOES_NOT_EXIST"));
		}
	}

}
