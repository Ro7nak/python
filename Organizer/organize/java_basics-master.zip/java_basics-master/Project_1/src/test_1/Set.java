package test_1;

import java.util.HashSet;

public class Set {

	public static void main(String[] args) {
		
		HashSet hs= new HashSet();
		hs.add("rounak");
		hs.add("infy");
		hs.add("hsbc");
		hs.add(123);
		hs.add("pune");
		System.out.println(hs.add("nagpur"));
		System.out.println(hs);
		
		
		
		//Set s = new Set();
		
		
	}
}
