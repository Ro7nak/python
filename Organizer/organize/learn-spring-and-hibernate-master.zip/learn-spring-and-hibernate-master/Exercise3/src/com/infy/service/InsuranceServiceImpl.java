package com.infy.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dao.InsuranceDAO;
import com.infy.model.Policy;
import com.infy.model.PolicyReport;
import com.infy.utility.LogConfig;
import com.infy.validator.Validator;

@Service
public class InsuranceServiceImpl implements InsuranceService{

	@Autowired
	private InsuranceDAO insuranceDAO;
	
	@Override
	public String buyPolicy(Policy policy) throws Exception {
		String result = null;
		try {
			Validator validator = new Validator();
			validator.validate(policy);
			result = insuranceDAO.buyPolicy(policy);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			if(e.getMessage().startsWith("Validator") || e.getMessage().startsWith("Service"))
				LogConfig.getLogger(this.getClass()).error(e.getMessage(), e);
			throw e;
		}
		return result;
	}

	@Override
	public Long calculateAge(LocalDate dateOfBirth) throws Exception {
		
		return dateOfBirth.until(LocalDate.now(), ChronoUnit.MONTHS);
	}
	
	@Override
	public List<PolicyReport> getReport(String policyType) throws Exception {
		List<Policy> policyList = insuranceDAO.getAllPolicyDetails();
		List<PolicyReport> policyReportList = new ArrayList<>();
		for(Policy p : policyList) {
			if(p.getPolicyType().equals(policyType)) {
				PolicyReport policyReport = new PolicyReport();
				policyReport.setPolicyHolderName(p.getPolicyHolderName());
				policyReport.setPolicyNumber(p.getPolicyNumber());
				policyReport.setTenureInMonths(p.getTenureInMonths());
				policyReport.setPolicyHolderAge(calculateAge(p.getDateOfBirth()).doubleValue());
				policyReportList.add(policyReport);
			}
		}
		
		if(policyReportList.isEmpty())
			throw new Exception("Service.NO_RECORD");
		return policyReportList;
	}
	
}
