package com.infy.dao;

import java.util.List;

import com.infy.model.Director;
import com.infy.model.Movie;

public interface MovieDAO {
	public String addDirector(Director director) throws Exception;

	public Integer updateDirector(String directorId, List<Movie> movie) throws Exception;
	

	public Director getDirectorDetails(String directorId) throws Exception;
}
