

package test_1;

public class hello {
public static void main(String[] args) {
	System.out.println("Hello!!!");
	
	String s=  "world";
	System.out.println("Hello "+s);
	System.out.println(s.substring(2));
}

}
