package com.airticketreservation.dao;

import java.time.LocalDate;
import java.util.List;

import com.airticketreservation.model.BookingDetails;
import com.airticketreservation.model.FlightSchedule;

public class BookingDAOImpl implements BookingDAO {

	// don't tamper the signature
	public List<FlightSchedule> searchFlights(String source,
			String destination, LocalDate travelDate) {
		
		// Your code goes here
		return null;

	}

	// don't tamper the signature
	public Integer bookFlights(BookingDetails bookingDetails, Integer userId) {

		// Your code goes here
		return null;
	}

	// don't tamper the signature
	public FlightSchedule getFlightSchedules(String scheduleId) {

		// Your code goes here
		return null;
	}

}
