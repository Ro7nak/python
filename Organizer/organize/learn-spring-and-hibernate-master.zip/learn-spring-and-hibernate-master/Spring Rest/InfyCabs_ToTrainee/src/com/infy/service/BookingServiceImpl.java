package com.infy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.BookingDAO;
import com.infy.exception.DAOTechnicalError;
import com.infy.exception.InvalidDataForBookingException;
import com.infy.exception.InvalidServiceAreaException;
import com.infy.model.CabBooking;

@Service("bookingService")
@Transactional(readOnly=true)
public class BookingServiceImpl implements BookingService{

	@Autowired
	BookingDAO bookingDao;
	@Override
	public Float getEstimateFare(String from,String to)throws DAOTechnicalError,InvalidServiceAreaException{
		Float distance=0f;
		Float fare=0f;
		Float costPerKm=6f;
		try{
			distance=bookingDao.getEstimateFare(from,to);
			fare=distance*costPerKm;
			if(fare<=0){
				throw new InvalidServiceAreaException("BookingService.Invalid_ServiceArea");
			}
			return fare;
		}catch(Exception e){
			throw e;
		}
		
	}
	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Integer booking(CabBooking booking) throws DAOTechnicalError,InvalidDataForBookingException{
		Integer bookingId=0;
		try{
			bookingId=bookingDao.booking(booking);
			if(bookingId<=0){
				throw new InvalidDataForBookingException("BookingService.Invalid_Data");
			}
		}catch(Exception e){
			throw e;
		}return bookingId;
	}
	
	@Override
	public List<CabBooking> getdetails(Long mobileNo) throws DAOTechnicalError,Exception{
		List<CabBooking> bookingDetail=null;
		try{
			bookingDetail=bookingDao.getdetails(mobileNo);
			if(bookingDetail.isEmpty())
				throw new Exception();
			
						}catch(Exception e){
			throw e;
		}return bookingDetail;
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Integer updateBooking(Integer bookingId,Long mobileNo) throws DAOTechnicalError,Exception{
		Integer booking_Id=0;
		try{
			
			booking_Id=bookingDao.updateBooking(bookingId,mobileNo);
			if(booking_Id==null)
				throw new Exception("BookingService.RIDES_NOT_FOUND");
		}catch(Exception e){
				throw e;
		}return booking_Id;
	}

}
