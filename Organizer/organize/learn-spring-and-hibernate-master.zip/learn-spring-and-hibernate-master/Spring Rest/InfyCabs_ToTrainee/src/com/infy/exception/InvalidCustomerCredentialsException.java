package com.infy.exception;


public class InvalidCustomerCredentialsException extends Exception {

	private static final long serialVersionUID = 1L;

	public InvalidCustomerCredentialsException(String message) {
		super(message);
	}
}
