package com.infy.dao;

import org.springframework.stereotype.Repository;

import com.infy.model.Desktop;
import com.infy.model.Trainee;

@Repository
public class DesktopAllocationDAOImpl implements DesktopAllocationDAO {

	public Trainee getAllocationDetails(Integer traineeId) throws Exception {
		Trainee trainee = null;

		if (traineeId == 1001) {
			trainee = new Trainee();
			trainee.setId(traineeId);
			trainee.setName("Aman");
			Desktop desktop = new Desktop();
			desktop.setMachineName("MYSGEC111111D");
			desktop.setMake("Acer");
			trainee.setDesktop(desktop);
		}
		return trainee;
	}

	public Integer addNewTrainee(Trainee trainee) throws Exception {
		return trainee.getId();

	}

}
