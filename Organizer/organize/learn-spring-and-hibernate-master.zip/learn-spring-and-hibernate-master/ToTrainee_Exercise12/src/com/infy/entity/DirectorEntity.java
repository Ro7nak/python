package com.infy.entity;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "Director_Details")
public class DirectorEntity {
	@Id
	private String directorId;
	private String directorName;
	private LocalDate dob;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "Movie_Director_Details",
	joinColumns = @JoinColumn(name = "directorId"),
	inverseJoinColumns = @JoinColumn(name = "movieId", unique = true))
	private List<MovieEntity> moviesList;
	
	public String getDirectorId() {
		return directorId;
	}
	public void setDirectorId(String directorId) {
		this.directorId = directorId;
	}
	public String getDirectorName() {
		return directorName;
	}
	public void setDirectorName(String directorName) {
		this.directorName = directorName;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public List<MovieEntity> getMoviesList() {
		return moviesList;
	}
	public void setMoviesList(List<MovieEntity> moviesList) {
		this.moviesList = moviesList;
	}
	
	
}
