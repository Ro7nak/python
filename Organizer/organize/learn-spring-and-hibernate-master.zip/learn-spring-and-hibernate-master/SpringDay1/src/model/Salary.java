package model;

public class Salary {
	private double basicAllowance;
	private double travelAllowance;
	private double totalsalary;
	public double getBasicAllowance() {
		return basicAllowance;
	}
	public void setBasicAllowance(double basicAllowance) {
		this.basicAllowance = basicAllowance;
	}
	public double getTravelAllowance() {
		return travelAllowance;
	}
	public void setTravelAllowance(double travelAllowance) {
		this.travelAllowance = travelAllowance;
	}
	public double getTotalsalary() {
		setTotalsalary();
		return totalsalary;
	}
	public void setTotalsalary() {
		this.totalsalary = basicAllowance + travelAllowance;
	}
	
	
}
