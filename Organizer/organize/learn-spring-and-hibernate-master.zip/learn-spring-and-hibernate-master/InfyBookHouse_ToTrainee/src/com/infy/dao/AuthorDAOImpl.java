package com.infy.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.AuthorEntity;
import com.infy.entity.BookEntity;
import com.infy.model.Author;
import com.infy.model.Book;

@Repository(value = "authorDAO")
public class AuthorDAOImpl implements AuthorDAO {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public Boolean checkEmailAvailability(String emailId) throws Exception {
		
		// Your code goes here
		Boolean existing = false;
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		CriteriaQuery<AuthorEntity> criteriaQuery = criteriaBuilder.createQuery(AuthorEntity.class);
		Root<AuthorEntity> root = criteriaQuery.from(AuthorEntity.class);
		criteriaQuery.select(root)
		.where(criteriaBuilder.equal(root.get("emailId"), emailId));
		AuthorEntity authorEntity = session.createQuery(criteriaQuery).uniqueResult();
		if(authorEntity != null)
			existing = true;
		
		return existing;
	}

	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public Boolean checkBookAvailability(String bookId) throws Exception {
		
		// Your code goes here
		Boolean existing = false;
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		CriteriaQuery<BookEntity> criteriaQuery = criteriaBuilder.createQuery(BookEntity.class);
		Root<BookEntity> root = criteriaQuery.from(BookEntity.class);
		criteriaQuery.select(root)
		.where(criteriaBuilder.equal(root.get("bookId"), bookId));
		BookEntity bookEntity = session.createQuery(criteriaQuery).uniqueResult();
		if(bookEntity != null)
			existing = true;
		return existing;
	}

	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public Integer addAuthor(Author author) throws Exception {
		
		// Your code goes here
		Integer authorId = null;
		Session session = sessionFactory.getCurrentSession();
		AuthorEntity authorEntity = new AuthorEntity();
		authorEntity.setAuthorName(author.getAuthorName());
		authorEntity.setEmailId(author.getEmailId());
		authorEntity.setQualification(author.getQualification());
		if(!author.getBookList().isEmpty()) {
			List<BookEntity> bookEntityList = new ArrayList<BookEntity>();
			for(Book book : author.getBookList()) {
				BookEntity bookEntity = new BookEntity();
				bookEntity.setBookId(book.getBookId());
				bookEntity.setName(book.getName());
				bookEntity.setLanguage(book.getLanguage());
				bookEntityList.add(bookEntity);
			}
			authorEntity.setBookList(bookEntityList);
		}
		authorId = (Integer) session.save(authorEntity);
		return authorId;
	}

	// don't tamper with the signature
	public List<Author> getAuthorDetails(String qualification) throws Exception {

		// Your code goes here
		List<Author> authorList = new ArrayList<Author>();
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		CriteriaQuery<AuthorEntity> criteriaQuery = criteriaBuilder.createQuery(AuthorEntity.class);
		Root<AuthorEntity> root = criteriaQuery.from(AuthorEntity.class);
		criteriaQuery.select(root)
		.where(criteriaBuilder.equal(root.get("qualification"), qualification));
		List<AuthorEntity> authorEntityList = session.createQuery(criteriaQuery).getResultList();
		System.out.println(authorEntityList.size());
		if(!authorEntityList.isEmpty()) {
			for(AuthorEntity authorEntity : authorEntityList) {
				Author author = new Author();
				author.setAuthorId(authorEntity.getAuthorId());
				author.setAuthorName(authorEntity.getAuthorName());
				author.setEmailId(authorEntity.getEmailId());
				
				if(!authorEntity.getBookList().isEmpty()) {
					List<Book> bookList = new ArrayList<Book>();
					for(BookEntity bookEntity : authorEntity.getBookList()) {
						Book book = new Book();
						book.setBookId(bookEntity.getBookId());
						book.setName(bookEntity.getName());
						book.setLanguage(bookEntity.getLanguage());
						bookList.add(book);
					}
					
					author.setBookList(bookList);
					authorList.add(author);
				}
				
			}
			
		}
		return authorList;
	}

}
