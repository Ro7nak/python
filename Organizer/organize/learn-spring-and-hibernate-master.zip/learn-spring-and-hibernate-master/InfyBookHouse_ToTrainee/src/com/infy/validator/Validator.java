package com.infy.validator;

import com.infy.model.Book;

public class Validator {

	public static void validate(Book book) throws Exception {
		// Your code goes here
		if(!validateBookId(book.getBookId()))
			throw new Exception("Validator.INVALID_BOOKID");
	}

	// don't tamper with the signature
	public static Boolean validateBookId(String bookId) {

		Boolean isValid = false;
		if(bookId.startsWith("B"))
			isValid = true;
		return isValid;

	}

}
