package com.gauravssnl.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.gaurav.model.Address;
import com.gaurav.model.Customer;

@Configuration
public class SpringConfig {
	
	@Bean
	public Customer getCustomer() {
		return new Customer();
	}
	
	@Bean 
	public Address getAddress() {
		return new Address();
	}
	
	
}
