package com.infy.model;

import java.util.List;

/**
 * Bean class to hold and transfer Trainee data across the tiers   
 * @author ETA
 */


public class Trainee {
	
	private Integer traineeId;
	private String name;
	private List<Exam> examList;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Exam> getExamList() {
		return examList;
	}
	public void setExamList(List<Exam> examList) {
		this.examList = examList;
	}
	public Integer getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(Integer traineeId) {
		this.traineeId = traineeId;
	}
	
	
}
