DROP TABLE Transaction CASCADE CONSTRAINTS;

CREATE TABLE Transaction
  (
    transactionId   NUMBER(10) PRIMARY KEY,
    customerId      VARCHAR2(10) NOT NULL,
    transactionTime DATE NOT NULL,
    amount          NUMBER(10,2)
  );

INSERT INTO Transaction  VALUES (1001, 'C5001', SYSDATE-10, 1000);
INSERT INTO Transaction  VALUES (1002, 'C5002', SYSDATE-9, 450.2);
INSERT INTO Transaction  VALUES (1003, 'C5003', SYSDATE-12, 283.30);
INSERT INTO Transaction  VALUES (1004, 'C5002', SYSDATE-10, 900.0);
INSERT INTO Transaction  VALUES (1005, 'C5001', SYSDATE, 789.22);


COMMIT;

Select * from Transaction;
