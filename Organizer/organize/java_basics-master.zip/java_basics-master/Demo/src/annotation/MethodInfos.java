package annotation;

public @interface MethodInfos {
	MethodInfo[] value();
}
