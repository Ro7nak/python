package com.infy.entity;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
@Component
@Scope("prototype")
@Entity
@Table(name="cabbooking")
@GenericGenerator(name="Pk_gen", strategy="increment")
public class CabBookingEntity {
	@Id
	@GeneratedValue(generator="Pk_gen")
	private Integer	bookingId;
	@Column(name="source")
	private String from;
	@Column(name="Destination")
	private String to;
	private Float estimatedfare;
	private Float actualfare;
	@Temporal(TemporalType.TIMESTAMP)
	private Calendar dateoftravel;
	private Long usermobilenumber;
	private Character status;
	
	public Long getUsermobilenumber() {
		return usermobilenumber;
	}
	public void setUsermobilenumber(Long usermobilenumber) {
		this.usermobilenumber = usermobilenumber;
	}
	public Character getStatus() {
		return status;
	}
	public void setStatus(Character status) {
		this.status = status;
	}
	public Integer getBookingid() {
		return bookingId;
	}
	public void setBookingid(Integer bookingid) {
		this.bookingId = bookingid;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public Float getEstimatedfare() {
		return estimatedfare;
	}
	public void setEstimatedfare(Float estimatedfare) {
		this.estimatedfare = estimatedfare;
	}
	public Float getActualfare() {
		return actualfare;
	}
	public void setActualfare(Float actualfare) {
		this.actualfare = actualfare;
	}
	public Calendar getDateoftravel() {
		return dateoftravel;
	}
	public void setDateoftravel(Calendar dateoftravel) {
		this.dateoftravel = dateoftravel;
	}
	

}
