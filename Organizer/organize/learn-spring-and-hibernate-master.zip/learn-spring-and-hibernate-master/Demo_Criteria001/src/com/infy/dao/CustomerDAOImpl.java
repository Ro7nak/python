package com.infy.dao;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.infy.entity.CustomerEntity;
import com.infy.model.Customer;

@Repository(value = "customerDao")
public class CustomerDAOImpl implements CustomerDAO {

	@Autowired
	SessionFactory sessionFactory;

	@Override
	public List<Customer> getCustomerDetails() {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		CriteriaQuery<CustomerEntity> criteriaQuery = criteriaBuilder
				.createQuery(CustomerEntity.class);
		Root<CustomerEntity> root = criteriaQuery.from(CustomerEntity.class);
		criteriaQuery.select(root);
		Query query = session.createQuery(criteriaQuery);
		List<CustomerEntity> customerEntities = query.getResultList();
		List<Customer> customerList = new ArrayList<>();
		for (CustomerEntity customerEntity : customerEntities) {
			Customer customer = new Customer();
			customer.setCustomerId(customerEntity.getCustomerId());
			customer.setName(customerEntity.getName());
			customer.setDateOfBirth(customerEntity.getDateOfBirth());
			customer.setEmailId(customerEntity.getEmailId());
			customerList.add(customer);
		}
		return customerList;
	}

	@Override
	public List<String> getCustomerName() {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		
		
		CriteriaQuery<String> criteriaQuery = criteriaBuilder
				.createQuery(String.class);
		Root<CustomerEntity> root = criteriaQuery.from(CustomerEntity.class);
		criteriaQuery.select(root.get("name"));
		Query query = session.createQuery(criteriaQuery);
		List<String> customerNames = query.<String>getResultList();

		return customerNames;
	}

	@Override
	public List<Object[]> getCustomerNameandEmail() {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		CriteriaQuery<Object[]> criteriaQuery = criteriaBuilder
				.createQuery(Object[].class);
		Root<CustomerEntity> root = criteriaQuery.from(CustomerEntity.class);
		criteriaQuery.multiselect(root.get("name"), root.get("emailId"));
		Query query = session.createQuery(criteriaQuery);
		List<Object[]> customerDetails = query.getResultList();
		return customerDetails;
	}
}
