package com.infy.dao;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.infy.model.CustomerLogin;

@Repository(value = "customerLoginDao")
public class CustomerLoginDAOImpl implements CustomerLoginDAO {
	public CustomerLoginDAOImpl() {
		// TODO Auto-generated constructor stub
		System.out.println("CustomerLoginDAOImpl constructor");
	}
	@Override
	public CustomerLogin getCustomerLoginByLoginName(String loginName) {
		Map<String, String> customerCredentials = new HashMap<>();
		customerCredentials.put("tom", "tom123");
		customerCredentials.put("gaurav", "gaurav12");
		
		CustomerLogin customerLogin = new CustomerLogin();
		customerLogin.setLoginName(loginName);
		customerLogin.setPassword(customerCredentials.get(loginName));
		return customerLogin;
	}
	
}
