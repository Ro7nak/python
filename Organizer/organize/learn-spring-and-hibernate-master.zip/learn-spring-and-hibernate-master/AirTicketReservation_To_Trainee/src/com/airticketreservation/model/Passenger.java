package com.airticketreservation.model;

import java.util.List;


public class Passenger {
	
	private Integer userId;
	private String passengerName;
	private String password;
	private Integer age;
	private Character gender;
	private Address address;
	private String emailid;
	private String contactNumber;
	private List<BookingDetails> bookings;
	
	
	public List<BookingDetails> getBookings() {
		return bookings;
	}
	public void setBookings(List<BookingDetails> bookings) {
		this.bookings = bookings;
	}
	
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getPassengerName() {
		return passengerName;
	}
	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	
	public Character getGender() {
		return gender;
	}
	public void setGender(Character gender) {
		this.gender = gender;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	
	
	
	
}
