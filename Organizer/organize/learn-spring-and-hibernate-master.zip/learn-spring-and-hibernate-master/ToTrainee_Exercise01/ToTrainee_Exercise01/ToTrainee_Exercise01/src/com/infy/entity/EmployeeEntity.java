package com.infy.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infy.model.EmployeeUnit;

@Entity
@Table(name="Employee")
public class EmployeeEntity {
	@Id
	private Integer employeeId;
	private String emailId;
	@Column(name="employeeName")
	private String name;
	@Column(name = "dob")
	private LocalDate dateOfBirth;
	@Enumerated(EnumType.STRING)
	private EmployeeUnit employeeUnit;
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public EmployeeUnit getEmployeeUnit() {
		return employeeUnit;
	}
	public void setEmployeeUnit(EmployeeUnit employeeUnit) {
		this.employeeUnit = employeeUnit;
	}
	
	
}
