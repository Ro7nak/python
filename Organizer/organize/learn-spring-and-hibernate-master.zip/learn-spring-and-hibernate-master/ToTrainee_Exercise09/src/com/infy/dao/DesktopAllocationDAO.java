package com.infy.dao;

import com.infy.model.Desktop;
import com.infy.model.Trainee;

public interface DesktopAllocationDAO {

	public Trainee getAllocationDetails(Integer traineeId) throws Exception;

	public Integer addNewTrainee(Trainee trainee) throws Exception;

	public Integer allocateExistingDesktop(Integer traineeId, String machineName) throws Exception;

	public String allocateNewDesktop(Integer traineeId, Desktop desktop) throws Exception;

	public String deallocateDesktop(Integer traineeId) throws Exception;

	public String deleteTraineeOnly(Integer traineeId) throws Exception;

	public Integer deleteTraineeAndDesktop(Integer traineeId) throws Exception;
}
