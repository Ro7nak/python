package com.infy.ui;

import java.time.LocalDate;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.infy.configuration.AppConfig;
import com.infy.configuration.SpringConfig;
import com.infy.model.Director;
import com.infy.model.Movie;
import com.infy.service.MovieService;


public class UserInterface {
	static ApplicationContext ctx = new AnnotationConfigApplicationContext(SpringConfig.class);
	static MovieService service = (MovieService)ctx.getBean("movieServiceImpl");
	public static void main(String[] args) {
		addMovie();
		getMovieNameDirectorName();
	}

	public static void addMovie() {
		
		try {
			Movie movie = new Movie();
			movie.setMovieId("M1001");
			// set movie name as empty to log error
			movie.setMovieName("Chris Columbus");
			movie.setReleasedIn(LocalDate.of(1990, 5, 24));
			movie.setLanguage("English");
			movie.setRevenueInDollars(1990);
			
			Director director = new Director();
			director.setDirectorId("D101");
			director.setDirectorName("Chris Columbus");
			director.setBornIn(1990);
			
			movie.setDirector(director);
			String result = service.addMovie(movie);
			System.out.println("New movie successfully added with movieId: " + result);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println(e.getMessage() +
					AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void getMovieNameDirectorName() {
		try {
			System.out.println("Movie Name\t\t\tDirector Name\n****************\t\t******************");
			service.getMovieNameDirectorName()
					.forEach(
							movie -> System.out
									.println(movie.getMovieName()
											+ "\t\t\t"
											+ movie.getDirector()
													.getDirectorName()));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println(e.getMessage() +
					AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}

	}
}
