package config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import service.RegisterService;
import dao.RegisterDAO;

@Configuration
public class SpringConfig {
	@Bean
	public RegisterDAO createRegisterDAO() {
		return new RegisterDAO();
	}
	
	@Bean
	public RegisterService createRegisterService() {
		return new RegisterService();
	}
}
