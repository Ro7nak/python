package com.infy.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.EmployeeEntity;
import com.infy.model.Employee;

@Repository(value = "employeeDAO")
public class EmployeeDAOImpl implements EmployeeDAO {
	
	@Autowired
	SessionFactory sessionFactory;

	public Integer addEmployee(Employee employee) throws Exception {
		Session session = sessionFactory.getCurrentSession();
		EmployeeEntity employeeEntity = new EmployeeEntity();
		employeeEntity.setEmployeeId(employee.getEmployeeId());
		employeeEntity.setName(employee.getName());
		employeeEntity.setDateOfBirth(employee.getDateOfBirth());
		employeeEntity.setEmailId(employee.getEmailId());
		employeeEntity.setEmployeeUnit(employee.getEmployeeUnit());
		Integer employeeId = (Integer)session.save(employeeEntity);
		return employeeId;
	}

	public Employee getEmployeeDetails(Integer employeeId) throws Exception {
		Employee employee = null;
		//Session session = null;
		Session session = sessionFactory.getCurrentSession();
		EmployeeEntity employeeEntity = session.get(EmployeeEntity.class, employeeId);
		if(employeeEntity != null) {
				employee = new Employee();
				employee.setEmployeeId(employeeEntity.getEmployeeId());
				employee.setName(employeeEntity.getName());
				employee.setDateOfBirth(employeeEntity.getDateOfBirth());
				employee .setEmailId(employeeEntity.getEmailId());
				employee.setEmployeeUnit(employeeEntity.getEmployeeUnit());
		}
		
		return employee;
	}

	public Integer updateEmployee(Integer employeeId, String emailId)
			throws Exception {
		Integer result = null;
		Session session = sessionFactory.getCurrentSession();
		EmployeeEntity employeeEntity = session.get(EmployeeEntity.class, employeeId);
		if(employeeEntity != null) 
			result = employeeEntity.getEmployeeId();
		employeeEntity.setEmailId(emailId);
		return result;
	}

	public String deleteEmployee(Integer employeeId) throws Exception {
		String result = null;
		Session session = sessionFactory.getCurrentSession();
		EmployeeEntity employeeEntity = session.get(EmployeeEntity.class, employeeId);
		if(employeeEntity != null) 
			result = employeeEntity.getName();
		session.delete(employeeEntity);
		return result;
	}
}