package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dao.CustomerLoginDAO;
import com.infy.model.CustomerLogin;

@Service(value = "customerLoginService")
public class CustomerLoginServiceImpl implements CustomerLoginService {
	public CustomerLoginServiceImpl() {
		// TODO Auto-generated constructor stub
		System.out.println("CustomerLoginServiceImpl constructor");
	}
	@Autowired
	private CustomerLoginDAO customerLoginDAO;
	@Override
	public Boolean authenticateCustomerLogin(CustomerLogin customerLogin) {
		Boolean isValid = false;
		CustomerLogin customerLoginFromDao = customerLoginDAO.getCustomerLoginByLoginName(customerLogin.getLoginName());
		if(customerLogin.getPassword().equals(customerLoginFromDao.getPassword()))
			isValid = true;
		return isValid;
	}
	
}
