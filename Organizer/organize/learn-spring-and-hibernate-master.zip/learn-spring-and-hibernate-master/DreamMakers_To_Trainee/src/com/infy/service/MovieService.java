package com.infy.service;

import java.util.List;

import com.infy.model.Movie;

public interface MovieService {
	public String addMovie(Movie movie) throws Exception;

	public List<Movie> getMovieNameDirectorName() throws Exception;
	}
