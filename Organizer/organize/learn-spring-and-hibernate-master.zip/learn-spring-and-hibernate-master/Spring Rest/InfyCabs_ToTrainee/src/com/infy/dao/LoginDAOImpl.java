package com.infy.dao;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.UserDetailEntity;
import com.infy.exception.DAOTechnicalError;
import com.infy.model.UserLogin;

@Repository("loginDao")
public class LoginDAOImpl implements LoginDAO {
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public String authenticate(UserLogin user) throws DAOTechnicalError {

		Session session = null;
		String userName = "";
		{

			session = sessionFactory.getCurrentSession();

			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<String> criteria = builder.createQuery(String.class);

			Root<UserDetailEntity> root = criteria.from(UserDetailEntity.class);
			criteria.select(root.get("name"));
			criteria.where(builder.and(
					(builder.equal(root.get("mobileNumber"),
							user.getMobileNumber())),
					(builder.equal(root.get("password"), user.getPassword()))));

			userName = session.createQuery(criteria).uniqueResult();

		}
		return userName;
	}

	@Override
	public String changePassword(String oldPassword, String newPassword,
			Long mobileNo) throws DAOTechnicalError {
		Session session = null;
		UserDetailEntity userDetail = null;
		
		session = sessionFactory.getCurrentSession();
		
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<UserDetailEntity> criteria = builder
				.createQuery(UserDetailEntity.class);

		Root<UserDetailEntity> root = criteria.from(UserDetailEntity.class);

		criteria.where(builder.and(
				(builder.equal(root.get("mobileNumber"), mobileNo)),
				(builder.equal(root.get("password"), oldPassword))));
		userDetail = session.createQuery(criteria).uniqueResult();
		if (userDetail != null) {
			userDetail.setPassword(newPassword);
		} else {
			return null;
		}

		return userDetail.getName();

	}
}
