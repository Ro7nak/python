package com.infy.dao;

import com.infy.model.Transaction;

public interface TransactionDAO {
	public Integer makeTransaction(Transaction transaction) throws Exception;

	public Transaction getTransactionDetails(Integer transactionId) throws Exception;
}
