DROP TABLE Author_Book ;
DROP TABLE Book ;
DROP TABLE Author ;
DROP SEQUENCE HIBERNATE_SEQUENCE;

CREATE SEQUENCE hibernate_sequence START WITH 9005 INCREMENT BY 1;

CREATE TABLE Author (
authorId number(4) PRIMARY KEY,
name VARCHAR2(50) NOT NULL,
emailId Varchar2(20) Not null,
qualification varchar2(20) not null
);
CREATE TABLE Book(
bookId varchar2(10) PRIMARY KEY,
name VARCHAR2(50) NOT NULL,
language Varchar2(10) Not null
);
Create table Author_Book(
authorId number(4) references Author(authorId),
bookId varchar2(10) references Book(bookId),
primary key(authorId,bookId)
);

INSERT INTO Author VALUES(9001,'Sona','Sona@infy.in','MBA');
INSERT INTO Author VALUES(9002,'Soha','Soha@infy.in','MBA');
INSERT INTO Author VALUES(9003,'Swathi','Swathi@infy.in','M.Com');
INSERT INTO Author VALUES(9004,'Aliva','Aliva@infy.in','BSc');


INSERT INTO Book VALUES('B1001','B1','English');
INSERT INTO Book VALUES('B1002','B2','Kannada');
INSERT INTO Book VALUES('B1003','B3','Hindi');
INSERT INTO Book VALUES('B1004','B4','Tamil');
INSERT INTO Book VALUES('B1005','B5','Telugu');

INSERT INTO Author_Book VALUES(9001,'B1001');
INSERT INTO Author_Book VALUES(9001,'B1002');
INSERT INTO Author_Book VALUES(9002,'B1003');
INSERT INTO Author_Book VALUES(9003,'B1004');
INSERT INTO Author_Book VALUES(9004,'B1005');




select * from Author;

select * from Book;

select * from Author_Book;




