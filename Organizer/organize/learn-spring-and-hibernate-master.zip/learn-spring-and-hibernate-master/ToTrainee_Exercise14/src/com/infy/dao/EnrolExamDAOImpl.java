package com.infy.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.ExamEntity;
import com.infy.entity.TraineeEntity;
import com.infy.model.Exam;
import com.infy.model.Trainee;

@Repository(value = "enrolExamDAO")
public class EnrolExamDAOImpl implements EnrolExamDAO {
	@Autowired
	SessionFactory sessionFactory;

	
	@Override
	public String enrollTraineeForExams(Integer traineeId, List<String> examIdL)
			throws Exception {
		// TODO Auto-generated method stub
		String result = null;
		Session session = sessionFactory.getCurrentSession();
		TraineeEntity traineeEntity = session.get(TraineeEntity.class, traineeId);
		//List<ExamEntity> examEntityList = new ArrayList<ExamEntity>();
		
		if(traineeEntity != null) {
			List<ExamEntity> traineeExamEntityList = traineeEntity.getExamList();
			for(String examId : examIdL) {
				
				ExamEntity examEntity = session.get(ExamEntity.class, examId);
				if(examEntity != null) {
					if(!traineeExamEntityList.contains(examEntity))
						traineeExamEntityList.add(examEntity);
					
				}
				else
					return "";	
			}
			
			result = traineeEntity.getName();
			traineeEntity.setExamList(traineeExamEntityList);
		}
		
		return result;
	}

	@Override
	public String delistTraineeFromExams(Integer traineeId, List<String> examIdL)
			throws Exception {
		// TODO Auto-generated method stub
		String result = null;
		Session session = sessionFactory.getCurrentSession();
		TraineeEntity traineeEntity = session.get(TraineeEntity.class, traineeId);
		if(traineeEntity != null) {
			for(String examId : examIdL) {
				ExamEntity examEntity = session.get(ExamEntity.class, examId);
				if(examEntity != null) {
					result = traineeEntity.getName();
					if(traineeEntity.getExamList().contains(examEntity))
						traineeEntity.getExamList().remove(examEntity);
				}
			}
		}
		return result;
	}

	@Override
	public String deleteTraineeDetails(Integer traineeId) throws Exception {
		// TODO Auto-generated method stub
		String result = null;
		Session session = sessionFactory.getCurrentSession();
		TraineeEntity traineeEntity = session.get(TraineeEntity.class, traineeId);
		if(traineeEntity != null) {
			result = traineeEntity.getName();
			traineeEntity.setExamList(null);
			session.delete(traineeEntity);
		}
		return result;
	}

	@Override
	public Trainee getTraineeDetails(Integer traineeId) throws Exception {
		// TODO Auto-generated method stub
		Trainee trainee=  null;
		Session session = sessionFactory.getCurrentSession();
		TraineeEntity traineeEntity = session.get(TraineeEntity.class, traineeId);
		if(traineeEntity != null) {
			trainee = new Trainee();
			trainee.setTraineeId(traineeEntity.getId());
			trainee.setName(traineeEntity.getName());
			List<Exam> examList = new ArrayList<Exam>();
			for(ExamEntity examEntity : traineeEntity.getExamList()) {
				Exam exam = new Exam();
				exam.setExamId(examEntity.getExamId());
				exam.setDetails(examEntity.getDetails());
				examList.add(exam);
			}
			trainee.setExamList(examList);
		}
		
		return trainee;
	}

}
