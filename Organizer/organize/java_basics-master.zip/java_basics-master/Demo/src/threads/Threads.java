package threads;

public class Threads implements Runnable{

	@Override
	public void run() {
		System.out.println("Hello Threads");
	}

}
