package com.infy.ui;

import com.infy.configuration.AppConfig;
import com.infy.model.ClassRoom;
import com.infy.model.Trainee;
import com.infy.service.ClassRoomAllocationService;
import com.infy.utility.ContextFactory;


public class UserInterface {

	public static void main(String args[]) {
		
		//UserInterface.getAllocationDetails();
		//UserInterface.addNewTraineeAndNewClassRoom();
		//UserInterface.updateClassRoomDetails();
		//UserInterface.deleteTraineeDetails();
	}

	public static void getAllocationDetails() {
		try {
			Integer traineeId = 800001;
			ClassRoomAllocationService service = (ClassRoomAllocationService) ContextFactory.getContext().getBean("classRoomAllocationService");

			Trainee trainee = service.getAllocationDetails(traineeId);
			System.out.println("Trainee Details");
			System.out.println("---------------");
			System.out.println("TraineeId \t\t: " + trainee.getTraineeId());
			System.out.println("Trainee Name \t\t: " + trainee.getTraineeName());
			if (trainee.getTraineeClassroom() != null) {
				System.out.println("Class Room \t\t: " + trainee.getTraineeClassroom().getClassRoomId());
				System.out.println("Seating Capacity \t: " + trainee.getTraineeClassroom().getSeatingCapacity());
			}
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
			e.printStackTrace();
		}
	}

	public static void addNewTraineeAndNewClassRoom() {
		try {
			Trainee trainee = new Trainee();
			trainee.setTraineeName("John");
			ClassRoom classRoom = new ClassRoom(); 
			classRoom.setClassRoomId("GEC2 - L1 - 072");
			classRoom.setSeatingCapacity(100);
			trainee.setTraineeClassroom(classRoom);

			ClassRoomAllocationService service = (ClassRoomAllocationService) ContextFactory.getContext().getBean("classRoomAllocationService");

			Integer traineeId = service.addNewTrainee(trainee);

			System.out.println(AppConfig.PROPERTIES.getProperty("UserInterface.NEW_TRAINEE_CLASSROOM_SUCCESS") + " : " + traineeId);
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
			e.printStackTrace();
		}

	}

	public static void updateClassRoomDetails() {
		try {

			String classRoomId = "GEC2 - G063";
			Integer traineeId = 800003;

			ClassRoomAllocationService service = (ClassRoomAllocationService) ContextFactory.getContext().getBean("classRoomAllocationService");

			service.updateClassRoomDetails(traineeId, classRoomId);

			System.out.println(AppConfig.PROPERTIES.getProperty("UserInterface.EXISTING_CLASSROOM_ALLOCATED_SUCCESS") + " : " + traineeId);
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void deleteTraineeDetails() {
		try {
			Integer traineeId = 800002;
			ClassRoomAllocationService service = (ClassRoomAllocationService) ContextFactory.getContext().getBean("classRoomAllocationService");

			String name = service.deleteTraineeDetails(traineeId);

			System.out.println(name + " " + AppConfig.PROPERTIES.getProperty("UserInterface.TRAINEE_DELETED_SUCCESS"));
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

}
