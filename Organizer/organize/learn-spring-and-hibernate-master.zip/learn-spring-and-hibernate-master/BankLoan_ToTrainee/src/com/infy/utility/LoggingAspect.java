package com.infy.utility;


public class LoggingAspect {

	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public void logDaoException(Exception exception) throws Exception {
		
	}

	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public void logServiceException(Exception exception) throws Exception {
		
	}

	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	private void logException(Exception exception) {
		LogConfig.getLogger(this.getClass()).error(exception.getMessage(),
				exception);
	}

}
