package com.airticketreservation.controller;

import java.util.Enumeration;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.airticketreservation.model.Passenger;
import com.airticketreservation.service.PassengerLoginService;
import com.airticketreservation.service.PassengerRegisterService;
import com.airticketreservation.utility.ContextFactory;

@Controller
@PropertySource("classpath:/com/airticketreservation/resources/configuration.properties")
public class PassengerController {

	@Autowired
	private Environment environment;

	@RequestMapping(value = { "/" })
	public ModelAndView login() {
		ModelAndView model = new ModelAndView("loginPage");
		return model;
	}

	@RequestMapping("/login")
	public ModelAndView login(@ModelAttribute Passenger customerLogin,
			HttpSession httpSession) {
		ModelAndView model = new ModelAndView("loginPage");

		try {

			PassengerLoginService loginService = (PassengerLoginService) ContextFactory
					.getContext().getBean("passengerLoginService");
			Passenger passenger = loginService
					.authenticatePassengerLogin(customerLogin);

			httpSession.setAttribute("userId", passenger.getUserId());
			httpSession.setAttribute("password", passenger.getPassword());
			httpSession.setAttribute("passengerName",passenger.getPassengerName() );

			model = new ModelAndView("home");
			model.addObject("loginName", passenger.getPassengerName());
		} catch (Exception e) {
			model.addObject("message", environment.getProperty(e.getMessage()));
		}

		return model;
	}

	@RequestMapping(value = "/register")
	public ModelAndView register() {
		ModelAndView model = new ModelAndView("register");
		return model;
	}

	@RequestMapping("/registerUser")
	public ModelAndView registerUser(@ModelAttribute Passenger passenger,
			HttpSession httpSession) {

		ModelAndView model = new ModelAndView("register");

		try {
			

			model.addObject("passengerName", passenger.getPassengerName());
			model.addObject("password", passenger.getPassword());
			model.addObject("age", passenger.getAge());		
			model.addObject("emailid", passenger.getEmailid());
			model.addObject("contactNumber", passenger.getContactNumber());
			
			
			PassengerRegisterService registerService = (PassengerRegisterService) ContextFactory
					.getContext().getBean("passengerRegisterService");
			Integer profileId = registerService.addPassenger(passenger);

			model = new ModelAndView("success");
			String message = environment
					.getProperty("PassengerController.REGISTRATION_SUCCESS")
					+ profileId;
			model.addObject("successMessage", message);

		} catch (Exception e) {
			model.addObject("message", environment.getProperty(e.getMessage()));
		}
		return model;
	}
	
	
	@RequestMapping(value = "/logOut")
	public ModelAndView logOut(HttpSession httpSession) {
		ModelAndView model = new ModelAndView("loginPage");
		Enumeration<String> attributes = httpSession.getAttributeNames();

		while (attributes.hasMoreElements()){
			httpSession.removeAttribute(attributes.nextElement());
		}
		model.addObject("successMessage",
				environment.getProperty("LoginController.LOGOUT_SUCCESS"));
		return model;
	}

}
