package com.infy.ui;

import java.util.ArrayList;
import java.util.List;

import com.infy.configuration.AppConfig;
import com.infy.model.Author;
import com.infy.model.Book;
import com.infy.service.AuthorService;
import com.infy.utility.ContextFactory;

public class UserInterface {
	
	static AuthorService service = (AuthorService) ContextFactory
			.getContext().getBean("authorService");
	public static void main(String[] args) {
			//addAuthor();
			getAuthorDetails();
	}


	public static void addAuthor() {
		try {

			Author author = new Author();
			author.setEmailId("Dev@infy.in");
			author.setAuthorName("Dev");
			author.setQualification("BTech");
			
			List<Book> bookList = new ArrayList<Book>();
			
			Book b1 = new Book();
			b1.setBookId("B1006");
			b1.setLanguage("English");
			b1.setName("B6");			
			
			bookList.add(b1);
			
			Book b2 = new Book();
			b2.setBookId("B1007");
			b2.setLanguage("Kannada");
			b2.setName("B7");
			bookList.add(b2);
		
			author.setBookList(bookList);

			Integer authorId = service.addAuthor(author);
			System.out.println("\n\n"+AppConfig.PROPERTIES.getProperty("UserInterface.AUTHOR_ADDED_SUCCESS")+" "+authorId);
			
		} catch (Exception e) {
			e.printStackTrace();
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			if (message == null) {
				message = AppConfig.PROPERTIES.getProperty("General.EXCEPTION");
			}
			System.out.println("\n\nERROR:" + message);
		}

	}
	
	public static void getAuthorDetails() {
		try {
			String qualification="MBA";
			List<Author> authors=service.getAuthorDetails(qualification);
			System.out.println(authors);
			if(authors!=null){
				for(Author b:authors){
					System.out.println("\nAuthorId: "+b.getAuthorId()+"\n\tBOOKS DETAILS");
					System.out.println("\nBook Id "+" BookName "+" language");
					System.out.println("******* "+" ******** "+" ********");
					for(Book c :b.getBookList()){
						System.out.println(c.getBookId()+"\t "+c.getName()+"\t   "+c.getLanguage());
					}
					System.out.println("----------------------------");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			if (message == null) {
				message = AppConfig.PROPERTIES.getProperty("General.EXCEPTION");
			}
			System.out.println("\n\nERROR:" + message);
		}
	}

}
