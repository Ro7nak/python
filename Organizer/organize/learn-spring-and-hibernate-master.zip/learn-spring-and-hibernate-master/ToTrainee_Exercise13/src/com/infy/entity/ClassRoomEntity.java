package com.infy.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ManyToOne_ClassRoom")
public class ClassRoomEntity {
	@Id
	private String classRoomId;
	private Integer seatingCapacity;
	public String getClassRoomId() {
		return classRoomId;
	}
	public void setClassRoomId(String classRoomId) {
		this.classRoomId = classRoomId;
	}
	public Integer getSeatingCapacity() {
		return seatingCapacity;
	}
	public void setSeatingCapacity(Integer seatingCapacity) {
		this.seatingCapacity = seatingCapacity;
	}
	
}
