package com.airticketreservation.dao;

import java.util.List;

import com.airticketreservation.model.BookingDetails;

public class TicketCancellationDAOImpl implements TicketCancellationDAO {

	// don't tamper the signature
	public List<BookingDetails> getMyBookingDetails(Integer profileId) {

		// Your code goes here
		return null;
	}

	// don't tamper the signature
	public Integer cancelTicket(Integer bookingId) {

		// Your code goes here
		return null;
	}

}
