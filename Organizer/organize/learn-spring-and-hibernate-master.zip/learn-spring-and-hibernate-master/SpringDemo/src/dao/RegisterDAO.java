package dao;

import model.Employee;

public class RegisterDAO {

	public String registerEmployee(Employee employee){
		System.out.println("Persisting Employee into Database");
		
		return "Registration Success";
	}
}
