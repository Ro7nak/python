package lambda;

public class StringFormatter {
public static void main(String[] args) {
	String[] s = {"Lambda","Expression"};
	
	String a;
	//String.format((s[0],s[1]) -> {s[0].toUpperCase()+s[1].toUpperCase()}), s)
}
}
