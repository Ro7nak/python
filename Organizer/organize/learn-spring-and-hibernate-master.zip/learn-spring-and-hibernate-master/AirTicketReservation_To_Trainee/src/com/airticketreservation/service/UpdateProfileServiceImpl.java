package com.airticketreservation.service;

import com.airticketreservation.model.Passenger;

public class UpdateProfileServiceImpl implements UpdateProfileService {

	// don't tamper the signature
	public Boolean updateProfile(Passenger passenger) throws Exception {

		// Your code goes here
		return null;

	}

	// don't tamper the signature
	public Boolean updateAddress(Passenger passenger) throws Exception {

		// Your code goes here
		return null;

	}

}
