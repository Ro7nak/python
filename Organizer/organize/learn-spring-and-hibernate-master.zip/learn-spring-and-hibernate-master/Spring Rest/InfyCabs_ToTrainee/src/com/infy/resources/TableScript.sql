
drop table userlogin cascade constraint;
drop table cabbooking cascade constraint;
drop table userdetail cascade constraint;
drop table driverdetails cascade constraint;

create table userdetail(
mobilenumber number(10) primary key,
name varchar2(15) not null,
password varchar2(15) not null,
email varchar2(25)not null unique,
notification varchar2(60),
role char check (role in('C','D','A'))
);

create table cabbooking(bookingId number(7) primary key,
usermobilenumber number(10) not null references userdetail(mobilenumber),
source varchar2(25),
destination varchar2(25),
estimatedfare number(9,2) default null,
actualfare number(9,2) default null,
dateoftravel TIMESTAMP DEFAULT SYSTIMESTAMP NOT NULL,
status CHAR NOT NULL);

select * from CABBOOKING;
select * from userdetail;

create table userlogin(
mobilenumber number(10) primary key,
password varchar2(15)
);
drop table fareestimation;
create table fareestimation(
sourceDestination varchar2(40) primary key,
distance number(5)
);
insert into fareestimation values('Mysore-Bangalore',145);
insert into fareestimation values('Mysore-Chennai',482);

insert into fareestimation values('Mysore-Hampi',412);

insert into fareestimation values('Mysore-Goa',620);

insert into fareestimation values('Mysore-Mangalore',254);

insert into USERDETAIL values(9998766756,'Andy','and@123','andy@hotmail.com',null,'C');
insert into USERDETAIL values(9898766756,'Ron','ron@123','ron@hotmail.com',null,'C');

insert into USERDETAIL values(9898770751,'Chan','chan@123','chan@hotmail.com',null,'C');
insert into USERDETAIL values(9877766756,'Winny','win@123','winny@hotmail.com',null,'C');
insert into USERDETAIL values(9898006896,'Edd','ed@123','eddy@hotmail.com',null,'C');
insert into USERDETAIL values(8898766766,'Sam','sam@123','sam@hotmail.com',null,'C');

insert into CABBOOKING values(2,9898766756,'Mysore','Goa',3720,null,sysdate+3,'B');
insert into CABBOOKING values(3,9898766756,'Goa','Mysore',3720,null,sysdate+6,'B');
insert into CABBOOKING values(4,9877766756,'Mysore','Mangalore',1524,null,sysdate+2,'B');
insert into CABBOOKING values(5,8898766766,'Bangalore','Mysore',870,null,sysdate+4,'B');
insert into CABBOOKING values(6,8898766766,'Mysore','Bangalore',870,null,sysdate+7,'B');
insert into CABBOOKING values(7,9898770751,'Mysore','Hampi',2472,null,sysdate+1,'B');
insert into CABBOOKING values(8,9898006896,'Mysore','Chennai',2892,null,sysdate+5,'B');

insert into CABBOOKING values(1,9898766756,'Mysore','Goa',620,null,sysdate+3,'B');

select * from USERDETAIL;

create table driverdetails(
drivermobileNumber number(10) primary key,
cabNumber varchar2(15) not null unique,
cabType varchar2(15) not null,
location varchar2(30) not null
);

Select * from DriverDetails;
drop table driverridedetails cascade constraint;

create table driverridedetails(
driverbookingId number(7) primary key,
bookingId number(7) references cabbooking(bookingId),
drivermobileNumber number(10)  references driverdetails(drivermobilenumber),
ridestatus char check(ridestatus in ('C','U','O'))

);
Select * from DriverRideDetails;