package com.infy.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.DesktopEntity;
import com.infy.entity.TraineeEntity;
import com.infy.model.Desktop;
import com.infy.model.Trainee;

@Repository(value = "desktopAllocationDAO")
public class DesktopAllocationDAOImpl implements DesktopAllocationDAO {
	
	@Autowired
	SessionFactory sessionFactory;
	
	public Trainee getAllocationDetails(Integer traineeId) throws Exception {
		Trainee trainee = null;
		Session session = sessionFactory.getCurrentSession();
		TraineeEntity traineeEntity = session.get(TraineeEntity.class, traineeId);
		if(traineeEntity != null) {
			trainee = new Trainee();
			trainee.setTraineeId(traineeEntity.getTraineeId());
			trainee.setTraineeName(traineeEntity.getTraineeName());
			if(traineeEntity.getDesktopEntity() != null) {
				Desktop desktop = new Desktop();
				desktop.setMachineName(traineeEntity.getDesktopEntity().getMachineName());
				desktop.setMake(traineeEntity.getDesktopEntity().getMake());
				trainee.setDesktop(desktop);
			}
		}
		return trainee;
	}

	
	public Integer addNewTrainee(Trainee trainee) throws Exception {		
		Integer traineeId = null;
		Session session = sessionFactory.getCurrentSession();
		TraineeEntity traineeEntity = new TraineeEntity();
		traineeEntity.setTraineeName(trainee.getTraineeName());
		if(trainee.getDesktop() != null) {
			DesktopEntity desktopEntity = new DesktopEntity();
			desktopEntity.setMachineName(trainee.getDesktop().getMachineName());
			desktopEntity.setMake(trainee.getDesktop().getMake());
			session.persist(desktopEntity);
			traineeEntity.setDesktopEntity(desktopEntity);
		}
		
		traineeId = (Integer) session.save(traineeEntity);
		return traineeId;
	}

	
	public Integer allocateExistingDesktop(Integer traineeId, String machineName) throws Exception {
		Integer result = null;
		Session session = sessionFactory.getCurrentSession();
		TraineeEntity traineeEntity = session.get(TraineeEntity.class, traineeId);
		DesktopEntity desktopEntity = session.get(DesktopEntity.class, machineName);
		if(traineeEntity != null) {
			if(desktopEntity != null) {
				result = 1;
				traineeEntity.setDesktopEntity(desktopEntity);
				session.persist(traineeEntity);
			}
			
			else
				result = 0;
		}
		
		else 
			result = -1;
		return result;
	}

	public String allocateNewDesktop(Integer traineeId, Desktop desktop) throws Exception {
		String result = null;
		
		Session session = sessionFactory.getCurrentSession();
		TraineeEntity traineeEntity = session.get(TraineeEntity.class, traineeId);
		if(traineeEntity != null) {
			result = traineeEntity.getTraineeName();
			DesktopEntity desktopEntity = new DesktopEntity();
			desktopEntity.setMachineName(desktop.getMachineName());
			desktopEntity.setMake(desktop.getMake());
			//session.persist(desktopEntity);
			traineeEntity.setDesktopEntity(desktopEntity);
			//session.persist(traineeEntity);
		
		}
		
		return result;
	}

	public String deallocateDesktop(Integer traineeId) throws Exception {
		String result = null;
		Session session = sessionFactory.getCurrentSession();
		TraineeEntity traineeeEntity = session.get(TraineeEntity.class, traineeId);
		if(traineeeEntity != null) {
			result = traineeeEntity.getTraineeName();
			traineeeEntity.setDesktopEntity(null);
			session.persist(traineeeEntity);
			
		}
		return result;
	}

	
	public String deleteTraineeOnly(Integer traineeId) throws Exception {
		String result = null;
		Session session = sessionFactory.getCurrentSession();
		TraineeEntity traineeEntity = session.get(TraineeEntity.class, traineeId);
		if(traineeEntity != null) {
			result = traineeEntity.getTraineeName();
			// set traineeEntity's DesktopEntity as null , so that deleting trainee doesn't delete desktop
			traineeEntity.setDesktopEntity(null);
			session.delete(traineeEntity);
		}
		return result;
	}


	public Integer deleteTraineeAndDesktop(Integer traineeId) throws Exception {
		Integer result = null;
		Session session = sessionFactory.getCurrentSession();
		TraineeEntity traineeEntity = session.get(TraineeEntity.class, traineeId);
		if(traineeEntity == null)
			result = 0;
		else {
			if(traineeEntity.getDesktopEntity() == null)
				result = -1;
			else {
				result = 1;
				//session.delete(traineeEntity.getDesktopEntity());
				session.delete(traineeEntity);
			}
		}
		
		return result;
	}
}
