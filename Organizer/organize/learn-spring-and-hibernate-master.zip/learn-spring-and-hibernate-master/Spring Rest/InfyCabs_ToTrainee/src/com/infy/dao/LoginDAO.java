package com.infy.dao;

import com.infy.exception.DAOTechnicalError;
import com.infy.model.UserLogin;



public interface LoginDAO  {
	public String authenticate(UserLogin user)throws DAOTechnicalError;
	public String changePassword(String oldPassword,String newPassword,Long mobileNo) throws DAOTechnicalError;
}
