DROP TABLE Movie_Details CASCADE CONSTRAINTS;
DROP TABLE Director_Details CASCADE CONSTRAINTS;
DROP TABLE Movie_Director_Details CASCADE CONSTRAINTS;

CREATE TABLE Movie_Details
  (
    movieId    NUMBER(6) PRIMARY KEY,
    movieName  VARCHAR2(20) UNIQUE NOT NULL,
    IMDBRating NUMBER(2,1) NULL
  );
  
CREATE TABLE Director_Details
  (
    directorId   VARCHAR2(6) PRIMARY KEY,
    directorName VARCHAR2(20) UNIQUE NOT NULL,
    dob          DATE
  );
  
CREATE TABLE Movie_Director_Details
  (
    movieId    NUMBER(6) REFERENCES Movie_Details(movieId),
    directorId   VARCHAR2(6) REFERENCES Director_Details(directorId),
    PRIMARY KEY (directorId, movieId)
  );

INSERT INTO Director_Details VALUES('D9001', 'Christopher Nolan', '30-JULY-1970');
INSERT INTO Director_Details VALUES('D9002', 'Tony Leondis', '24-MAR-1967');
INSERT INTO Director_Details VALUES('D9003', 'David Sandberg', '21-JAN-1981');
INSERT INTO Director_Details VALUES('D9004', 'Jon Watts', '28-JUNE-1981');
INSERT INTO Director_Details VALUES('D9005', 'Patty Jenkins', '24-JULY-1971');
INSERT INTO Director_Details VALUES('D9006', 'David Leitch', '30-JULY-1970');
INSERT INTO Director_Details VALUES('D9007', 'Kyle Balda', '09-MARCH-1971');
INSERT INTO Director_Details VALUES('D9008', 'Tim Miller', '28-FEB-1970');

INSERT INTO Movie_Details VALUES(9001, 'Deadpool', 8.0);
INSERT INTO Movie_Details VALUES(9002, 'The Emoji Movie', 1.5);
INSERT INTO Movie_Details VALUES(9003, 'Dunkirk', 8.5);
INSERT INTO Movie_Details VALUES(9004, 'The Avengers', 8.1);
INSERT INTO Movie_Details VALUES(9005, 'Annabelle', 7.6);
INSERT INTO Movie_Details VALUES(9006, 'Planet of the Apes', 8.0);
INSERT INTO Movie_Details VALUES(9007, 'Spider-Man', 7.9);
INSERT INTO Movie_Details VALUES(9008, 'Atomic Blonde', 7.2);
INSERT INTO Movie_Details VALUES(9009, 'Despicable Me 3', 6.4);
INSERT INTO Movie_Details VALUES(9010, 'Wonder Woman',  7.9);

INSERT INTO Movie_Director_Details VALUES(9001, 'D9008');
INSERT INTO Movie_Director_Details VALUES(9002, 'D9002');
INSERT INTO Movie_Director_Details VALUES(9003, 'D9001');
INSERT INTO Movie_Director_Details VALUES(9009, 'D9007');
INSERT INTO Movie_Director_Details VALUES(9008, 'D9006');
INSERT INTO Movie_Director_Details VALUES(9007, 'D9004');

COMMIT;

SELECT * FROM Movie_Details;
SELECT * FROM Director_Details;
SELECT * FROM Movie_Director_Details;
