package com.infy.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "ManyToMany_Trainee")
public class TraineeEntity {
	@Id
	private Integer id;
	private String name;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "TraineeExam",
	joinColumns = @JoinColumn(name = "traineeId", referencedColumnName = "id"),
	inverseJoinColumns = @JoinColumn(name = "examId", referencedColumnName = "examId"))
	private List<ExamEntity> examList;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<ExamEntity> getExamList() {
		return examList;
	}
	public void setExamList(List<ExamEntity> examList) {
		this.examList = examList;
	}
	
}
