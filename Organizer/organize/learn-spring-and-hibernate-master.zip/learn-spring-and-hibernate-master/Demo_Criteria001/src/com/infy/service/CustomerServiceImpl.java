package com.infy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.CustomerDAO;
import com.infy.model.Customer;

@Service(value = "customerService")
@Transactional(readOnly = true)
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerDAO customerDAO;

	@Override
	public List<Customer> getCustomerDetails() throws Exception {
		return customerDAO.getCustomerDetails();
	}

	@Override
	public List<String> getCustomerName() throws Exception {
		return customerDAO.getCustomerName();
	}

	@Override
	public List<Object[]> getCustomerNameandEmail() throws Exception {
		return customerDAO.getCustomerNameandEmail();
	}

	
}