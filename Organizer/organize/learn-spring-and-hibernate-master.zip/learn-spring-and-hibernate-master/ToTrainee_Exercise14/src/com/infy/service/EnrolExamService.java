package com.infy.service;

import java.util.List;

import com.infy.model.Trainee;

public interface EnrolExamService {

	
	public Trainee getTraineeDetails(Integer traineeId) throws Exception;

	public String enrollTraineeForExams(Integer traineeId, List<String> examIdL) throws Exception;
	
	public String delistTraineeFromExams(Integer traineeId, List<String> examIdL) throws Exception;

	public String deleteTraineeDetails(Integer traineeId) throws Exception;

}
