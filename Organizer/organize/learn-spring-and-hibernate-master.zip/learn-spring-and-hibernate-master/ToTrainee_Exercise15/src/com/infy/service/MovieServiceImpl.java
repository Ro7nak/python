package com.infy.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.MovieDAO;
import com.infy.model.Movie;

@Service(value = "movieService")
@Transactional(readOnly = true)
public class MovieServiceImpl implements MovieService {
	@Autowired
	private MovieDAO movieDAO;

	@Override
	public Movie getMovieDetails(String movieName) throws Exception {
		// TODO Auto-generated method stub
		Movie movie = null;
		movie = movieDAO.getMovieDetails(movieName);
		if(movie == null)
			throw new Exception("Service.NO_MOVIE_FOUND");
		return movie;
	}

	@Override
	public List<Movie> getMovieByImdbRating(Double fromRating, Double toRating)
			throws Exception {
		// TODO Auto-generated method stub
		List<Movie> movieList = null;
		movieList = movieDAO.getMovieByImdbRating(fromRating, toRating);
		if(movieList.isEmpty())
			throw new Exception("Service.NO_MOVIES_FOUND_FOR_RATING");
		return movieList;
	}

	@Override
	public List<Object[]> getMoviesNameAndYear(String directorName,
			Double toRating) throws Exception {
		// TODO Auto-generated method stub
		List<Object[]> moviesNameAndYearList = null;
		moviesNameAndYearList = movieDAO.getMoviesNameAndYear(directorName, toRating);
		if(moviesNameAndYearList.isEmpty())
			throw new Exception("Service.MOVIE_NOT_FOUND_FOR_DIRECTOR");
		return moviesNameAndYearList;
	}

	@Override
	public List<String> getMoviesByDirectorName(String directorName)
			throws Exception {
		// TODO Auto-generated method stub
		List<String> movieNamesList = null;
		movieNamesList = movieDAO.getMoviesByDirectorName(directorName);
		if(movieNamesList.isEmpty())
			throw new Exception("Service.NO_MOVIE_FOUND");
		return movieNamesList;
	}

}
