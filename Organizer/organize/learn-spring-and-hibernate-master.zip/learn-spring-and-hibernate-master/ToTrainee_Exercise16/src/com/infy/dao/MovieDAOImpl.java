package com.infy.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.MovieEntity;
import com.infy.model.Movie;
@Repository(value = "movieDAO")
public class MovieDAOImpl implements MovieDAO {
	@Autowired
	SessionFactory sessionFactory;

	public List<Movie> getMovieByRatingInAscending(Double fromRating)
			throws Exception {
		List<Movie> movieList = new ArrayList<Movie>();
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		CriteriaQuery<MovieEntity> criteriaQuery = criteriaBuilder.createQuery(MovieEntity.class);
		Root<MovieEntity> root = criteriaQuery.from(MovieEntity.class);
		criteriaQuery.select(root)
		.where(criteriaBuilder.ge(root.get("imdbRating"), fromRating))
		.orderBy(criteriaBuilder.asc(root.get("imdbRating")));
		Query query = session.createQuery(criteriaQuery);
		List<MovieEntity> movieEntityList = query.getResultList();
		if(!movieEntityList.isEmpty()) {
			for(MovieEntity movieEntity : movieEntityList) {
				Movie movie = new Movie();
				movie.setMovieId(movieEntity.getMovieId());
				movie.setMovieName(movieEntity.getMovieName());
				movie.setDirectorName(movieEntity.getDirectorName());
				movie.setYear(movieEntity.getYear());
				movie.setImdbRating(movieEntity.getImdbRating());
				movieList.add(movie);
			}
		}

		return movieList;
	}

	public Map<String, Float> getMaxRatedMovieOfDirector(String directorName)
			throws Exception {
		Map<String, Float> directorMaxRatingMap = new HashMap<>();
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		
		// Get maximum IMDBRating 
		CriteriaQuery<Float> criteriaQuery1 = criteriaBuilder.createQuery(Float.class);
		Root<MovieEntity> root1 = criteriaQuery1.from(MovieEntity.class);
		criteriaQuery1.select(criteriaBuilder.max(root1.get("imdbRating")));
		criteriaQuery1.where(criteriaBuilder.equal(root1.get("directorName"), directorName));
		Float maxRating = (Float) session.createQuery(criteriaQuery1).uniqueResult();
		
		// Get Movie with maximum IMDB Rating
		CriteriaQuery<MovieEntity> criteriaQuery2 = criteriaBuilder.createQuery(MovieEntity.class);
		Root<MovieEntity> root2 = criteriaQuery2.from(MovieEntity.class);
		criteriaQuery2.select(root2);
		criteriaQuery2.where(criteriaBuilder.and(
				criteriaBuilder.equal(root1.get("directorName"), directorName),
				criteriaBuilder.equal(root2.get("imdbRating"), maxRating)));
		List<MovieEntity> movieEntityList = session.createQuery(criteriaQuery2).getResultList();
		if(!movieEntityList.isEmpty()) {
			for(MovieEntity movieEntity : movieEntityList)
				directorMaxRatingMap.put(movieEntity.getMovieName(), movieEntity.getImdbRating());
		}
		return directorMaxRatingMap;
	}

	public Float getAverageRatingOFDirector(String directorName)
			throws Exception {
		Float averageRating = null;

		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		CriteriaQuery<Double> criteriaQuery = criteriaBuilder.createQuery(Double.class);
		Root<MovieEntity> root = criteriaQuery.from(MovieEntity.class);
		// multiselect does not require type casting
		criteriaQuery.select(criteriaBuilder.avg(root.get("imdbRating")));
		criteriaQuery.where(criteriaBuilder.equal(root.get("directorName"), directorName));
		averageRating = (session.createQuery(criteriaQuery).getSingleResult()).floatValue();

		return averageRating;
	}

	public Integer getNumberMovieReleasedInYearRange(Integer fromYear,
			Integer toYear) throws Exception {
		Integer numberOfMovies =  0;
			Session session = sessionFactory.getCurrentSession();
			CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
			CriteriaQuery<Long> criteriaQuery = criteriaBuilder.createQuery(Long.class);
			Root<MovieEntity> root = criteriaQuery.from(MovieEntity.class);
			criteriaQuery.select(criteriaBuilder.count(root.get("movieId")))
			.where(criteriaBuilder.between(root.get("year"), fromYear, toYear));
		numberOfMovies = session.createQuery(criteriaQuery).uniqueResult().intValue();	
		return numberOfMovies;
	}

}
