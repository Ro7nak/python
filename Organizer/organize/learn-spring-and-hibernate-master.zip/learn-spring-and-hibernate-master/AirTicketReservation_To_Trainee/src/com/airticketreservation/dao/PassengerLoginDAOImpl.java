package com.airticketreservation.dao;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.airticketreservation.entity.PassengerEntity;
import com.airticketreservation.model.Passenger;

@Repository(value = "passengerloginDao")
public class PassengerLoginDAOImpl implements PassengerLoginDAO {

	@Autowired
	SessionFactory sessionFactory;

	@Override
	public Passenger getPassengerLoginByLoginName(Passenger passenger) {

		String password = passenger.getPassword();
		Passenger passenger1 = null;

		Session session =  sessionFactory.getCurrentSession();

		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<PassengerEntity> criteria = builder
				.createQuery(PassengerEntity.class);
		Root<PassengerEntity> root = criteria.from(PassengerEntity.class);

		Predicate p1 = builder.equal(root.get("userId"), passenger.getUserId());
		Predicate p2 = builder.equal(root.get("password"), password);
		criteria.where(p1, p2);

		PassengerEntity passengerEntity = session.createQuery(criteria)
				.uniqueResult();

		if (passengerEntity != null) {

			passenger1 = new Passenger();
			passenger1.setUserId(passengerEntity.getUserId());
			passenger1.setPassword(passengerEntity.getPassword());
			passenger1.setAge(passengerEntity.getAge());
			passenger1.setPassengerName(passengerEntity.getPassengerName());
			passenger1.setEmailid(passengerEntity.getEmailid());
			passenger1.setGender(passengerEntity.getGender());
			passenger1.setContactNumber(passengerEntity.getContactNumber());
		}

		return passenger1;
	}

}
