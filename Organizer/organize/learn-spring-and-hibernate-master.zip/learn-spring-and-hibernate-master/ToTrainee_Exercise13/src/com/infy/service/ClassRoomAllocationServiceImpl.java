package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.ClassRoomAllocationDAO;
import com.infy.model.Trainee;

@Service(value = "classRoomAllocationService")
@Transactional(readOnly = true)
public class ClassRoomAllocationServiceImpl implements
		ClassRoomAllocationService {
	@Autowired
	private ClassRoomAllocationDAO classRoomAllocationDAO;

	public Trainee getAllocationDetails(Integer traineeId) throws Exception {
		Trainee trainee = null;
		trainee = classRoomAllocationDAO.getAllocationDetails(traineeId);
		if(trainee == null)
			throw new Exception("Service.INVALID_ID");
		return trainee;
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Integer addNewTrainee(Trainee trainee) throws Exception {
		Integer id =  null;
		id = classRoomAllocationDAO.addNewTrainee(trainee);
		return id;
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Integer updateClassRoomDetails(Integer traineeId, String classRoomId)
			throws Exception {
		Integer result =  null;
		result = classRoomAllocationDAO.updateClassRoomDetails(traineeId, classRoomId);
		if(result == 0)
			throw new Exception("Service.INVALID_ID");
		if(result == -1)
			throw new Exception("Service.INVALID_CLASSROOM");
		return result;
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String deleteTraineeDetails(Integer traineeId) throws Exception {
		String result =  null;
		result = classRoomAllocationDAO.deleteTraineeDetails(traineeId);
		if(result == null)
			throw new Exception("Service.TRAINEE_DELETED_FAILURE");
		return result;
	}

}
