package com.infy.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.DirectorEntity;
import com.infy.entity.MovieEntity;
import com.infy.model.Director;
import com.infy.model.Movie;

@Repository(value = "movieDAO")
public class MovieDAOImpl implements MovieDAO {
	
	@Autowired
	SessionFactory sessionFactory;
	
	public String addDirector(Director director) throws Exception {
		String directorId =  null;
		Session session = null;
		session = sessionFactory.getCurrentSession();
		DirectorEntity directorEntity = new DirectorEntity();
		directorEntity.setDirectorId(director.getDirectorId());
		directorEntity.setDirectorName(director.getDirectorName());
		directorEntity.setDob(director.getDob());
		List<MovieEntity> movieEntityList = new ArrayList<>();
		for(Movie movie : director.getMoviesList()) {
			MovieEntity movieEntity = new MovieEntity();
			movieEntity.setMovieId(movie.getMovieId());
			movieEntity.setMovieName(movie.getMovieName());
			movieEntity.setIMDBRating(movie.getIMDBRating());
			movieEntityList.add(movieEntity);
		}
		
		directorEntity.setMoviesList(movieEntityList);
		directorId = (String) session.save(directorEntity);
		return directorId;
	}

	public Integer updateDirector(String directorId, List<Movie> movie) throws Exception {
		Integer result = 0;
		Session session = sessionFactory.getCurrentSession();
		DirectorEntity directorEntity = session.get(DirectorEntity.class, directorId);
		List<MovieEntity> movieEntityList = directorEntity.getMoviesList();
		for(Movie m : movie) {
			MovieEntity movieEntity = new MovieEntity();
			movieEntity.setMovieId(m.getMovieId());
			movieEntity.setMovieName(m.getMovieName());
			movieEntity.setIMDBRating(m.getIMDBRating());
			result ++;
			movieEntityList.add(movieEntity);
		}
		directorEntity.setMoviesList(movieEntityList);
		session.persist(directorEntity);
		return result;
	}

	public Director getDirectorDetails(String directorId) throws Exception {
		Director director = null;
		Session session = null;
		session = sessionFactory.getCurrentSession();
		DirectorEntity directorEntity = session.get(DirectorEntity.class, directorId);
		if(directorEntity != null) {
			director = new Director();
			director.setDirectorId(directorEntity.getDirectorId());
			director.setDirectorName(directorEntity.getDirectorName());
			director.setDob(directorEntity.getDob());
			List<MovieEntity> movieEntityList = directorEntity.getMoviesList();
			List<Movie> movieList = new ArrayList<>();
			if(!movieEntityList.isEmpty()) {
				for(MovieEntity movieEntity : movieEntityList) {
					Movie movie = new Movie();
					movie.setMovieId(movieEntity.getMovieId());
					movie.setMovieName(movieEntity.getMovieName());
					movie.setIMDBRating(movieEntity.getIMDBRating());
					movieList.add(movie);
				}
			}
			director.setMoviesList(movieList);
		}
		
		
		
		return director;
	}

}
